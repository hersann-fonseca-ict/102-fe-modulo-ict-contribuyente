prompt --application/pages/page_00203
begin
--   Manifest
--     PAGE: 00203
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>5801312104779619
,p_default_application_id=>102
,p_default_id_offset=>0
,p_default_owner=>'DESA_SIT'
);
wwv_flow_api.create_page(
 p_id=>203
,p_user_interface_id=>wwv_flow_api.id(5143571665344221)
,p_name=>unistr('Consulta de Cr\00E9ditos Fiscales')
,p_alias=>unistr('CONSULTA-DE-CR\00C9DITOS-FISCALES')
,p_step_title=>unistr('Consulta de Cr\00E9ditos Fiscales')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_browser_cache=>'N'
,p_last_updated_by=>'KIMBERLYN.SOLANO'
,p_last_upd_yyyymmddhh24miss=>'20221121125554'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(36445918481960701)
,p_plug_name=>'Consulta de Creditos  Fiscales'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(5058998562344289)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(36446097936960702)
,p_plug_name=>unistr('Par\00E1metros')
,p_parent_plug_id=>wwv_flow_api.id(36445918481960701)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(5058998562344289)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(36446168123960703)
,p_name=>'Reporte'
,p_parent_plug_id=>wwv_flow_api.id(36445918481960701)
,p_template=>wwv_flow_api.id(5058998562344289)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ID_CREDITO, ',
'       ID_DEUDOR, ',
'       --nombre_deudor, ',
'       CODIGO_ESTADO, ',
'       --nombre_estado, ',
'       ID_TIPO_CREDITO, ',
'       --nombre_credito, ',
'       CODIGO_MONEDA, ',
'       --nombre_moneda, ',
'       FECHA_CREDITO, ',
'       ''NC''||''-''||ID_CREDITO||''-''||PERIODO ',
'       nota_credito, ',
'       NUM_OFIC_CREDITO, ',
'       ID_DOCTO_X_PAGAR, ',
'       MONTO_MONEDA, ',
'       SALDO_MONEDA',
'FROM CREDITOS_CXC@CONSULTA_ICTX ',
'WHERE ID_DEUDOR = PKG_MAESTRO_CONTRIBUYENTE.RETORNA_ID_DEUDOR (:APP_USER)',
'AND ((:P203_FEC_DESDE is null) or (:P203_FEC_HASTA is null) or ',
'    TO_DATE(FECHA_CREDITO,''MM/DD/RRRR'') BETWEEN TO_DATE(:P203_FEC_DESDE,''DD/MM/RRRR'') AND TO_DATE(:P203_FEC_HASTA,''DD/MM/RRRR'')) ',
'AND CODIGO_ESTADO = ''T''   ',
'AND :P203_ESTADOS = ''CU''',
'UNION',
'SELECT ID_CREDITO, ',
'       ID_DEUDOR, ',
'       --nombre_deudor, ',
'       CODIGO_ESTADO, ',
'       --nombre_estado, ',
'       ID_TIPO_CREDITO, ',
'       --nombre_credito, ',
'       CODIGO_MONEDA, ',
'       --nombre_moneda, ',
'       FECHA_CREDITO, ',
'       ''NC''||''-''||ID_CREDITO||''-''||PERIODO ',
'       nota_credito, ',
'       NUM_OFIC_CREDITO, ',
'       ID_DOCTO_X_PAGAR, ',
'       MONTO_MONEDA, ',
'       SALDO_MONEDA',
'FROM CREDITOS_CXC@CONSULTA_ICTX ',
'WHERE ID_DEUDOR = PKG_MAESTRO_CONTRIBUYENTE.RETORNA_ID_DEUDOR (:APP_USER)',
'AND ((:P203_FEC_DESDE is null) or (:P203_FEC_HASTA is null) or',
'     TO_DATE(FECHA_CREDITO,''MM/DD/RRRR'') BETWEEN TO_DATE(:P203_FEC_DESDE,''DD/MM/RRRR'') AND TO_DATE(:P203_FEC_HASTA,''DD/MM/RRRR''))',
'AND CODIGO_ESTADO IN (''A'',''EN'',''P'')   ',
'AND :P203_ESTADOS = ''CS''',
''))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P203_FEC_HASTA,P203_FEC_DESDE,P203_ESTADOS'
,p_query_row_template=>wwv_flow_api.id(5085249619344274)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'SEARCH_ENGINE'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(36446220233960704)
,p_query_column_id=>1
,p_column_alias=>'ID_CREDITO'
,p_column_display_sequence=>1
,p_column_heading=>'Id Credito'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(36446350789960705)
,p_query_column_id=>2
,p_column_alias=>'ID_DEUDOR'
,p_column_display_sequence=>2
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(36447307038960715)
,p_query_column_id=>3
,p_column_alias=>'CODIGO_ESTADO'
,p_column_display_sequence=>3
,p_column_heading=>'Estado'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_api.id(36555624753671155)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(36446529734960707)
,p_query_column_id=>4
,p_column_alias=>'ID_TIPO_CREDITO'
,p_column_display_sequence=>4
,p_column_heading=>unistr('Tipo de Cr\00E9dito')
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_api.id(36549656771716629)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(36446608688960708)
,p_query_column_id=>5
,p_column_alias=>'CODIGO_MONEDA'
,p_column_display_sequence=>5
,p_column_heading=>'Moneda'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_api.id(36154951738689168)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(36446765732960709)
,p_query_column_id=>6
,p_column_alias=>'FECHA_CREDITO'
,p_column_display_sequence=>6
,p_column_heading=>unistr('Fecha Cr\00E9dito')
,p_use_as_row_header=>'N'
,p_column_format=>'DD-MM-YYYY'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(36447416413960716)
,p_query_column_id=>7
,p_column_alias=>'NOTA_CREDITO'
,p_column_display_sequence=>7
,p_column_heading=>unistr('Nota Cr\00E9dito')
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(36446840010960710)
,p_query_column_id=>8
,p_column_alias=>'NUM_OFIC_CREDITO'
,p_column_display_sequence=>8
,p_column_heading=>unistr('Oficio Cr\00E9dito')
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(36446950672960711)
,p_query_column_id=>9
,p_column_alias=>'ID_DOCTO_X_PAGAR'
,p_column_display_sequence=>9
,p_column_heading=>'Docto por Pagar'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(36447025742960712)
,p_query_column_id=>10
,p_column_alias=>'MONTO_MONEDA'
,p_column_display_sequence=>10
,p_column_heading=>unistr('Monto Cr\00E9dito')
,p_use_as_row_header=>'N'
,p_column_format=>'999,999,999.99'
,p_column_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(36447138525960713)
,p_query_column_id=>11
,p_column_alias=>'SALDO_MONEDA'
,p_column_display_sequence=>11
,p_column_heading=>unistr('Saldo Cr\00E9dito')
,p_use_as_row_header=>'N'
,p_column_format=>'999,999,999.99'
,p_column_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(36448138896960723)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(36446097936960702)
,p_button_name=>'BNT_BUSCAR_CREDITO'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5121094921344251)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Buscar'
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(36447600012960718)
,p_name=>'P203_FEC_DESDE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(36446097936960702)
,p_prompt=>'Fecha Inicial'
,p_format_mask=>'dd/mm/yyyy'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_colspan=>4
,p_field_template=>wwv_flow_api.id(5119791289344256)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(36447782919960719)
,p_name=>'P203_FEC_HASTA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(36446097936960702)
,p_prompt=>'Fecha Final'
,p_format_mask=>'dd/mm/yyyy'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_colspan=>4
,p_field_template=>wwv_flow_api.id(5119791289344256)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(36447837117960720)
,p_name=>'P203_ESTADOS'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(36446097936960702)
,p_prompt=>'Estados'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>unistr('STATIC:Cr\00E9ditos Utilizados;CU,Cr\00E9ditos con Saldo;CS')
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(5119791289344256)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.component_end;
end;
/
