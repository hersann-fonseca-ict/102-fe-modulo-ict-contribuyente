prompt --application/pages/page_00007
begin
--   Manifest
--     PAGE: 00007
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>5801312104779619
,p_default_application_id=>102
,p_default_id_offset=>0
,p_default_owner=>'DESA_SIT'
);
wwv_flow_api.create_page(
 p_id=>7
,p_user_interface_id=>wwv_flow_api.id(5143571665344221)
,p_name=>unistr('7-Solicitar Activaci\00F3n Usuario')
,p_alias=>unistr('7-SOLICITAR-ACTIVACI\00D3N-USUARIO')
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Solicitar Activaci\00F3n Usuario')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_browser_cache=>'N'
,p_last_updated_by=>'KIMBERLYN.SOLANO'
,p_last_upd_yyyymmddhh24miss=>'20221121124830'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(98379749770033436)
,p_plug_name=>'Principal'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(5058998562344289)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(98379973432033438)
,p_plug_name=>'Enviar Correo'
,p_parent_plug_id=>wwv_flow_api.id(98379749770033436)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(5058998562344289)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(98380490253033443)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_api.id(98379973432033438)
,p_button_name=>'BTN_ENVIAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5121094921344251)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Enviar'
,p_button_position=>'REGION_TEMPLATE_CREATE'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(103591749007110313)
,p_branch_name=>'Go to 110'
,p_branch_action=>'f?p=&APP_ID.:110:&SESSION.::&DEBUG.::P110_TIPO_INSCRIPCION:U&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(98379868588033437)
,p_name=>'P7_USUARIO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(98379749770033436)
,p_prompt=>'Usuario:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(5119973298344255)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(98380023171033439)
,p_name=>'P7_DESDE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(98379973432033438)
,p_prompt=>'De:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(5119973298344255)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(98380168638033440)
,p_name=>'P7_PARA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(98379973432033438)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(98380285378033441)
,p_name=>'P7_ASUNTO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(98379973432033438)
,p_prompt=>'Asunto:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(5119973298344255)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(98380318347033442)
,p_name=>'P7_DETALLE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(98379973432033438)
,p_prompt=>'Detalle:'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(5120299602344255)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(98380571569033444)
,p_name=>'DAC_DATOS_CORREO'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P7_USUARIO'
,p_condition_element=>'P7_USUARIO'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(98380665032033445)
,p_event_id=>wwv_flow_api.id(98380571569033444)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(98379973432033438)
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(98380776984033446)
,p_event_id=>wwv_flow_api.id(98380571569033444)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(98379973432033438)
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(98380935857033448)
,p_event_id=>wwv_flow_api.id(98380571569033444)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'vAsunto_usrExterno VARCHAR2(4000);',
'vDetalle_usrExterno VARCHAR2(4000);',
'vCorreoUsrExt VARCHAR2(200);',
'vCorreoUsrInt VARCHAR2(200);',
'vCantCorreoUsrExt NUMBER;',
'vCantCorreoUsrInt NUMBER;',
'',
'--Obtenemos los correos de la inscripcion',
'    CURSOR C_CANT_CORREOS_USR_EXTERNO IS',
'    SELECT COUNT (*)',
'    FROM   CORREO_NOTIFICACIONES',
'    WHERE  ID_CONTRIBUYENTE = PKG_MAESTRO_CONTRIBUYENTE.RETORNA_ID_CONTRIBUYENTE (:P7_USUARIO)',
'    AND    CODIGO_ESTADO = ''AC'';',
'--Obtenemos los correos de la inscripcion',
'    CURSOR C_CORREOS_USR_EXTERNO IS',
'    SELECT CORREO_NOTIFICA',
'    FROM   CORREO_NOTIFICACIONES',
'    WHERE  ID_CONTRIBUYENTE = PKG_MAESTRO_CONTRIBUYENTE.RETORNA_ID_CONTRIBUYENTE (:P7_USUARIO)',
'    AND    CODIGO_ESTADO = ''AC'';',
'--Obtengo cantidad de encargados',
'    CURSOR C_CANT_CORREOS_USR_INTERNO IS',
'    SELECT COUNT(*)',
'    FROM  ENCARGADO_CORREO_SIT',
'    WHERE IND_CORREO = ''S'';',
'--Obtenemos correos de los encargados',
'    CURSOR C_CORREOS_ENCAR IS',
'    SELECT CORREO_ENCARGADO',
'    FROM  ENCARGADO_CORREO_SIT',
'    WHERE IND_CORREO = ''S'';',
'BEGIN',
'    OPEN  C_CANT_CORREOS_USR_EXTERNO;',
'    FETCH C_CANT_CORREOS_USR_EXTERNO INTO vCantCorreoUsrExt;',
'    CLOSE C_CANT_CORREOS_USR_EXTERNO;',
'    ',
'    OPEN  C_CANT_CORREOS_USR_INTERNO;',
'    FETCH C_CANT_CORREOS_USR_INTERNO INTO vCantCorreoUsrInt;',
'    CLOSE C_CANT_CORREOS_USR_INTERNO;',
'    ',
'FOR b IN 1..vCantCorreoUsrExt LOOP',
'    vCorreoUsrExt := NULL;',
'    FOR i IN C_CORREOS_USR_EXTERNO LOOP',
'        vCorreoUsrExt := i.CORREO_NOTIFICA||'',''||vCorreoUsrExt;',
'    END LOOP;',
'    --:P7_DESDE := vCorreoUsrExt;',
'END LOOP;',
'',
'FOR b IN 1..vCantCorreoUsrInt LOOP',
'vCorreoUsrInt := NULL;',
'    FOR i IN C_CORREOS_ENCAR LOOP',
'        vCorreoUsrInt := i.CORREO_ENCARGADO||'',''||vCorreoUsrInt;',
'    END LOOP;',
'   :P7_PARA := vCorreoUsrInt ;',
'    :P7_DESDE := vCorreoUsrExt;',
unistr('    :P7_ASUNTO := ''Solicitud de activaci\00F3n de usuario, c\00F3digo tributario: ''||PKG_MAESTRO_CONTRIBUYENTE.RETORNA_ID_DEUDOR (:P7_USUARIO);'),
'END LOOP;',
'END;'))
,p_attribute_02=>'P7_USUARIO'
,p_attribute_03=>'P7_DESDE,P7_PARA,P7_ASUNTO'
,p_attribute_04=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(103591335949110309)
,p_name=>'DAC_MUESTRA_BTN_ENVIAR'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P7_DETALLE'
,p_condition_element=>'P7_DETALLE'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(103591437213110310)
,p_event_id=>wwv_flow_api.id(103591335949110309)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_api.id(98380490253033443)
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(103591587770110311)
,p_event_id=>wwv_flow_api.id(103591335949110309)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_api.id(98380490253033443)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(103591630062110312)
,p_process_sequence=>10
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_ENVIA_CORREO'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'vAsunto VARCHAR2(100);',
'BEGIN',
unistr(' vAsunto := TRANSLATE(:P7_ASUNTO,''\00F1\00E1\00E9\00ED\00F3\00FA\00E0\00E8\00EC\00F2\00F9\00E3\00F5\00E2\00EA\00EE\00F4\00F4\00E4\00EB\00EF\00F6\00FC\00E7\00D1\00C1\00C9\00CD\00D3\00DA\00C0\00C8\00CC\00D2\00D9\00C3\00D5\00C2\00CA\00CE\00D4\00DB\00C4\00CB\00CF\00D6\00DC\00C7'',''naeiouaeiouaoaeiooaeioucNAEIOUAEIOUAOAEIOOAEIOUC'');'),
unistr(' vAsunto := REPLACE(vAsunto, ''\00F3'',  ''o'');'),
'PKG_ENVIO_NOTIF_ICT_CONTRIB.CORREO_ACTIVA_USR_EXTERNO (:P7_USUARIO,NULL,8,vAsunto,:P7_DETALLE);',
'END;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(98380490253033443)
);
wwv_flow_api.component_end;
end;
/
