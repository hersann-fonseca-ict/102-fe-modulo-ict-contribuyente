prompt --application/pages/page_00111
begin
--   Manifest
--     PAGE: 00111
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>5801312104779619
,p_default_application_id=>102
,p_default_id_offset=>0
,p_default_owner=>'DESA_SIT'
);
wwv_flow_api.create_page(
 p_id=>111
,p_user_interface_id=>wwv_flow_api.id(5143571665344221)
,p_name=>'111-Documentos requeridos'
,p_alias=>'111-DOCUMENTOS-REQUERIDOS'
,p_step_title=>'Documentos requeridos'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_browser_cache=>'N'
,p_last_updated_by=>'KIMBERLYN.SOLANO'
,p_last_upd_yyyymmddhh24miss=>'20230706105539'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(19521418534845407)
,p_plug_name=>'Documentos requeridos'
,p_region_template_options=>'#DEFAULT#:t-Wizard--hideStepsXSmall'
,p_component_template_options=>'t-WizardSteps--displayLabels'
,p_plug_template=>wwv_flow_api.id(5069356128344283)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_list_id=>wwv_flow_api.id(5407085389363356)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_api.id(5098266341344267)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(19521707922845410)
,p_plug_name=>'Documentos requeridos para &P111_NOM_CONTRIBUYENTE.'
,p_parent_plug_id=>wwv_flow_api.id(19521418534845407)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(5058998562344289)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(19525273385845445)
,p_name=>'Reporte Documentos'
,p_parent_plug_id=>wwv_flow_api.id(19521707922845410)
,p_template=>wwv_flow_api.id(5058998562344289)
,p_display_sequence=>30
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID_REQUISITOS_INS,',
'       TIPO_REQUISTO,',
'       NOMBRE_REQUISITO,',
'       ID_TIPO_CONTRIBUYENTE,',
'       PKG_INSCRIPCION_REGULAR.EXISTE_ARCHIVO_INCRIP (ID_REQUISITOS_INS,:P111_NUM_SOLICITUD)EXISTE_ARCHIVO,',
'       case PKG_INSCRIPCION_REGULAR.EXISTE_ARCHIVO_INCRIP (ID_REQUISITOS_INS,:P111_NUM_SOLICITUD)',
'           when ''S'' then ''far fa-check-circle''',
'           when ''N'' then ''fas fa-times-circle''',
'           when ''C'' then ''fas fa-question-circle''',
'       end as icon_class,       ',
'       case PKG_INSCRIPCION_REGULAR.EXISTE_ARCHIVO_INCRIP (ID_REQUISITOS_INS,:P111_NUM_SOLICITUD)',
'           when ''S'' then ''#7AFF33''',
'           when ''N'' then ''#FF5733''',
'           when ''C'' then ''#F7DC6F''',
'       end as color_class,',
'       case PKG_INSCRIPCION_REGULAR.EXISTE_ARCHIVO_INCRIP (ID_REQUISITOS_INS,:P111_NUM_SOLICITUD) ',
'           when ''N'' then ''javascript:$s("P111_ID_REQUISITO",''||ID_REQUISITOS_INS||'');javascript:openModal("IATA_ID"); $("#IATA_ID").trigger("apexrefresh");''',
'           when ''S'' then ''#''',
'           when ''C'' then ''#''',
'       end as link',
'  from TIPO_REQUISITOS',
'  where ID_TIPO_CONTRIBUYENTE = :P103_TIPO_FUENTE',
'  and   TIPO_REQUISTO = ''I''',
'  and CODIGO_ESTADO = ''AC'''))
,p_ajax_enabled=>'Y'
,p_query_row_template=>wwv_flow_api.id(5085249619344274)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(19525318756845446)
,p_query_column_id=>1
,p_column_alias=>'ID_REQUISITOS_INS'
,p_column_display_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(20099368376899402)
,p_query_column_id=>2
,p_column_alias=>'TIPO_REQUISTO'
,p_column_display_sequence=>4
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(19525559015845448)
,p_query_column_id=>3
,p_column_alias=>'NOMBRE_REQUISITO'
,p_column_display_sequence=>3
,p_column_heading=>'Requisitos'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(19525483375845447)
,p_query_column_id=>4
,p_column_alias=>'ID_TIPO_CONTRIBUYENTE'
,p_column_display_sequence=>2
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(34030855908882849)
,p_query_column_id=>5
,p_column_alias=>'EXISTE_ARCHIVO'
,p_column_display_sequence=>5
,p_column_heading=>'Existe Archivo'
,p_use_as_row_header=>'N'
,p_column_html_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<span class="fa #ICON_CLASS#" style="color: #COLOR_CLASS#;">',
'    <spam class="visuallyhidden">#EXISTE_ARCHIVO#</spam>',
'</span>'))
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(34030941021882850)
,p_query_column_id=>6
,p_column_alias=>'ICON_CLASS'
,p_column_display_sequence=>7
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(34182164361231301)
,p_query_column_id=>7
,p_column_alias=>'COLOR_CLASS'
,p_column_display_sequence=>8
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(34182286938231302)
,p_query_column_id=>8
,p_column_alias=>'LINK'
,p_column_display_sequence=>9
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(20099418143899403)
,p_query_column_id=>9
,p_column_alias=>'DERIVED$01'
,p_column_display_sequence=>6
,p_column_heading=>'Adjuntar'
,p_use_as_row_header=>'N'
,p_column_link=>'#LINK#'
,p_column_linktext=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-page.png" class="apex-edit-page" alt="">'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_derived_column=>'Y'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(20099575277899404)
,p_plug_name=>'Adjuntar Archivos'
,p_region_name=>'IATA_ID'
,p_parent_plug_id=>wwv_flow_api.id(19521418534845407)
,p_region_template_options=>'#DEFAULT#:js-dialog-size480x320'
,p_plug_template=>wwv_flow_api.id(5051409310344291)
,p_plug_display_sequence=>40
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(19762498008289990)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(19521418534845407)
,p_button_name=>'PREVIOUS'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5121094921344251)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Regresar'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_button_execute_validations=>'N'
,p_icon_css_classes=>'fa-angle-double-left'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(19762706567287630)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(19521418534845407)
,p_button_name=>'FINISH'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5121094921344251)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Finalizar'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_button_condition=>'P111_ARC_COMPLETOS'
,p_button_condition2=>'S'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_icon_css_classes=>'fa-angle-double-right'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(19763066003286179)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(19521418534845407)
,p_button_name=>'CANCEL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5121094921344251)
,p_button_image_alt=>'Cancel'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:1:&APP_SESSION.::&DEBUG.:::'
,p_button_condition_type=>'NEVER'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(20100170025899410)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(20099575277899404)
,p_button_name=>'BTN_GUARDAR'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5121094921344251)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Guardar'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(19521687412845409)
,p_branch_name=>'Go To Page 110'
,p_branch_action=>'f?p=&APP_ID.:110:&SESSION.::&DEBUG.::P110_NOMBRE_ENTIDAD,P110_NUM_SOLICITUD,P110_TIPO_INSCRIPCION:&P111_NOM_ENTIDAD.,&P111_NUM_SOLICITUD.,IR&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(19762706567287630)
,p_branch_sequence=>10
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(19521592431845408)
,p_branch_name=>'Go To Page 108'
,p_branch_action=>'f?p=&APP_ID.:109:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_VALIDATION'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(19762498008289990)
,p_branch_sequence=>10
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19521860089845411)
,p_name=>'P111_ARCHIVO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(20099575277899404)
,p_prompt=>'Seleccionar Archivo:'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_tag_attributes=>'accept=".pdf,.jpeg,.png"'
,p_field_template=>wwv_flow_api.id(5119973298344255)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19522662188845419)
,p_name=>'P111_NOM_CONTRIBUYENTE'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(19521707922845410)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(20099647305899405)
,p_name=>'P111_ID_REQUISITO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(20099575277899404)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(20099843567899407)
,p_name=>'P111_NUM_SOLICITUD'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(19521707922845410)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(20099958609899408)
,p_name=>'P111_NOM_ENTIDAD'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(19521707922845410)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(25490012533415042)
,p_name=>'P111_ARC_COMPLETOS'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_api.id(19521707922845410)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(81336915254146129)
,p_name=>'P111_NOTIFICACION'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(20099575277899404)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(81337480028146134)
,p_name=>'DAC_GUARDAR_ARCHIVO'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(20100170025899410)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(18685676628810209)
,p_event_id=>wwv_flow_api.id(81337480028146134)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_api.id(20100170025899410)
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(81337504111146135)
,p_event_id=>wwv_flow_api.id(81337480028146134)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>':P111_NOTIFICACION := ''S'';'
,p_attribute_02=>'P111_NOTIFICACION'
,p_attribute_03=>'P111_NOTIFICACION'
,p_attribute_04=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(81337626543146136)
,p_event_id=>wwv_flow_api.id(81337480028146134)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P111_NOTIFICACION'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(81337771187146137)
,p_event_id=>wwv_flow_api.id(81337480028146134)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(81337918916146139)
,p_event_id=>wwv_flow_api.id(81337480028146134)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(18685471461810207)
,p_name=>'New'
,p_event_sequence=>20
,p_bind_type=>'bind'
,p_bind_event_type=>'apexbeforepagesubmit'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(18685543061810208)
,p_event_id=>wwv_flow_api.id(18685471461810207)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_api.id(20100170025899410)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(19522559584845418)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_DATOS'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'vNom_Contribuyente VARCHAR2(100);',
'BEGIN',
':P111_NOTIFICACION := ''N'';',
'select DESCRIPCION into vNom_Contribuyente from TIPO_CONTRIBUYENTE where ID_TIPO_CONTRIBUYENTE = :P103_TIPO_FUENTE;',
':P111_NOM_CONTRIBUYENTE := vNom_Contribuyente;',
'',
'--IF :P111_ARC_COMPLETOS IS NULL THEN',
':P111_ARC_COMPLETOS := PKG_INSCRIPCION_REGULAR.VALIDA_EXIST_ARCH_INSCRIP (:P103_TIPO_FUENTE,:P111_NUM_SOLICITUD);',
'--END IF;',
'END;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(20100215445899411)
,p_process_sequence=>10
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_ADJUNTAR_ARCHIVOS'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'vId_Num_Inscripcion NUMBER;',
'vIdApoderado NUMBER;',
'vIdApoderadoAut NUMBER;',
'v_retorno_boolean   boolean;',
'v_mensaje_retorno   varchar2(2000);',
'',
'vArchivo BLOB;',
'vMimetype VARCHAR2(255);',
'vFilename VARCHAR2(255);',
'BEGIN',
'    --Insertamos documentos requeridos',
'    --Para agencias de viajes',
'    SELECT BLOB_CONTENT, MIME_TYPE, FILENAME INTO vArchivo,vMimetype, vFilename FROM APEX_APPLICATION_TEMP_FILES WHERE NAME = :P111_ARCHIVO;',
'    PKG_INSCRIPCION_REGULAR.P_INSERT_ARCHIVO_REQUI_INSCRIP (:P111_ID_REQUISITO,',
'                                    :P111_NUM_SOLICITUD,',
'                                    vFilename,',
'                                    vArchivo,',
'                                    vMimetype,',
'                                    :APP_USER,',
'                                    v_mensaje_retorno,',
'                                    v_retorno_boolean); ',
'                                                                       ',
'   ',
'IF NOT v_retorno_boolean  ',
'   THEN',
'     RAISE_APPLICATION_ERROR(-20000,v_mensaje_retorno);',
'     rollback;',
'     return; ',
'   else ',
'      commit;',
'   end if;',
'END;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'P111_NOTIFICACION'
,p_process_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_process_when2=>'S'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(20101935629899428)
,p_process_sequence=>20
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_ACTUALIZA_ESTADO'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'UPDATE SOLICITUD_INSCRIPCION SET CODIGO_ESTADO = ''P'' WHERE ID_NUM_INSCRIPCION = :P111_NUM_SOLICITUD;',
'COMMIT;',
'NULL;',
'--Envio de correo usuario externo',
'PKG_ENVIO_NOTIF_ICT_CONTRIB.NOTIFICA_INSCRIPCION (:P111_NUM_SOLICITUD,3,''E'',''I'');',
'--Envio de correo usuario interno',
'PKG_ENVIO_NOTIF_ICT_CONTRIB.NOTIFICA_INSCRIPCION (:P111_NUM_SOLICITUD,3,''I'',''I'');',
'END;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(19762706567287630)
);
wwv_flow_api.component_end;
end;
/
