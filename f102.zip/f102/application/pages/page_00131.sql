prompt --application/pages/page_00131
begin
--   Manifest
--     PAGE: 00131
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>5801312104779619
,p_default_application_id=>102
,p_default_id_offset=>0
,p_default_owner=>'DESA_SIT'
);
wwv_flow_api.create_page(
 p_id=>131
,p_user_interface_id=>wwv_flow_api.id(5143571665344221)
,p_name=>'131-Comprobante de pago COT'
,p_alias=>'131-COMPROBANTE-DE-PAGO-COT'
,p_step_title=>'131-Comprobante de pago COT'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'JORGE.ROJAS'
,p_last_upd_yyyymmddhh24miss=>'20241114100826'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(554465007363907035)
,p_plug_name=>'Principal'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(5058998562344289)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(525553595525825200)
,p_name=>'Entidades Bancarias'
,p_parent_plug_id=>wwv_flow_api.id(554465007363907035)
,p_template=>wwv_flow_api.id(5058998562344289)
,p_display_sequence=>40
,p_region_template_options=>'#DEFAULT#:t-Region--accent5:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--altRowsDefault:t-Report--rowHighlight:t-Report--horizontalBorders:t-Report--hideNoPagination'
,p_new_grid_row=>false
,p_grid_column_span=>3
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
' ''Banco de Costa Rica (BCR)'' AS nombre_identidad, ''https://www.bancobcr.com/wps/portal/bcr'' AS enlace FROM dual',
'UNION ALL',
'SELECT ',
unistr('  ''BCR (Tuc\00E1n)'', ''https://www.tucan.fi.cr/wps/portal/tucan'''),
'FROM dual',
'UNION ALL',
'SELECT ',
'  ''Banco Nacional de Costa Rica (BCR)'', ''https://www.bncr.fi.cr/''',
'FROM dual;'))
,p_ajax_enabled=>'Y'
,p_query_row_template=>wwv_flow_api.id(5085249619344274)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(263386422460358797)
,p_query_column_id=>1
,p_column_alias=>'NOMBRE_IDENTIDAD'
,p_column_display_sequence=>1
,p_column_heading=>'Entidad Bancaria'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(263386876024358798)
,p_query_column_id=>2
,p_column_alias=>'ENLACE'
,p_column_display_sequence=>2
,p_column_heading=>'Enlace (Url)'
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<a href="#ENLACE#" target="_blank"target="_blank" style="color: blue; font-weight: bold; text-decoration: underline;">Visitar</a>'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(554726030839540025)
,p_plug_name=>'Datos del Comprobante de Pago'
,p_parent_plug_id=>wwv_flow_api.id(554465007363907035)
,p_region_template_options=>'#DEFAULT#:t-Region--accent5:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(5058998562344289)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_query_type=>'TABLE'
,p_query_table=>'COMPROBANTE_PAGO_COT'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(847007978710417463)
,p_plug_name=>'Titulo'
,p_parent_plug_id=>wwv_flow_api.id(554465007363907035)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(5058998562344289)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<center><h2>Instituto Costarricense de Turismo</h2></center>',
unistr('<center><h4>Declaraci\00F3n Jurada de Ch\00E1rter Terrestre Transporte Internacional.</h4></center>'),
'<center><h4>Comprobante de pago</h4></center>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(263377576316358786)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(554726030839540025)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5121094921344251)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'REGION_TEMPLATE_CHANGE'
,p_button_condition=>'P131_ID_COMPROBANTE'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(263377938125358786)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(554726030839540025)
,p_button_name=>'CANCEL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5121094921344251)
,p_button_image_alt=>'Cancelar'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
,p_button_redirect_url=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(263378322303358786)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(554726030839540025)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5121094921344251)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Enviar'
,p_button_position=>'REGION_TEMPLATE_CREATE'
,p_button_execute_validations=>'N'
,p_button_condition=>'P131_ID_COMPROBANTE'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(263378727148358786)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(554726030839540025)
,p_button_name=>'DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5121094921344251)
,p_button_image_alt=>'Delete'
,p_button_position=>'REGION_TEMPLATE_DELETE'
,p_button_redirect_url=>'javascript:apex.confirm(htmldb_delete_message,''DELETE'');'
,p_button_execute_validations=>'N'
,p_button_condition=>'P131_ID_COMPROBANTE'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(263393256878358804)
,p_branch_name=>'Go To Page 110'
,p_branch_action=>'f?p=&APP_ID.:110:&SESSION.::&DEBUG.::P110_TIPO_INSCRIPCION:COT&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>1
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(263379138432358787)
,p_name=>'P131_ID_COMPROBANTE'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(554726030839540025)
,p_item_source_plug_id=>wwv_flow_api.id(554726030839540025)
,p_item_default=>'SEQ_COMPROBANTE_COT'
,p_item_default_type=>'SEQUENCE'
,p_source=>'ID_COMPROBANTE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(263379521122358788)
,p_name=>'P131_ID_DECLARA_CTO'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(554726030839540025)
,p_item_source_plug_id=>wwv_flow_api.id(554726030839540025)
,p_source=>'ID_DECLARA_CTO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(263379997749358788)
,p_name=>'P131_NUM_DEPOSITO'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(554726030839540025)
,p_item_source_plug_id=>wwv_flow_api.id(554726030839540025)
,p_prompt=>unistr('N\00B0 Deposito/Transferencia:')
,p_source=>'NUM_DEPOSITO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>20
,p_grid_column=>3
,p_field_template=>wwv_flow_api.id(5119791289344256)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(263380316136358788)
,p_name=>'P131_NOMBRE_ENTIDAD'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(554726030839540025)
,p_item_source_plug_id=>wwv_flow_api.id(554726030839540025)
,p_prompt=>'Nombre de la Entidad Bancaria:'
,p_source=>'NOMBRE_ENTIDAD'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'SELECT NOMBRE_ENTIDAD, CODIGO_ENTIDAD  FROM ENTIDADES@CONSULTA_ICTX'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_grid_column=>3
,p_field_template=>wwv_flow_api.id(5119791289344256)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(263380736735358788)
,p_name=>'P131_FECHA_COMPROB'
,p_source_data_type=>'DATE'
,p_is_required=>true
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(554726030839540025)
,p_item_source_plug_id=>wwv_flow_api.id(554726030839540025)
,p_prompt=>'Fecha Comprobante:'
,p_format_mask=>'DD/MM/YYYY'
,p_source=>'FECHA_COMPROB'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>10
,p_cMaxlength=>255
,p_grid_column=>3
,p_field_template=>wwv_flow_api.id(5119791289344256)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(263381106415358789)
,p_name=>'P131_CODIGO_MONEDA'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(554726030839540025)
,p_item_source_plug_id=>wwv_flow_api.id(554726030839540025)
,p_item_default=>'SELECT codigo_moneda FROM declara_charter_terrestre_o WHERE id_declara_cto = :P131_ID_DECLARA_CTO;'
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>unistr('C\00F3digo Moneda:')
,p_source=>'CODIGO_MONEDA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select upper(DESCRIPCION), CODIGO_MONEDA',
'from TIPO_MONEDAS@CONSULTA_ICTX',
'where CODIGO_MONEDA = :P127_CODIGO_MONEDA'))
,p_cHeight=>1
,p_grid_column=>3
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(5119791289344256)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(263381568498358789)
,p_name=>'P131_MONTO_COMPROB'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(554726030839540025)
,p_item_source_plug_id=>wwv_flow_api.id(554726030839540025)
,p_item_default=>'SELECT TO_CHAR(impuesto_pagar, ''999G999D99'') AS impuesto_pagar FROM declara_charter_terrestre_o WHERE id_declara_cto = :P131_ID_DECLARA_CTO;'
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>'Monto Comprobante:'
,p_format_mask=>'999G999G999G999G990D00'
,p_source=>'MONTO_COMPROB'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_grid_column=>3
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(5120038037344255)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(263381972720358789)
,p_name=>'P131_ARCHIVO1'
,p_is_required=>true
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(554726030839540025)
,p_prompt=>'Adjuntar Comprobante de Pago:'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_grid_column=>3
,p_field_template=>wwv_flow_api.id(5120038037344255)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_help_text=>'<p><span style="color: #008000;">Adjuntar comprobante de pago</span></p>'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
,p_attribute_11=>'.pdf'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(263382811246358792)
,p_name=>'P131_ARCHIVO2'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(554726030839540025)
,p_prompt=>unistr('Adjuntar Declaraci\00F3n Jurada:')
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_grid_column=>3
,p_field_template=>wwv_flow_api.id(5119791289344256)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_help_text=>unistr('<p><span style="color: #008000;">Adjuntar declaraci\00F3n jurada</span></p>')
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
,p_attribute_11=>'.pdf'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(263383795666358793)
,p_name=>'P131_ARCHIVO3'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(554726030839540025)
,p_prompt=>'Otros documentos:'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>20
,p_grid_column=>3
,p_field_template=>wwv_flow_api.id(5119791289344256)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_help_text=>unistr('<p><span style="color: #008000;">Adjuntar alg\00FAn otro documento que sea pertinente</span></p>')
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
,p_attribute_11=>'.pdf'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(263384614577358794)
,p_name=>'P131_ALERTA'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_api.id(554726030839540025)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(263389406336358801)
,p_validation_name=>'VAL_ARCHIVO1_NOT_NULL'
,p_validation_sequence=>10
,p_validation=>'P131_ARCHIVO1'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Debe adjuntar el comprobante de pago'
,p_when_button_pressed=>wwv_flow_api.id(263378322303358786)
,p_associated_item=>wwv_flow_api.id(263381972720358789)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(263389810259358801)
,p_validation_name=>'VAL_NUM_DEPOSITO_NOT_NULL'
,p_validation_sequence=>20
,p_validation=>'P131_NUM_DEPOSITO'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>unistr('Debe ingresar el N\00B0 Deposito/Transferencia')
,p_when_button_pressed=>wwv_flow_api.id(263378322303358786)
,p_associated_item=>wwv_flow_api.id(263379997749358788)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(263390299001358801)
,p_validation_name=>'VAL_NOMBRE_ENTIDAD_NOT_NULL'
,p_validation_sequence=>30
,p_validation=>'P131_NOMBRE_ENTIDAD'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Debe ingresar el nombre de la entidad bancaria'
,p_when_button_pressed=>wwv_flow_api.id(263378322303358786)
,p_associated_item=>wwv_flow_api.id(263380316136358788)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(263390630064358802)
,p_validation_name=>'VAL_FECHA_COMPROB_NOT_NULL'
,p_validation_sequence=>40
,p_validation=>'P131_FECHA_COMPROB'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Debe seleccionar la fecha del comprobante de pago'
,p_when_button_pressed=>wwv_flow_api.id(263378322303358786)
,p_associated_item=>wwv_flow_api.id(263380736735358788)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(263391318311358802)
,p_name=>'DAC_VALIDA_COMPROBANTE'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P131_MONTO_COMPROB'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(263391857825358803)
,p_event_id=>wwv_flow_api.id(263391318311358802)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'vFecha DATE;',
'BEGIN',
' vFecha := TO_DATE(:P131_FECHA_COMPROB,''DD/MM/YYYY'');',
'IF PKG_TRAMITE_COT.VAL_CONPROBANTE_PAGO (:P131_NUM_DEPOSITO, :P131_NOMBRE_ENTIDAD,vFecha, REPLACE(:P131_MONTO_COMPROB,'','','''')) = ''S'' THEN',
'    :P131_ALERTA := ''S'';',
'ELSE',
'     :P131_ALERTA := ''N'';',
'END IF;',
'END;'))
,p_attribute_02=>'P131_ID_COMPROBANTE,P131_NOMBRE_ENTIDAD,P131_FECHA_COMPROB,P131_MONTO_COMPROB,P131_ALERTA,P131_NUM_DEPOSITO'
,p_attribute_03=>'P131_ALERTA'
,p_attribute_04=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(263392209840358803)
,p_name=>'New'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P131_ALERTA'
,p_condition_element=>'P131_ALERTA'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'S'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(263392770347358803)
,p_event_id=>wwv_flow_api.id(263392209840358803)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>unistr('El dep\00F3sito bancario ya fue utilizado en otra transacci\00F3n, favor verificar')
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(263385418616358795)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_api.id(554726030839540025)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form 131-Comprobante de pago COT'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(263390998305358802)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_INSERTA_ARCHIVOS'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    v_retorno_boolean   boolean;',
'    v_mensaje_retorno   varchar2(2000);',
'    vArchivo BLOB;',
'    vMimetype VARCHAR2(255);',
'    vFilename VARCHAR2(255);',
'',
'BEGIN',
'    ',
'    --Insertamos documentos',
'    IF :P131_ARCHIVO1 IS NOT NULL THEN',
'        SELECT BLOB_CONTENT, MIME_TYPE, FILENAME INTO vArchivo,vMimetype, vFilename FROM APEX_APPLICATION_TEMP_FILES WHERE NAME = :P131_ARCHIVO1;',
'        PKG_TRAMITE_COT.ARCHIVOS_COMPROBANTE_PAGO (:P131_ID_COMPROBANTE,',
'                                                    vFilename,',
'                                                    vArchivo,',
'                                                    vMimetype,',
'                                                    v_mensaje_retorno,',
'                                                    v_retorno_boolean);                                      ',
'   END IF;',
'   IF :P131_ARCHIVO2 IS NOT NULL THEN',
'       SELECT BLOB_CONTENT, MIME_TYPE, FILENAME INTO vArchivo,vMimetype, vFilename FROM APEX_APPLICATION_TEMP_FILES WHERE NAME = :P131_ARCHIVO2;',
'       PKG_TRAMITE_COT.ARCHIVOS_COMPROBANTE_PAGO (:P131_ID_COMPROBANTE,',
'                                                   vFilename,',
'                                                   vArchivo,',
'                                                   vMimetype,',
'                                                   v_mensaje_retorno,',
'                                                   v_retorno_boolean);                                             ',
'   END IF;',
'   IF :P131_ARCHIVO3 IS NOT NULL THEN',
'       SELECT BLOB_CONTENT, MIME_TYPE, FILENAME INTO vArchivo,vMimetype, vFilename FROM APEX_APPLICATION_TEMP_FILES WHERE NAME = :P131_ARCHIVO3;',
'        PKG_TRAMITE_COT.ARCHIVOS_COMPROBANTE_PAGO (:P131_ID_COMPROBANTE,',
'                                                    vFilename,',
'                                                    vArchivo,',
'                                                    vMimetype,',
'                                                    v_mensaje_retorno,',
'                                                    v_retorno_boolean);                  ',
'   END IF;',
'   ',
'   PKG_ENVIO_NOTIF_ICT_CONTRIB.NOTIFICA_INSC_COT_PAGO_ADJ(:P131_ID_DECLARA_CTO, :P131_ID_COMPROBANTE, 14, ''E'', ''I'');',
'   PKG_ENVIO_NOTIF_ICT_CONTRIB.NOTIFICA_INSC_COT_PAGO_ADJ(:P131_ID_DECLARA_CTO, :P131_ID_COMPROBANTE, 14, ''I'', ''I'');',
'   ',
'   IF NOT v_retorno_boolean THEN',
'       RAISE_APPLICATION_ERROR(-20000,v_mensaje_retorno);',
'       rollback;',
'       return; ',
'    else ',
'       commit;',
'    end if;',
'END;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(263378322303358786)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(263385076506358795)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_api.id(554726030839540025)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form 131-Comprobante de pago COT'
);
wwv_flow_api.component_end;
end;
/
