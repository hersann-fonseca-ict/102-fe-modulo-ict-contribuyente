prompt --application/pages/page_00128
begin
--   Manifest
--     PAGE: 00128
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>5801312104779619
,p_default_application_id=>102
,p_default_id_offset=>0
,p_default_owner=>'DESA_SIT'
);
wwv_flow_api.create_page(
 p_id=>128
,p_user_interface_id=>wwv_flow_api.id(5143571665344221)
,p_name=>'128-Recomendaciones COT'
,p_alias=>'128-RECOMENDACIONES-COT'
,p_step_title=>'128-Recomendaciones COT'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'JORGE.ROJAS'
,p_last_upd_yyyymmddhh24miss=>'20241114095329'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(546261881146756653)
,p_plug_name=>'Principal'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(5058998562344289)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(546263097927756665)
,p_plug_name=>'Titulo Requisitos'
,p_parent_plug_id=>wwv_flow_api.id(546261881146756653)
,p_region_template_options=>'#DEFAULT#:t-Region--hideHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(5058998562344289)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_plug_source=>'<center><h3>Requisitos</h3></center>'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P128_MOSTRAR_RECOMEN'
,p_plug_display_when_cond2=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(438220065334423212)
,p_name=>'Requisitos'
,p_parent_plug_id=>wwv_flow_api.id(546263097927756665)
,p_template=>wwv_flow_api.id(5058998562344289)
,p_display_sequence=>50
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--removeHeader:t-Region--textContent:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_region_attributes=>'style="width: 1070px;"'
,p_display_column=>3
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID_REQUISITOS_INS,',
'       NOMBRE_REQUISITO',
'  from TIPO_REQUISITOS',
'  where ID_TIPO_CONTRIBUYENTE = :P128_TTR',
'  and  CODIGO_ESTADO = ''AC''',
'  and  TIPO_REQUISTO = ''I''',
'  order by ID_REQUISITOS_INS'))
,p_display_when_condition=>'P128_TTR'
,p_display_when_cond2=>'17'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P128_TTR'
,p_query_row_template=>wwv_flow_api.id(5085249619344274)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(263321772854269103)
,p_query_column_id=>1
,p_column_alias=>'ID_REQUISITOS_INS'
,p_column_display_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(263322125295269104)
,p_query_column_id=>2
,p_column_alias=>'NOMBRE_REQUISITO'
,p_column_display_sequence=>2
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(546262052843756655)
,p_name=>'Requisitos'
,p_parent_plug_id=>wwv_flow_api.id(546263097927756665)
,p_template=>wwv_flow_api.id(5058998562344289)
,p_display_sequence=>40
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--removeHeader:t-Region--textContent:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_region_attributes=>'style="width: 1070px;"'
,p_display_column=>3
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID_REQUISITOS_INS,',
'       NOMBRE_REQUISITO',
'  from TIPO_REQUISITOS',
'  where ID_TIPO_CONTRIBUYENTE = :GLOBAL_TIPO_CONTRIBUYENTE',
'  and  CODIGO_ESTADO = ''AC''',
'  and  TIPO_REQUISTO = ''I''',
'  order by ID_REQUISITOS_INS'))
,p_display_when_condition=>'GLOBAL_TIPO_CONTRIBUYENTE'
,p_display_when_cond2=>'8'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_ajax_enabled=>'Y'
,p_query_row_template=>wwv_flow_api.id(5085249619344274)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(263323626199269105)
,p_query_column_id=>1
,p_column_alias=>'ID_REQUISITOS_INS'
,p_column_display_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(263324099523269105)
,p_query_column_id=>2
,p_column_alias=>'NOMBRE_REQUISITO'
,p_column_display_sequence=>2
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(546263137733756666)
,p_plug_name=>'Titulo Recomendaciones'
,p_parent_plug_id=>wwv_flow_api.id(546261881146756653)
,p_region_template_options=>'#DEFAULT#:t-Region--hideHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(5058998562344289)
,p_plug_display_sequence=>40
,p_plug_display_point=>'BODY'
,p_plug_source=>'<center><h3>Recomendaciones</h3></center>'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P128_MOSTRAR_RECOMEN'
,p_plug_display_when_cond2=>'S'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(438219575054423207)
,p_name=>'Tipo Recomendacion'
,p_parent_plug_id=>wwv_flow_api.id(546263137733756666)
,p_template=>wwv_flow_api.id(5058998562344289)
,p_display_sequence=>60
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--textContent:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_region_attributes=>'style="width: 1090px;"'
,p_display_column=>3
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID_RECOMENDACION,',
'       DESCRIPCION',
'  from TIPO_RECOMENDACION',
'  where ID_TIPO_CONTRIBUYENTE = :P128_TTR',
'  and   CODIGO_ESTADO = ''AC'''))
,p_display_when_condition=>'P128_TTR'
,p_display_when_cond2=>'17'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P128_TTR'
,p_query_row_template=>wwv_flow_api.id(5085249619344274)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'no data found'
,p_query_row_count_max=>500
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(263325891766269107)
,p_query_column_id=>1
,p_column_alias=>'ID_RECOMENDACION'
,p_column_display_sequence=>1
,p_default_sort_column_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(263326203559269107)
,p_query_column_id=>2
,p_column_alias=>'DESCRIPCION'
,p_column_display_sequence=>2
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(546689024140659272)
,p_name=>'Tipo Recomendacion'
,p_parent_plug_id=>wwv_flow_api.id(546263137733756666)
,p_template=>wwv_flow_api.id(5058998562344289)
,p_display_sequence=>50
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--textContent:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_region_attributes=>'style="width: 1090px;"'
,p_display_column=>3
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID_RECOMENDACION,',
'       DESCRIPCION',
'  from TIPO_RECOMENDACION',
'  where ID_TIPO_CONTRIBUYENTE = :GLOBAL_TIPO_CONTRIBUYENTE',
'  and   CODIGO_ESTADO = ''AC'''))
,p_display_when_condition=>'GLOBAL_TIPO_CONTRIBUYENTE'
,p_display_when_cond2=>'8'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_ajax_enabled=>'Y'
,p_query_row_template=>wwv_flow_api.id(5085249619344274)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'no data found'
,p_query_row_count_max=>500
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_prn_format=>'PDF'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(263327738356269108)
,p_query_column_id=>1
,p_column_alias=>'ID_RECOMENDACION'
,p_column_display_sequence=>1
,p_default_sort_column_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(263328125170269109)
,p_query_column_id=>2
,p_column_alias=>'DESCRIPCION'
,p_column_display_sequence=>2
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(707493811610238381)
,p_plug_name=>'Titulo'
,p_parent_plug_id=>wwv_flow_api.id(546261881146756653)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(5058998562344289)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_source=>'<center><h2>Instituto Costarricense de Turismo</h2></center>'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(263322533677269104)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(438220065334423212)
,p_button_name=>'BTN_CONTINUA_1'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5121094921344251)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Continuar'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:128:&SESSION.::&DEBUG.::P128_MOSTRAR_RECOMEN:S'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(263324489680269105)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(546262052843756655)
,p_button_name=>'BTN_CONTINUA'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5121094921344251)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Continuar'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:128:&SESSION.::&DEBUG.::P128_MOSTRAR_RECOMEN:S'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(263326658496269107)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(438219575054423207)
,p_button_name=>'BTN_CANCELAR_1'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5121094921344251)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Cancelar'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(263328571063269109)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(546689024140659272)
,p_button_name=>'BTN_CONTINUAR'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5121094921344251)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Continuar'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:127:&SESSION.::&DEBUG.:127:P127_CLEAR:S'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(263322932714269104)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(438220065334423212)
,p_button_name=>'BTN_CANCELA_1'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5121094921344251)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Cancelar'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(263324835996269106)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(546262052843756655)
,p_button_name=>'BTN_CANCELA'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5121094921344251)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Cancelar'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(263327060023269108)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(438219575054423207)
,p_button_name=>'BTN_CONTINUAR_1'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5121094921344251)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Continuar'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:127:&SESSION.::&DEBUG.::P127_CLEAR:S'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(263328985417269109)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(546689024140659272)
,p_button_name=>'BTN_CANCELAR'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5121094921344251)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Cancelar'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:::'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(263320300337269102)
,p_name=>'P128_MOSTRAR_RECOMEN'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(546261881146756653)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(263320732556269102)
,p_name=>'P128_TTR'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(546261881146756653)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.component_end;
end;
/
