prompt --application/pages/page_00121
begin
--   Manifest
--     PAGE: 00121
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>5801312104779619
,p_default_application_id=>102
,p_default_id_offset=>0
,p_default_owner=>'DESA_SIT'
);
wwv_flow_api.create_page(
 p_id=>121
,p_user_interface_id=>wwv_flow_api.id(5143571665344221)
,p_name=>unistr('Inscripci\00F3n Vuelos Ch\00E1rter 7')
,p_alias=>unistr('INSCRIPCI\00D3N-VUELOS-CH\00C1RTER-7')
,p_step_title=>unistr('Inscripci\00F3n Vuelos Ch\00E1rter')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_browser_cache=>'N'
,p_last_updated_by=>'JORGE.ROJAS'
,p_last_upd_yyyymmddhh24miss=>'20240308152444'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(27762174231602869)
,p_plug_name=>unistr('Inscripci\00F3n Vuelos Ch\00E1rter 7')
,p_region_template_options=>'#DEFAULT#:t-Wizard--hideStepsXSmall'
,p_plug_template=>wwv_flow_api.id(5069356128344283)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_list_id=>wwv_flow_api.id(27737126160602921)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_api.id(5098266341344267)
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(27762247807602869)
,p_plug_name=>unistr('Direcci\00F3n represente en Costa Rica para Notificaciones ')
,p_parent_plug_id=>wwv_flow_api.id(27762174231602869)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(5058998562344289)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'ITEM_IS_NULL'
,p_plug_display_when_condition=>'P121_ID_SOLICITUD'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(86430927074074202)
,p_plug_name=>'Documentos requeridos'
,p_parent_plug_id=>wwv_flow_api.id(27762174231602869)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(5058998562344289)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P121_ID_SOLICITUD'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(106258516422816576)
,p_name=>'Reporte Documentos'
,p_parent_plug_id=>wwv_flow_api.id(86430927074074202)
,p_template=>wwv_flow_api.id(5058998562344289)
,p_display_sequence=>30
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID_REQUISITOS_INS,',
'       TIPO_REQUISTO,',
'       NOMBRE_REQUISITO,',
'       ID_TIPO_CONTRIBUYENTE,',
'       PKG_INSCRIPCION_REGULAR.EXISTE_ARCHIVO_INCRIP (ID_REQUISITOS_INS,:P121_ID_SOLICITUD)EXISTE_ARCHIVO,',
'       case PKG_INSCRIPCION_REGULAR.EXISTE_ARCHIVO_INCRIP (ID_REQUISITOS_INS,:P121_ID_SOLICITUD)',
'           when ''S'' then ''far fa-check-circle''',
'           when ''N'' then ''fas fa-times-circle''',
'           when ''C'' then ''fas fa-question-circle''',
'       end as icon_class,       ',
'       case PKG_INSCRIPCION_REGULAR.EXISTE_ARCHIVO_INCRIP (ID_REQUISITOS_INS,:P121_ID_SOLICITUD)',
'           when ''S'' then ''#7AFF33''',
'           when ''N'' then ''#FF5733''',
'           when ''C'' then ''#F7DC6F''',
'       end as color_class,',
'       case PKG_INSCRIPCION_REGULAR.EXISTE_ARCHIVO_INCRIP (ID_REQUISITOS_INS,:P121_ID_SOLICITUD) ',
'           when ''N'' then ''javascript:$s("P121_ID_REQUISITO",''||ID_REQUISITOS_INS||'');javascript:openModal("IATA_ID"); $("#IATA_ID").trigger("apexrefresh");''',
'           when ''S'' then ''#''',
'           when ''C'' then ''#''',
'       end as link',
'  from TIPO_REQUISITOS',
'  where ID_TIPO_CONTRIBUYENTE = 7',
'  and   TIPO_REQUISTO = ''I''',
'  and CODIGO_ESTADO = ''AC'''))
,p_ajax_enabled=>'Y'
,p_query_row_template=>wwv_flow_api.id(5085249619344274)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(86735870921971114)
,p_query_column_id=>1
,p_column_alias=>'ID_REQUISITOS_INS'
,p_column_display_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(86737055045971113)
,p_query_column_id=>2
,p_column_alias=>'TIPO_REQUISTO'
,p_column_display_sequence=>4
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(86736601368971114)
,p_query_column_id=>3
,p_column_alias=>'NOMBRE_REQUISITO'
,p_column_display_sequence=>3
,p_column_heading=>'Requisitos'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(86736212987971114)
,p_query_column_id=>4
,p_column_alias=>'ID_TIPO_CONTRIBUYENTE'
,p_column_display_sequence=>2
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(86733859485971118)
,p_query_column_id=>5
,p_column_alias=>'EXISTE_ARCHIVO'
,p_column_display_sequence=>5
,p_column_heading=>'Existe Archivo'
,p_use_as_row_header=>'N'
,p_column_html_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<span class="fa #ICON_CLASS#" style="color: #COLOR_CLASS#;">',
'    <spam class="visuallyhidden">#EXISTE_ARCHIVO#</spam>',
'</span>'))
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(86734288221971115)
,p_query_column_id=>6
,p_column_alias=>'ICON_CLASS'
,p_column_display_sequence=>7
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(86734639408971115)
,p_query_column_id=>7
,p_column_alias=>'COLOR_CLASS'
,p_column_display_sequence=>8
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(86735078668971115)
,p_query_column_id=>8
,p_column_alias=>'LINK'
,p_column_display_sequence=>9
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(86735461198971114)
,p_query_column_id=>9
,p_column_alias=>'DERIVED$01'
,p_column_display_sequence=>6
,p_column_heading=>'Adjuntar'
,p_use_as_row_header=>'N'
,p_column_link=>'#LINK#'
,p_column_linktext=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-page.png" class="apex-edit-page" alt="">'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_derived_column=>'Y'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(106931066054827722)
,p_plug_name=>'Adjuntar Archivos'
,p_region_name=>'IATA_ID'
,p_parent_plug_id=>wwv_flow_api.id(86430927074074202)
,p_region_template_options=>'#DEFAULT#:js-dialog-size480x320'
,p_plug_template=>wwv_flow_api.id(5051409310344291)
,p_plug_display_sequence=>40
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(27764153833602868)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(27762174231602869)
,p_button_name=>'PREVIOUS'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5121094921344251)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Regresar'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_button_execute_validations=>'N'
,p_icon_css_classes=>'fa-angle-double-left'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(86431008101074203)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(27762174231602869)
,p_button_name=>'SIGUIENTE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5121094921344251)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Siguiente'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>'P121_ID_SOLICITUD'
,p_button_condition_type=>'ITEM_IS_NULL'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(27764083260602868)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(27762174231602869)
,p_button_name=>'FINISH'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5121094921344251)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Finalizar'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_button_condition=>'P121_ID_SOLICITUD'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(86831778217928311)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(106931066054827722)
,p_button_name=>'BTN_GUARDAR'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5121094921344251)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Guardar'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(27763936334602868)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_api.id(27762174231602869)
,p_button_name=>'CANCEL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5121094921344251)
,p_button_image_alt=>'Cancelar'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:1:&APP_SESSION.::&DEBUG.:::'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(27765643912602867)
,p_branch_name=>'Go To Page 110'
,p_branch_action=>'f?p=&APP_ID.:110:&SESSION.::&DEBUG.::P110_NUM_SOLICITUD,P110_NOMBRE_ENTIDAD,P110_TIPO_INSCRIPCION:&P121_ID_SOLICITUD.,&P121_NOM_ENTIDAD.,IVC&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_COMPUTATION'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>1
,p_branch_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_branch_condition=>'P121_OFF_BTN_FINALIZAR'
,p_branch_condition_text=>'X'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(27764994595602867)
,p_branch_name=>'Go To Page 120'
,p_branch_action=>'f?p=&APP_ID.:120:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_COMPUTATION'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(27764153833602868)
,p_branch_sequence=>10
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(11284941097086416)
,p_name=>'P121_INSERTAR'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(27762174231602869)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(27388487252630915)
,p_name=>'P121_CORREO_NOTIFICA2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(27762247807602869)
,p_prompt=>'Email2:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>40
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(5119791289344256)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(27763622326602868)
,p_name=>'P121_CORREO_NOTIFICA1'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(27762247807602869)
,p_prompt=>'Email1:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>40
,p_field_template=>wwv_flow_api.id(5120038037344255)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(27956833091876012)
,p_name=>'P121_ID_SOLICITUD'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(27762247807602869)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(27957546272876019)
,p_name=>'P121_NOM_ENTIDAD'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(27762247807602869)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(86430805646074201)
,p_name=>'P121_OBSERVACIONES'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(27762247807602869)
,p_prompt=>'Observaciones:'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cHeight=>3
,p_field_template=>wwv_flow_api.id(5119791289344256)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(86832158432928309)
,p_name=>'P121_ID_REQUISITO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(106931066054827722)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(86832514181928304)
,p_name=>'P121_ARCHIVO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(106931066054827722)
,p_prompt=>'Seleccionar Archivo:'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_tag_attributes=>'accept=".pdf,.jpeg,.png"'
,p_field_template=>wwv_flow_api.id(5119973298344255)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(86832960821928304)
,p_name=>'P121_NOTIFICACION'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(106931066054827722)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(207693072934667322)
,p_name=>'P121_OFF_BTN_FINALIZAR'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(27762174231602869)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(27958073357876024)
,p_validation_name=>'VAL_EMAIL1'
,p_validation_sequence=>10
,p_validation=>'P121_CORREO_NOTIFICA1'
,p_validation2=>'@'
,p_validation_type=>'ITEM_IN_VALIDATION_CONTAINS_AT_LEAST_ONE_CHAR_IN_STRING2'
,p_error_message=>'Formato del email no valido'
,p_validation_condition=>'P121_CORREO_NOTIFICA1'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_associated_item=>wwv_flow_api.id(27763622326602868)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(27958149098876025)
,p_validation_name=>'VAL_EMAIL2'
,p_validation_sequence=>20
,p_validation=>'P121_CORREO_NOTIFICA2'
,p_validation2=>'@'
,p_validation_type=>'ITEM_IN_VALIDATION_CONTAINS_AT_LEAST_ONE_CHAR_IN_STRING2'
,p_error_message=>'Formato del email no valido'
,p_validation_condition=>'P121_CORREO_NOTIFICA2'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_associated_item=>wwv_flow_api.id(27388487252630915)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(14738219456333153)
,p_validation_name=>'VAL_COMAS_EMAIL1'
,p_validation_sequence=>30
,p_validation=>'P121_CORREO_NOTIFICA1'
,p_validation2=>','
,p_validation_type=>'ITEM_IN_VALIDATION_CONTAINS_NO_CHAR_IN_STRING2'
,p_error_message=>'Formato de correo no valido, por favor verificar'
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(13958760330744232)
,p_validation_name=>'VAL_COMAS_EMAIL2'
,p_validation_sequence=>40
,p_validation=>'P121_CORREO_NOTIFICA2'
,p_validation2=>','
,p_validation_type=>'ITEM_IN_VALIDATION_CONTAINS_NO_CHAR_IN_STRING2'
,p_error_message=>'Formato de correo no valido, por favor verificar'
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(86835759601897387)
,p_name=>'New'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(86831778217928311)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(86836197564897365)
,p_event_id=>wwv_flow_api.id(86835759601897387)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>':P121_NOTIFICACION:= ''S'';'
,p_attribute_02=>'P121_NOTIFICACION'
,p_attribute_03=>'P121_NOTIFICACION'
,p_attribute_04=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(86836602844897365)
,p_event_id=>wwv_flow_api.id(86835759601897387)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P121_NOTIFICACION'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(86837695054897364)
,p_event_id=>wwv_flow_api.id(86835759601897387)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(86837164242897365)
,p_event_id=>wwv_flow_api.id(86835759601897387)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(86431399769074206)
,p_name=>'DAC_UPPER_OBS'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P121_OBSERVACIONES'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(86431442822074207)
,p_event_id=>wwv_flow_api.id(86431399769074206)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$("#P121_OBSERVACIONES").val($("#P121_OBSERVACIONES").val().toUpperCase());'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(10115596127669124)
,p_name=>'DAC_LOWER_CORREO1'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P121_CORREO_NOTIFICA1'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(10115645036669125)
,p_event_id=>wwv_flow_api.id(10115596127669124)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$("#P121_CORREO_NOTIFICA1").val($("#P121_CORREO_NOTIFICA1").val().toLowerCase());'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(10115793623669126)
,p_name=>'DAC_LOWER_CORREO2'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P121_CORREO_NOTIFICA2'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(10115807003669127)
,p_event_id=>wwv_flow_api.id(10115793623669126)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$("#P121_CORREO_NOTIFICA2").val($("#P121_CORREO_NOTIFICA2").val().toLowerCase());'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(11285029584086417)
,p_name=>'DAC_DESABILITA_BOTON'
,p_event_sequence=>50
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(86431008101074203)
,p_condition_element=>'P121_ID_SOLICITUD'
,p_triggering_condition_type=>'NULL'
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(11285157572086418)
,p_event_id=>wwv_flow_api.id(11285029584086417)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>':P121_INSERTAR := ''S'';'
,p_attribute_02=>'P121_INSERTAR'
,p_attribute_03=>'P121_INSERTAR'
,p_attribute_04=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(11285270396086419)
,p_event_id=>wwv_flow_api.id(11285029584086417)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_api.id(86431008101074203)
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(11285378032086420)
,p_event_id=>wwv_flow_api.id(11285029584086417)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(221060802857749003)
,p_name=>'DAC_INABILITA_FINISH'
,p_event_sequence=>60
,p_bind_type=>'bind'
,p_bind_event_type=>'apexbeforepagesubmit'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(221061093054749005)
,p_event_id=>wwv_flow_api.id(221060802857749003)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_api.id(27764083260602868)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(86431246888074205)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_DATOS'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'vExiste VARCHAR2(1);',
'BEGIN',
'    IF :P121_ID_SOLICITUD IS NOT NULL THEN',
'        SELECT ''S'' INTO vExiste FROM SOLICITUD_INSCRIPCION WHERE ID_NUM_INSCRIPCION= :P121_ID_SOLICITUD;',
'            IF vExiste = ''S'' THEN',
'             :P121_ID_SOLICITUD := NULL;',
'             :P121_NOTIFICACION := ''N'';',
'            END IF;',
'    END IF;',
'END;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_type=>'NEVER'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(27956668488876010)
,p_process_sequence=>10
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_INSERT_SOLICITUD'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'vId_Num_Inscripcion NUMBER;',
'vIdApoderado NUMBER;',
'v_retorno_boolean   boolean;',
'v_mensaje_retorno   varchar2(2000);',
'vCed_Fisica VARCHAR2(20);',
'vCed_Juridica VARCHAR2(20);',
'vFechaOperaciones DATE;',
'BEGIN',
'',
'    IF :P116_ID_TIPO_IDENTIFICACION = 1 THEN',
'        vCed_Juridica:= :P116_CEDULA;',
'    ELSE',
'        vCed_Fisica := :P116_CEDULA;',
'    END IF;',
'    vFechaOperaciones := TO_DATE(:P116_FECHA_INICIO_OPERA,''DD/MM/YYYY'');',
'',
'    PKG_INSCRIPCION_REGULAR.P_INSERT_SOLICITUD_INSCRIP(vId_Num_Inscripcion,',
'                               :P116_NOMBRE_ENTIDAD,',
'                               :P116_ID_TIPO_IDENTIFICACION,',
'                               :P116_RAZON_SOCIAL,',
'                               NULL,',
'                               vCed_Juridica,',
'                               vCed_Fisica,',
'                               :P116_TIPO_FUENTE,',
'                               NULL,',
'                               NULL,',
'                               vFechaOperaciones,',
'                               NULL,',
'                               NULL,',
'                               NULL,',
'                               NULL,',
'                               NULL,',
'                               NULL,',
'                               NULL,',
'                               NULL, ',
'                               NULL,',
'                               NULL,',
'                               NULL,                                  ',
'                               :P118_NOMBRE_REPRE_LEGAL,',
'                               :P118_CEDULA_REPRE_LEGAL,',
'                               :P118_CORREO_REPRE_LEGAL,',
'                               ''P'',',
'                               SYSDATE,--pFECHA_INSCRIPCION,',
'                               :P121_OBSERVACIONES,',
'                               NULL,--pOBSERVA_ADM_TRIBUTA,    ',
'                               NULL,--pFECHA_SUSCRITO,',
'                               NULL,--pLUGAR_SUSCRITO,',
'                               NULL,--pUSUARIO_INTERNO,',
'                               1,--ID_CHARTER',
'                               NULL,--ID_REQUISITOS_INS',
'                               NULL,',
'                               :P119_NOM_ASISTENTE_CHARTER,',
'                               :P119_CEDULA_ASISTENTE_CHARTER,',
'                               :P119_CORREO_ASISTENTE_CHARTER,',
'                               NULL,',
'                               :APP_USER,',
'                               v_mensaje_retorno,',
'                               v_retorno_boolean);',
'                               COMMIT;',
'',
'',
'    :P116_ID_NUM_SOLICITUD := vId_Num_Inscripcion;',
'    :P121_ID_SOLICITUD := vId_Num_Inscripcion;',
'    :P121_NOM_ENTIDAD := :P116_NOMBRE_ENTIDAD;',
'    ',
'   IF vId_Num_Inscripcion IS NOT NULL THEN',
'      -- RAISE_APPLICATION_ERROR (-20000, vId_Num_Inscripcion);',
'    --Insertamos los datos en la tabla TELEFONO_X_SOLICITUD_INSCRIP-----------------',
'   IF :P116_TEL_OFICINA1 IS NOT NULL OR :P116_CELULAR IS NOT NULL THEN',
'   PKG_INSCRIPCION_REGULAR.P_INSERT_TEL_SOLIC_INSCRIP (vId_Num_Inscripcion,',
'                                  :P116_TEL_OFICINA1,',
'                                  :P116_CELULAR,',
'                                  :APP_USER,',
'                                  v_mensaje_retorno,',
'                                  v_retorno_boolean);',
'    END IF;',
'    IF :P116_TEL_OFICINA2 IS NOT NULL OR :P116_CELULAR2 IS NOT NULL THEN                                        ',
'    PKG_INSCRIPCION_REGULAR.P_INSERT_TEL_SOLIC_INSCRIP (vId_Num_Inscripcion,',
'                                  :P116_TEL_OFICINA2,',
'                                  :P116_CELULAR2,',
'                                  :APP_USER,',
'                                  v_mensaje_retorno,',
'                                  v_retorno_boolean);',
'    END IF; ',
'',
'--Insertamos los datos en la tabla IMPUESTO_X_SOLICITUD_INSCRI------------------                                        ',
'    IF :P117_TIP_IMPUESTO IS NOT NULL THEN',
'    PKG_INSCRIPCION_REGULAR.P_INSERT_IMP_SOLIC_INSCRIP (vId_Num_Inscripcion,',
'                                  :P117_TIP_IMPUESTO,',
'                                  NULL,',
'                                  NULL,',
'                                  NULL,',
'                                 :APP_USER,',
'                                  v_mensaje_retorno,',
'                                  v_retorno_boolean); ',
'    END IF;',
'    IF :P117_TIP_IMPUESTO_1 IS NOT NULL THEN ',
'    PKG_INSCRIPCION_REGULAR.P_INSERT_IMP_SOLIC_INSCRIP (vId_Num_Inscripcion,',
'                                  :P117_TIP_IMPUESTO_1,',
'                                  NULL,',
'                                  NULL,',
'                                  NULL,',
'                                 :APP_USER,',
'                                  v_mensaje_retorno,',
'                                  v_retorno_boolean); ',
'    END IF;',
'    IF :P117_TIP_IMPUESTO_2 IS NOT NULL THEN',
'    PKG_INSCRIPCION_REGULAR.P_INSERT_IMP_SOLIC_INSCRIP (vId_Num_Inscripcion,',
'                                  :P117_TIP_IMPUESTO_2,',
'                                  NULL,',
'                                  NULL,',
'                                  NULL,',
'                                  :APP_USER,',
'                                  v_mensaje_retorno,',
'                                  v_retorno_boolean);',
'    END IF;                              ',
'                                              ',
'--Inserta datos en la tabla CORREO_NOTIFICA_INSCRIP-----------------------------                                          ',
'     PKG_INSCRIPCION_REGULAR.P_INSERT_CORREO_NOT_INSCRIP (vId_Num_Inscripcion,',
'                                 :P121_CORREO_NOTIFICA1,',
'                                 :P121_CORREO_NOTIFICA2,',
'                                 :APP_USER,',
'                                 v_mensaje_retorno,',
'                                 v_retorno_boolean);',
'                                 ',
'     --RAISE_APPLICATION_ERROR(-20000,vId_Num_Inscripcion);                    ',
'     IF :P120_NOMBRE_APODERADO IS NOT NULL THEN',
'     PKG_INSCRIPCION_REGULAR.P_INSERT_APODERADOS_SOLICITUD (vIdApoderado,',
'                                   vId_Num_Inscripcion,',
'                                   3,',
'                                   :P120_NOMBRE_APODERADO,',
'                                   :P120_CEDULA_APODERADO,',
'                                   :P120_CORREO_APODERADO,',
'                                   ''A'',',
'                                   NULL,',
'                                   NULL,',
'                                   NULL,',
'                                   :APP_USER,',
'                                   v_mensaje_retorno,',
'                                   v_retorno_boolean);                         ',
' ',
'     END IF;',
' END IF;',
'IF NOT v_retorno_boolean  ',
'   THEN',
'     RAISE_APPLICATION_ERROR(-20000,v_mensaje_retorno);',
'     rollback;',
'     return; ',
'   else ',
'      commit;',
'       :P121_INSERTAR := ''N'';',
'   end if;',
'END;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'P121_INSERTAR'
,p_process_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_process_when2=>'S'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(86834833419915113)
,p_process_sequence=>20
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_ADJUNTAR_ARCHIVOS'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'vId_Num_Inscripcion NUMBER;',
'vIdApoderado NUMBER;',
'vIdApoderadoAut NUMBER;',
'v_retorno_boolean   boolean;',
'v_mensaje_retorno   varchar2(2000);',
'',
'vArchivo BLOB;',
'vMimetype VARCHAR2(255);',
'vFilename VARCHAR2(255);',
'BEGIN',
'    --Insertamos documentos requeridos',
'    --Para agencias de viajes',
'    IF :P121_ARCHIVO IS NOT NULL THEN',
'    SELECT BLOB_CONTENT, MIME_TYPE, FILENAME INTO vArchivo,vMimetype, vFilename FROM APEX_APPLICATION_TEMP_FILES WHERE NAME = :P121_ARCHIVO;',
'    PKG_INSCRIPCION_REGULAR.P_INSERT_ARCHIVO_REQUI_INSCRIP (:P121_ID_REQUISITO,',
'                                    :P121_ID_SOLICITUD,',
'                                    vFilename,',
'                                    vArchivo,',
'                                    vMimetype,',
'                                    :APP_USER,',
'                                    v_mensaje_retorno,',
'                                    v_retorno_boolean); ',
'    END IF;                                                                   ',
'   ',
'IF NOT v_retorno_boolean  ',
'   THEN',
'     RAISE_APPLICATION_ERROR(-20000,v_mensaje_retorno);',
'     rollback;',
'     return; ',
'   else ',
'      commit;',
'   end if;',
'END;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'P121_NOTIFICACION'
,p_process_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_process_when2=>'S'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(86431158332074204)
,p_process_sequence=>30
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_ENVIA_CORREO'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
':P121_OFF_BTN_FINALIZAR := ''X'';',
'--Envio de correo usuario externo',
'PKG_ENVIO_NOTIF_ICT_CONTRIB.NOTIFICA_INSCRIPCION (:P121_ID_SOLICITUD,4,''E'',''I'');',
'--Envio de correo usuario interno',
'PKG_ENVIO_NOTIF_ICT_CONTRIB.NOTIFICA_INSCRIPCION (:P121_ID_SOLICITUD,4,''I'',''I'');',
'',
'END;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(27764083260602868)
);
wwv_flow_api.component_end;
end;
/
