prompt --application/pages/page_09999
begin
--   Manifest
--     PAGE: 09999
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>5801312104779619
,p_default_application_id=>102
,p_default_id_offset=>0
,p_default_owner=>'DESA_SIT'
);
wwv_flow_api.create_page(
 p_id=>9999
,p_user_interface_id=>wwv_flow_api.id(5143571665344221)
,p_name=>'Login Page'
,p_alias=>'LOGIN'
,p_step_title=>'Sign In'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.t-Login-logo {',
'         background-image: url(#APP_IMAGES#indice.png);',
'         background-size: cover;',
'         width: 100px;',
'         height: 100px;',
'            }',
'',
'.t-PageBody--login .t-Login-container { background-image: url(#APP_IMAGES#loginexterno102.jpg); background-position: center center; background-repeat: no-repeat; background-attachment: fixed; background-size: cover; background-color: #45484d; backgro'
||'und-color: -moz-linear-gradient(top, #45484d 0%, #000000 100%); background-color: -webkit-linear-gradient(top, #45484d 0%,#000000 100%); background-color: linear-gradient(to bottom, #45484d 0%,#000000 100%);}',
''))
,p_step_template=>wwv_flow_api.id(5011635210344315)
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_browser_cache=>'N'
,p_last_updated_by=>'KIMBERLYN.SOLANO'
,p_last_upd_yyyymmddhh24miss=>'20221121125716'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(5147633332344172)
,p_plug_name=>'Front_End'
,p_region_template_options=>'#DEFAULT#:t-Login-region--headerIcon'
,p_plug_template=>wwv_flow_api.id(5057695117344289)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(5152312025344159)
,p_plug_name=>'Language Selector'
,p_parent_plug_id=>wwv_flow_api.id(5147633332344172)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_api.id(5031545193344301)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_source=>'apex_lang.emit_language_selector_list;'
,p_plug_source_type=>'NATIVE_PLSQL'
,p_plug_query_num_rows=>15
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(5344663426975006)
,p_plug_name=>unistr('Gestionar Contrase\00F1a')
,p_parent_plug_id=>wwv_flow_api.id(5147633332344172)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(5031545193344301)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_plug_source=>unistr('<p><a href="f?p=&APP_ID.:2:&APP_SESSION.:::2:P2_USUARIO:&P9999_USERNAME.">Olvid\00E9 mi contrase\00F1a</a></p>')
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(5150459188344163)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(5344663426975006)
,p_button_name=>'LOGIN'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5121094921344251)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Ingresar'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(29016144882693922)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(5344663426975006)
,p_button_name=>'LOGIN_1'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5121094921344251)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Ingresar'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.::P3_USUARIO:&P9999_USERNAME.'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(98379321487033432)
,p_button_sequence=>80
,p_button_plug_id=>wwv_flow_api.id(5147633332344172)
,p_button_name=>'BTN_SOLICITA_USR'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5121094921344251)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('Solicitar activaci\00F3n ')
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:7:&SESSION.::&DEBUG.::P7_USUARIO:&P9999_USERNAME.'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5148026199344170)
,p_name=>'P9999_USERNAME'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(5147633332344172)
,p_prompt=>'Username'
,p_placeholder=>'Username'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>40
,p_cMaxlength=>100
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_api.id(5119649110344257)
,p_item_icon_css_classes=>'fa-user'
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5148442178344169)
,p_name=>'P9999_PASSWORD'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(5147633332344172)
,p_prompt=>'Password'
,p_placeholder=>'Password'
,p_display_as=>'NATIVE_PASSWORD'
,p_cSize=>40
,p_cMaxlength=>100
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_api.id(5119649110344257)
,p_item_icon_css_classes=>'fa-key'
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5149535209344165)
,p_name=>'P9999_REMEMBER'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(5147633332344172)
,p_prompt=>'Remember username'
,p_display_as=>'NATIVE_CHECKBOX'
,p_named_lov=>'LOGIN_REMEMBER_USERNAME'
,p_lov=>'.'||wwv_flow_api.id(5148759088344169)||'.'
,p_label_alignment=>'RIGHT'
,p_display_when=>'apex_authentication.persistent_cookies_enabled'
,p_display_when_type=>'PLSQL_EXPRESSION'
,p_field_template=>wwv_flow_api.id(5119649110344257)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'If you select this checkbox, the application will save your username in a persistent browser cookie named "LOGIN_USERNAME_COOKIE".',
'When you go to the login page the next time,',
'the username field will be automatically populated with this value.',
'</p>',
'<p>',
'If you deselect this checkbox and your username is already saved in the cookie,',
'the application will overwrite it with an empty value.',
'You can also use your browser''s developer tools to completely remove the cookie.',
'</p>'))
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(29015410389693915)
,p_name=>'P9999_CLAVE_TEMP'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(5147633332344172)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(29017033271693931)
,p_name=>'P9999_ALERTA'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(5147633332344172)
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_tag_attributes=>'style="color:red;"'
,p_field_template=>wwv_flow_api.id(5119973298344255)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(29017148968693932)
,p_name=>'P9999_CONTROLA_ALERTA'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(5147633332344172)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(98379252637033431)
,p_name=>'P9999_SOLICITA_USR'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(5147633332344172)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(29015712014693918)
,p_name=>'DAC_VAL_USR'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P9999_USERNAME'
,p_condition_element=>'P9999_USERNAME'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(29015878189693919)
,p_event_id=>wwv_flow_api.id(29015712014693918)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'vEstado VARCHAR2(1);',
'vValClave BOOLEAN;',
'vmensaje_retorno VARCHAR2(200);',
'vExiste varchar2(255):=''N'';',
'vEstadoUsuario varchar2(3);',
'BEGIN',
' vExiste := FNC_VALIDA_USR (:P9999_USERNAME);',
'',
'--Obtenemos el estado del usuario',
'IF vExiste = ''S'' THEN',
':P9999_CONTROLA_ALERTA := ''N'';',
':P9999_ALERTA := NULL;',
'SELECT CODIGO_ESTADO INTO vEstadoUsuario FROM USUARIOS_EXTERNOS WHERE upper(id_usuario) = upper(:P9999_USERNAME);',
'IF vEstadoUsuario = ''IA'' THEN',
':P9999_CONTROLA_ALERTA := ''S'';',
unistr(':P9999_ALERTA := ''El usuario ya se encuentra inscrito en estado INACTIVO, favor comunicarse con el Departamento de Administraci\00F3n Tributaria del ICT al tel\00E9fono 2299-5892'';'),
':P9999_SOLICITA_USR := ''S'';',
'ELSE',
':P9999_SOLICITA_USR := ''N'';',
'END IF;',
'SELECT ESTADO INTO vEstado FROM USUARIOS_EXTERNOS WHERE upper(id_usuario) = upper(:P9999_USERNAME);',
'ELSE',
':P9999_CONTROLA_ALERTA := ''S'';',
':P9999_ALERTA := ''Usuario no Existe... por favor validar.'';',
'--:P9999_SOLICITA_USR := ''N'';',
'END IF;',
'',
'--Validamos si la clave ya vencio',
'vValClave:= F_CAMBIO_CLAVE_SIT(:P9999_USERNAME,vmensaje_retorno);',
'IF vValClave = TRUE THEN',
'UPDATE USUARIOS_EXTERNOS SET ESTADO = 0 WHERE ID_USUARIO = :P9999_USERNAME;',
'COMMIT;',
'END IF;',
'',
'    IF vEstado = 0 OR vValClave = TRUE THEN',
'        :P9999_CLAVE_TEMP := ''S'';',
'    ELSE',
'        :P9999_CLAVE_TEMP := ''N'';',
'    END IF;',
'END;'))
,p_attribute_02=>'P9999_USERNAME,P9999_SOLICITA_USR'
,p_attribute_03=>'P9999_CLAVE_TEMP,P9999_ALERTA,P9999_CONTROLA_ALERTA,P9999_SOLICITA_USR'
,p_attribute_04=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(29016222564693923)
,p_name=>'DAC_CAMBIAR_PWD'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P9999_CLAVE_TEMP'
,p_condition_element=>'P9999_CLAVE_TEMP'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'S'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(29016303039693924)
,p_event_id=>wwv_flow_api.id(29016222564693923)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_api.id(29016144882693922)
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(29016432165693925)
,p_event_id=>wwv_flow_api.id(29016222564693923)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_api.id(29016144882693922)
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(29016523819693926)
,p_event_id=>wwv_flow_api.id(29016222564693923)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_api.id(5150459188344163)
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(29016680501693927)
,p_event_id=>wwv_flow_api.id(29016222564693923)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_api.id(5150459188344163)
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(29016826894693929)
,p_name=>'DAC_VALIDA_PWD'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P9999_PASSWORD'
,p_condition_element=>'P9999_PASSWORD'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(29016925319693930)
,p_event_id=>wwv_flow_api.id(29016826894693929)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'vClave_Actual varchar2(255);',
'BEGIN',
' SELECT F_OBTIENE_CLAVE_EXTERNOS(id_usuario) INTO vClave_Actual FROM USUARIOS_EXTERNOS WHERE ID_USUARIO = UPPER(:P9999_USERNAME);',
' IF vClave_Actual <> :P9999_PASSWORD THEN',
' :P9999_CONTROLA_ALERTA := ''S'';',
unistr(' :P9999_ALERTA := ''La contrase\00F1a actual es incorrecta... por favor verifique'';'),
' ELSE',
' :P9999_CONTROLA_ALERTA := ''N'';',
' :P9999_ALERTA := NULL;',
' END IF;',
'END;'))
,p_attribute_02=>'P9999_USERNAME,P9999_PASSWORD'
,p_attribute_03=>'P9999_CONTROLA_ALERTA,P9999_ALERTA'
,p_attribute_04=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(29017299802693933)
,p_name=>'DAC_ALERTA'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P9999_CONTROLA_ALERTA'
,p_condition_element=>'P9999_CONTROLA_ALERTA'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'S'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(29017347458693934)
,p_event_id=>wwv_flow_api.id(29017299802693933)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P9999_ALERTA'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(29017478179693935)
,p_event_id=>wwv_flow_api.id(29017299802693933)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P9999_ALERTA'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(43139355553105948)
,p_event_id=>wwv_flow_api.id(29017299802693933)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(5344663426975006)
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(43139411709105949)
,p_event_id=>wwv_flow_api.id(29017299802693933)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(5344663426975006)
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(98379424893033433)
,p_name=>'DAC_SOLICITA_USR'
,p_event_sequence=>50
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P9999_SOLICITA_USR'
,p_condition_element=>'P9999_SOLICITA_USR'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'S'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(98379537274033434)
,p_event_id=>wwv_flow_api.id(98379424893033433)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_api.id(98379321487033432)
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(98379616937033435)
,p_event_id=>wwv_flow_api.id(98379424893033433)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_api.id(98379321487033432)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(5151236297344160)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Set Username Cookie'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex_authentication.send_login_username_cookie (',
'    p_username => lower(:P9999_USERNAME),',
'    p_consent  => :P9999_REMEMBER = ''Y'' );'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(5150858258344161)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Login'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex_authentication.login(',
'    p_username => :P9999_USERNAME,',
'    p_password => :P9999_PASSWORD );'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(5152094345344159)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'Clear Page(s) Cache'
,p_attribute_01=>'CLEAR_CACHE_CURRENT_PAGE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(5151650138344160)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Get Username Cookie'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P9999_USERNAME := apex_authentication.get_login_username_cookie;',
':P9999_REMEMBER := case when :P9999_USERNAME is not null then ''Y'' end;'))
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(29016788308693928)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_DATOS'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
':P9999_CLAVE_TEMP := NULL;',
':P9999_CONTROLA_ALERTA := NULL;',
':P9999_ALERTA := NULL;',
':P9999_SOLICITA_USR := NULL;',
'END;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
