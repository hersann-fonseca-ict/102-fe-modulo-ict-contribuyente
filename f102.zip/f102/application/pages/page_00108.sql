prompt --application/pages/page_00108
begin
--   Manifest
--     PAGE: 00108
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>5801312104779619
,p_default_application_id=>102
,p_default_id_offset=>0
,p_default_owner=>'DESA_SIT'
);
wwv_flow_api.create_page(
 p_id=>108
,p_user_interface_id=>wwv_flow_api.id(5143571665344221)
,p_name=>unistr('VI. Autorizaci\00F3n Uso Firma Digital')
,p_alias=>unistr('VI-AUTORIZACI\00D3N-USO-FIRMA-DIGITAL')
,p_step_title=>unistr('Autorizaci\00F3n Uso Firma Digital')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_browser_cache=>'N'
,p_last_updated_by=>'KIMBERLYN.SOLANO'
,p_last_upd_yyyymmddhh24miss=>'20230704141955'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(5431946736363331)
,p_plug_name=>unistr('VI. Autorizaci\00F3n Uso Firma Digital')
,p_region_template_options=>'#DEFAULT#:t-Wizard--hideStepsXSmall'
,p_plug_template=>wwv_flow_api.id(5069356128344283)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_list_id=>wwv_flow_api.id(5407085389363356)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_api.id(5098266341344267)
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(5432089455363331)
,p_plug_name=>unistr('VI. Autorizaci\00F3n Uso Firma Digital')
,p_parent_plug_id=>wwv_flow_api.id(5431946736363331)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(5031545193344301)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(6485563896953636)
,p_plug_name=>unistr('Autorizaci\00F3n Uso Firma Digital en declaraciones juradas')
,p_parent_plug_id=>wwv_flow_api.id(5432089455363331)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(5058998562344289)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(103594720014110343)
,p_plug_name=>'Apoderado1'
,p_parent_plug_id=>wwv_flow_api.id(6485563896953636)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(5058998562344289)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(103594841715110344)
,p_plug_name=>'Apoderado2'
,p_parent_plug_id=>wwv_flow_api.id(6485563896953636)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(5058998562344289)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(103594972815110345)
,p_plug_name=>'Apoderado3'
,p_parent_plug_id=>wwv_flow_api.id(6485563896953636)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(5058998562344289)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(6485617766953637)
,p_plug_name=>'Autorizo a terceras personas'
,p_parent_plug_id=>wwv_flow_api.id(5432089455363331)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(5058998562344289)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(5433921356363330)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(5431946736363331)
,p_button_name=>'PREVIOUS'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5121094921344251)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Regresar'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_button_execute_validations=>'N'
,p_icon_css_classes=>'fa-angle-double-left'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(5434026645363330)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(5431946736363331)
,p_button_name=>'NEXT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5121094921344251)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Siguiente'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_icon_css_classes=>'fa-angle-double-right'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(5433757342363330)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(5431946736363331)
,p_button_name=>'CANCEL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5121094921344251)
,p_button_image_alt=>'Cancelar'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:1:&APP_SESSION.::&DEBUG.:::'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(5435481769363329)
,p_branch_name=>'Go To Page 109'
,p_branch_action=>'f?p=&APP_ID.:109:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(5434026645363330)
,p_branch_sequence=>20
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(5434785581363330)
,p_branch_action=>'f?p=&APP_ID.:107:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_VALIDATION'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(5433921356363330)
,p_branch_sequence=>10
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5433406369363330)
,p_name=>'P108_NOM_APODERADO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(103594720014110343)
,p_prompt=>'Nombre Completo:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>50
,p_field_template=>wwv_flow_api.id(5119886074344255)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6484526435953626)
,p_name=>'P108_CEDULA_APRODERADO'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(103594720014110343)
,p_prompt=>unistr('N\00B0 C\00E9dula/ID:')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(5119886074344255)
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>unistr('Por favor ingresar el n\00FAmero de c\00E9dula sin espacios y sin guiones ejemplo (102220333).')
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6484646243953627)
,p_name=>'P108_IMPUESTO_FIRMAR'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(103594720014110343)
,p_prompt=>'Impuesto a firmar:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT PKG_MAESTRO_CONTRIBUYENTE.RETORNA_DESCRIP_TIPO_IMPUESTO (ID_TIPO_IMPUESTO)NOM_IMPUESTO,',
'ID_TIPO_IMPUESTO',
'FROM TIPO_IMPUESTO_CONTRIB',
'WHERE ID_TIPO_CONTRIB = :P102_TIPO_CONTRIBUYENTE',
'AND   ID_TIPO_IMPUESTO IN (:P104_TIP_IMPUESTO,:P104_TIP_IMPUESTO_1,:P104_TIP_IMPUESTO_2)'))
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(5119886074344255)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6484753521953628)
,p_name=>'P108_EMAIL_APODERADO'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(103594720014110343)
,p_prompt=>unistr('Correo electr\00F3nico:')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(5119886074344255)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6484845669953629)
,p_name=>'P108_NOM_APODERADO_1'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(103594841715110344)
,p_prompt=>'Nombre Completo:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>50
,p_field_template=>wwv_flow_api.id(5119886074344255)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6484951901953630)
,p_name=>'P108_CEDULA_APRODERADO_1'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(103594841715110344)
,p_prompt=>unistr('N\00B0 C\00E9dula/ID:')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(5119886074344255)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6485019735953631)
,p_name=>'P108_EMAIL_APODERADO_1'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_api.id(103594841715110344)
,p_prompt=>unistr('Correo electr\00F3nico:')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(5119886074344255)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6485194913953632)
,p_name=>'P108_NOM_APODERADO_2'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_api.id(103594972815110345)
,p_prompt=>'Nombre Completo:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>50
,p_field_template=>wwv_flow_api.id(5119886074344255)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6485262227953633)
,p_name=>'P108_CEDULA_APRODERADO_2'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_api.id(103594972815110345)
,p_prompt=>unistr('N\00B0 C\00E9dula/ID:')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(5119886074344255)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6485362560953634)
,p_name=>'P108_EMAIL_APODERADO_2'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_api.id(103594972815110345)
,p_prompt=>unistr('Correo electr\00F3nico:')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(5119886074344255)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6485798451953638)
,p_name=>'P108_FIRMA_APODERADO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(103594720014110343)
,p_prompt=>unistr('Firma solo apoderado (s) o Due\00F1o:')
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:Si;S'
,p_field_template=>wwv_flow_api.id(5119791289344256)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6486076050953641)
,p_name=>'P108_TERCEROS'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_api.id(103594972815110345)
,p_prompt=>'Autorizo a terceras personas y adjunto el poder legal correspondiente'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:Si;S'
,p_field_template=>wwv_flow_api.id(5119791289344256)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_warn_on_unsaved_changes=>'I'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6486481493953645)
,p_name=>'P108_IMP_FIRMAR_T'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(6485617766953637)
,p_prompt=>'Impuesto a firmar:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT PKG_MAESTRO_CONTRIBUYENTE.RETORNA_DESCRIP_TIPO_IMPUESTO (ID_TIPO_IMPUESTO)NOM_IMPUESTO,',
'ID_TIPO_IMPUESTO',
'FROM TIPO_IMPUESTO_CONTRIB',
'WHERE ID_TIPO_CONTRIB = :P102_TIPO_CONTRIBUYENTE',
'AND   ID_TIPO_IMPUESTO IN (:P104_TIP_IMPUESTO,:P104_TIP_IMPUESTO_1,:P104_TIP_IMPUESTO_2)'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(5119886074344255)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6486521470953646)
,p_name=>'P108_NOM_APO_T'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(6485617766953637)
,p_prompt=>'Nombre Completo:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>50
,p_field_template=>wwv_flow_api.id(5119886074344255)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6486628162953647)
,p_name=>'P108_CED_APO_T'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(6485617766953637)
,p_prompt=>unistr('N\00B0 C\00E9dula/ID:')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_grid_column=>4
,p_field_template=>wwv_flow_api.id(5119886074344255)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_help_text=>unistr('Por favor ingresar el n\00FAmero de c\00E9dula sin espacios y sin guiones ejemplo (102220333).')
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6486755262953648)
,p_name=>'P108_EMAIL_APO_T'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(6485617766953637)
,p_prompt=>unistr('Correo electr\00F3nico:')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_grid_column=>6
,p_field_template=>wwv_flow_api.id(5119886074344255)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6486872743953649)
,p_name=>'P108_NOM_APO_T_1'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_api.id(6485617766953637)
,p_prompt=>'Nombre Completo:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>50
,p_field_template=>wwv_flow_api.id(5119886074344255)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6486907745953650)
,p_name=>'P108_CED_APO_T_1'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_api.id(6485617766953637)
,p_prompt=>unistr('N\00B0 C\00E9dula/ID:')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_grid_column=>4
,p_field_template=>wwv_flow_api.id(5119886074344255)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6604744590928901)
,p_name=>'P108_EMAIL_APO_T_1'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_api.id(6485617766953637)
,p_prompt=>unistr('Correo electr\00F3nico:')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_grid_column=>6
,p_field_template=>wwv_flow_api.id(5119886074344255)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6604853129928902)
,p_name=>'P108_IMP_FIRMAR_T_1'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_api.id(6485617766953637)
,p_prompt=>'Impuesto a firmar:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT PKG_MAESTRO_CONTRIBUYENTE.RETORNA_DESCRIP_TIPO_IMPUESTO (ID_TIPO_IMPUESTO)NOM_IMPUESTO,',
'ID_TIPO_IMPUESTO',
'FROM TIPO_IMPUESTO_CONTRIB',
'WHERE ID_TIPO_CONTRIB = :P102_TIPO_CONTRIBUYENTE',
'AND   ID_TIPO_IMPUESTO IN (:P104_TIP_IMPUESTO,:P104_TIP_IMPUESTO_1,:P104_TIP_IMPUESTO_2)'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(5119886074344255)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6604987933928903)
,p_name=>'P108_NOM_APO_T_2'
,p_item_sequence=>210
,p_item_plug_id=>wwv_flow_api.id(6485617766953637)
,p_prompt=>'Nombre Completo:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>50
,p_field_template=>wwv_flow_api.id(5119886074344255)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6605089998928904)
,p_name=>'P108_CED_APO_T_2'
,p_item_sequence=>220
,p_item_plug_id=>wwv_flow_api.id(6485617766953637)
,p_prompt=>unistr('N\00B0 C\00E9dula/ID:')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_grid_column=>4
,p_field_template=>wwv_flow_api.id(5119886074344255)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6605140409928905)
,p_name=>'P108_EMAIL_APO_T_2'
,p_item_sequence=>230
,p_item_plug_id=>wwv_flow_api.id(6485617766953637)
,p_prompt=>unistr('Correo electr\00F3nico:')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_grid_column=>6
,p_field_template=>wwv_flow_api.id(5119886074344255)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6605226446928906)
,p_name=>'P108_IMP_FIRMAR_T_2'
,p_item_sequence=>260
,p_item_plug_id=>wwv_flow_api.id(6485617766953637)
,p_prompt=>'Impuesto a firmar:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT PKG_MAESTRO_CONTRIBUYENTE.RETORNA_DESCRIP_TIPO_IMPUESTO (ID_TIPO_IMPUESTO)NOM_IMPUESTO,',
'ID_TIPO_IMPUESTO',
'FROM TIPO_IMPUESTO_CONTRIB',
'WHERE ID_TIPO_CONTRIB = :P102_TIPO_CONTRIBUYENTE',
'AND   ID_TIPO_IMPUESTO IN (:P104_TIP_IMPUESTO,:P104_TIP_IMPUESTO_1,:P104_TIP_IMPUESTO_2)'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(5119886074344255)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6605376422928907)
,p_name=>'P108_NOM_APO_T_3'
,p_item_sequence=>290
,p_item_plug_id=>wwv_flow_api.id(6485617766953637)
,p_prompt=>'Nombre Completo:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>50
,p_field_template=>wwv_flow_api.id(5119886074344255)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6605433123928908)
,p_name=>'P108_CED_APO_T_3'
,p_item_sequence=>300
,p_item_plug_id=>wwv_flow_api.id(6485617766953637)
,p_prompt=>unistr('N\00B0 C\00E9dula/ID:')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_grid_column=>4
,p_field_template=>wwv_flow_api.id(5119886074344255)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6605585671928909)
,p_name=>'P108_EMAIL_APO_T_3'
,p_item_sequence=>310
,p_item_plug_id=>wwv_flow_api.id(6485617766953637)
,p_prompt=>unistr('Correo electr\00F3nico:')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_grid_column=>6
,p_field_template=>wwv_flow_api.id(5119886074344255)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6605636485928910)
,p_name=>'P108_IMP_FIRMAR_T_3'
,p_item_sequence=>350
,p_item_plug_id=>wwv_flow_api.id(6485617766953637)
,p_prompt=>'Impuesto a firmar:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT PKG_MAESTRO_CONTRIBUYENTE.RETORNA_DESCRIP_TIPO_IMPUESTO (ID_TIPO_IMPUESTO)NOM_IMPUESTO,',
'ID_TIPO_IMPUESTO',
'FROM TIPO_IMPUESTO_CONTRIB',
'WHERE ID_TIPO_CONTRIB = :P102_TIPO_CONTRIBUYENTE',
'AND   ID_TIPO_IMPUESTO IN (:P104_TIP_IMPUESTO,:P104_TIP_IMPUESTO_1,:P104_TIP_IMPUESTO_2)'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(5119886074344255)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6605748205928911)
,p_name=>'P108_IMPUESTO_FIRMAR_1'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_api.id(103594841715110344)
,p_prompt=>'Impuesto a firmar:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT PKG_MAESTRO_CONTRIBUYENTE.RETORNA_DESCRIP_TIPO_IMPUESTO (ID_TIPO_IMPUESTO)NOM_IMPUESTO,',
'ID_TIPO_IMPUESTO',
'FROM TIPO_IMPUESTO_CONTRIB',
'WHERE ID_TIPO_CONTRIB = :P102_TIPO_CONTRIBUYENTE',
'AND   ID_TIPO_IMPUESTO IN (:P104_TIP_IMPUESTO,:P104_TIP_IMPUESTO_1,:P104_TIP_IMPUESTO_2)'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(5119886074344255)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6605821789928912)
,p_name=>'P108_IMPUESTO_FIRMAR_2'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_api.id(103594972815110345)
,p_prompt=>'Impuesto a firmar:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT PKG_MAESTRO_CONTRIBUYENTE.RETORNA_DESCRIP_TIPO_IMPUESTO (ID_TIPO_IMPUESTO)NOM_IMPUESTO,',
'ID_TIPO_IMPUESTO',
'FROM TIPO_IMPUESTO_CONTRIB',
'WHERE ID_TIPO_CONTRIB = :P102_TIPO_CONTRIBUYENTE',
'AND   ID_TIPO_IMPUESTO IN (:P104_TIP_IMPUESTO,:P104_TIP_IMPUESTO_1,:P104_TIP_IMPUESTO_2)'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(5119886074344255)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6605978894928913)
,p_name=>'P108_NOM_APO_T_4'
,p_item_sequence=>380
,p_item_plug_id=>wwv_flow_api.id(6485617766953637)
,p_prompt=>'Nombre Completo:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>50
,p_field_template=>wwv_flow_api.id(5119886074344255)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6606093737928914)
,p_name=>'P108_CED_APO_T_4'
,p_item_sequence=>390
,p_item_plug_id=>wwv_flow_api.id(6485617766953637)
,p_prompt=>unistr('N\00B0 C\00E9dula/ID:')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_grid_column=>4
,p_field_template=>wwv_flow_api.id(5119886074344255)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6606162799928915)
,p_name=>'P108_EMAIL_APO_T_4'
,p_item_sequence=>400
,p_item_plug_id=>wwv_flow_api.id(6485617766953637)
,p_prompt=>unistr('Correo electr\00F3nico:')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_grid_column=>6
,p_field_template=>wwv_flow_api.id(5119886074344255)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6606285664928916)
,p_name=>'P108_IMP_FIRMAR_T_4'
,p_item_sequence=>430
,p_item_plug_id=>wwv_flow_api.id(6485617766953637)
,p_prompt=>'Impuesto a firmar:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT PKG_MAESTRO_CONTRIBUYENTE.RETORNA_DESCRIP_TIPO_IMPUESTO (ID_TIPO_IMPUESTO)NOM_IMPUESTO,',
'ID_TIPO_IMPUESTO',
'FROM TIPO_IMPUESTO_CONTRIB',
'WHERE ID_TIPO_CONTRIB = :P102_TIPO_CONTRIBUYENTE',
'AND   ID_TIPO_IMPUESTO IN (:P104_TIP_IMPUESTO,:P104_TIP_IMPUESTO_1,:P104_TIP_IMPUESTO_2)'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(5119886074344255)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6606301258928917)
,p_name=>'P108_NOM_APO_T_5'
,p_item_sequence=>460
,p_item_plug_id=>wwv_flow_api.id(6485617766953637)
,p_prompt=>'Nombre Completo:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>50
,p_field_template=>wwv_flow_api.id(5119886074344255)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6606488555928918)
,p_name=>'P108_CED_APO_T_5'
,p_item_sequence=>470
,p_item_plug_id=>wwv_flow_api.id(6485617766953637)
,p_prompt=>unistr('N\00B0 C\00E9dula/ID:')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_grid_column=>4
,p_field_template=>wwv_flow_api.id(5119886074344255)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6606546203928919)
,p_name=>'P108_EMAIL_APO_T_5'
,p_item_sequence=>480
,p_item_plug_id=>wwv_flow_api.id(6485617766953637)
,p_prompt=>unistr('Correo electr\00F3nico:')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_grid_column=>6
,p_field_template=>wwv_flow_api.id(5119886074344255)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6606662101928920)
,p_name=>'P108_IMP_FIRMAR_T_5'
,p_item_sequence=>520
,p_item_plug_id=>wwv_flow_api.id(6485617766953637)
,p_prompt=>'Impuesto a firmar:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT PKG_MAESTRO_CONTRIBUYENTE.RETORNA_DESCRIP_TIPO_IMPUESTO (ID_TIPO_IMPUESTO)NOM_IMPUESTO,',
'ID_TIPO_IMPUESTO',
'FROM TIPO_IMPUESTO_CONTRIB',
'WHERE ID_TIPO_CONTRIB = :P102_TIPO_CONTRIBUYENTE',
'AND   ID_TIPO_IMPUESTO IN (:P104_TIP_IMPUESTO,:P104_TIP_IMPUESTO_1,:P104_TIP_IMPUESTO_2)'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(5119886074344255)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(13252653117850215)
,p_name=>'P108_PODER_LEGAL'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(6485617766953637)
,p_prompt=>'Cedula'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>15
,p_tag_attributes=>'accept=".pdf,.jpeg,.png"'
,p_begin_on_new_line=>'N'
,p_grid_column=>8
,p_field_template=>wwv_flow_api.id(5119886074344255)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(13252748819850216)
,p_name=>'P108_PODER_LEGAL_1'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_api.id(6485617766953637)
,p_prompt=>'Cedula'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_tag_attributes=>'accept=".pdf,.jpeg,.png"'
,p_begin_on_new_line=>'N'
,p_grid_column=>8
,p_field_template=>wwv_flow_api.id(5119886074344255)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(13252846214850217)
,p_name=>'P108_PODER_LEGAL_2'
,p_item_sequence=>240
,p_item_plug_id=>wwv_flow_api.id(6485617766953637)
,p_prompt=>'Cedula'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_tag_attributes=>'accept=".pdf,.jpeg,.png"'
,p_begin_on_new_line=>'N'
,p_grid_column=>8
,p_field_template=>wwv_flow_api.id(5119886074344255)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(13252999554850218)
,p_name=>'P108_PODER_LEGAL_3'
,p_item_sequence=>330
,p_item_plug_id=>wwv_flow_api.id(6485617766953637)
,p_prompt=>'Cedula'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_tag_attributes=>'accept=".pdf,.jpeg,.png"'
,p_begin_on_new_line=>'N'
,p_grid_column=>8
,p_field_template=>wwv_flow_api.id(5119886074344255)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(13253076938850219)
,p_name=>'P108_PODER_LEGAL_4'
,p_item_sequence=>410
,p_item_plug_id=>wwv_flow_api.id(6485617766953637)
,p_prompt=>'Cedula'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_tag_attributes=>'accept=".pdf,.jpeg,.png"'
,p_begin_on_new_line=>'N'
,p_grid_column=>8
,p_field_template=>wwv_flow_api.id(5119886074344255)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(13253174999850220)
,p_name=>'P108_PODER_LEGAL_5'
,p_item_sequence=>500
,p_item_plug_id=>wwv_flow_api.id(6485617766953637)
,p_prompt=>'Cedula'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_tag_attributes=>'accept=".pdf,.jpeg,.png"'
,p_begin_on_new_line=>'N'
,p_grid_column=>8
,p_field_template=>wwv_flow_api.id(5119886074344255)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(34487165786508227)
,p_name=>'P108_PODER_ESPECIAL'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(6485617766953637)
,p_prompt=>'Poder Especial'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_tag_attributes=>'accept=".pdf,.jpeg,.png"'
,p_begin_on_new_line=>'N'
,p_grid_column=>11
,p_field_template=>wwv_flow_api.id(5119886074344255)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(34487298386508228)
,p_name=>'P108_PODER_ESPECIAL_1'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_api.id(6485617766953637)
,p_prompt=>'Poder Especial'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_tag_attributes=>'accept=".pdf,.jpeg,.png"'
,p_begin_on_new_line=>'N'
,p_grid_column=>11
,p_field_template=>wwv_flow_api.id(5119886074344255)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>5801312104779619
,p_default_application_id=>102
,p_default_id_offset=>0
,p_default_owner=>'DESA_SIT'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(34487337605508229)
,p_name=>'P108_PODER_ESPECIAL_2'
,p_item_sequence=>250
,p_item_plug_id=>wwv_flow_api.id(6485617766953637)
,p_prompt=>'Poder Especial'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_tag_attributes=>'accept=".pdf,.jpeg,.png"'
,p_begin_on_new_line=>'N'
,p_grid_column=>11
,p_field_template=>wwv_flow_api.id(5119886074344255)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(34487411404508230)
,p_name=>'P108_PODER_ESPECIAL_3'
,p_item_sequence=>340
,p_item_plug_id=>wwv_flow_api.id(6485617766953637)
,p_prompt=>'Poder Especial'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_tag_attributes=>'accept=".pdf,.jpeg,.png"'
,p_begin_on_new_line=>'N'
,p_grid_column=>11
,p_field_template=>wwv_flow_api.id(5119886074344255)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(34487537893508231)
,p_name=>'P108_PODER_ESPECIAL_4'
,p_item_sequence=>420
,p_item_plug_id=>wwv_flow_api.id(6485617766953637)
,p_prompt=>'Poder Especial'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_tag_attributes=>'accept=".pdf,.jpeg,.png"'
,p_begin_on_new_line=>'N'
,p_grid_column=>11
,p_field_template=>wwv_flow_api.id(5119886074344255)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(34487629439508232)
,p_name=>'P108_PODER_ESPECIAL_5'
,p_item_sequence=>510
,p_item_plug_id=>wwv_flow_api.id(6485617766953637)
,p_prompt=>'Poder Especial'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_tag_attributes=>'accept=".pdf,.jpeg,.png"'
,p_begin_on_new_line=>'N'
,p_grid_column=>11
,p_field_template=>wwv_flow_api.id(5119886074344255)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(43035330308942048)
,p_name=>'P108_TEXTO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(103594720014110343)
,p_item_default=>unistr('El suscrito como due\00F1o (a) o apoderado (a) y con facultades suficientes para este acto, solicit\00F3 firmar digitalmente las declaraciones juradas de impuestos del ICT conforme se\00F1alo a continuaci\00F3n:')
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(5119973298344255)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(103594542887110341)
,p_name=>'P108_IMPUESTO_FIRMAR_3'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(103594720014110343)
,p_prompt=>'Impuesto a firmar:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT PKG_MAESTRO_CONTRIBUYENTE.RETORNA_DESCRIP_TIPO_IMPUESTO (ID_TIPO_IMPUESTO)NOM_IMPUESTO,',
'ID_TIPO_IMPUESTO',
'FROM TIPO_IMPUESTO_CONTRIB',
'WHERE ID_TIPO_CONTRIB = :P102_TIPO_CONTRIBUYENTE',
'AND   ID_TIPO_IMPUESTO IN (:P104_TIP_IMPUESTO,:P104_TIP_IMPUESTO_1,:P104_TIP_IMPUESTO_2)'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_grid_column=>5
,p_display_when=>'P108_CANT_IMPUESTO'
,p_display_when2=>'1'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_NOT_EQ_COND2'
,p_field_template=>wwv_flow_api.id(5119886074344255)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(103594699009110342)
,p_name=>'P108_IMPUESTO_FIRMAR_4'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(103594720014110343)
,p_prompt=>'Impuesto a firmar:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT PKG_MAESTRO_CONTRIBUYENTE.RETORNA_DESCRIP_TIPO_IMPUESTO (ID_TIPO_IMPUESTO)NOM_IMPUESTO,',
'ID_TIPO_IMPUESTO',
'FROM TIPO_IMPUESTO_CONTRIB',
'WHERE ID_TIPO_CONTRIB = :P102_TIPO_CONTRIBUYENTE',
'AND   ID_TIPO_IMPUESTO IN (:P104_TIP_IMPUESTO,:P104_TIP_IMPUESTO_1,:P104_TIP_IMPUESTO_2)'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_display_when=>'P108_CANT_IMPUESTO'
,p_display_when2=>'3'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_api.id(5119886074344255)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(103595126496110347)
,p_name=>'P108_IMPUESTO_FIRMAR_5'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_api.id(103594841715110344)
,p_prompt=>'Impuesto a firmar:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT PKG_MAESTRO_CONTRIBUYENTE.RETORNA_DESCRIP_TIPO_IMPUESTO (ID_TIPO_IMPUESTO)NOM_IMPUESTO,',
'ID_TIPO_IMPUESTO',
'FROM TIPO_IMPUESTO_CONTRIB',
'WHERE ID_TIPO_CONTRIB = :P102_TIPO_CONTRIBUYENTE',
'AND   ID_TIPO_IMPUESTO IN (:P104_TIP_IMPUESTO,:P104_TIP_IMPUESTO_1,:P104_TIP_IMPUESTO_2)'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_grid_column=>5
,p_display_when=>'P108_CANT_IMPUESTO'
,p_display_when2=>'1'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_NOT_EQ_COND2'
,p_field_template=>wwv_flow_api.id(5119886074344255)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(103595229897110348)
,p_name=>'P108_IMPUESTO_FIRMAR_6'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_api.id(103594841715110344)
,p_prompt=>'Impuesto a firmar:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT PKG_MAESTRO_CONTRIBUYENTE.RETORNA_DESCRIP_TIPO_IMPUESTO (ID_TIPO_IMPUESTO)NOM_IMPUESTO,',
'ID_TIPO_IMPUESTO',
'FROM TIPO_IMPUESTO_CONTRIB',
'WHERE ID_TIPO_CONTRIB = :P102_TIPO_CONTRIBUYENTE',
'AND   ID_TIPO_IMPUESTO IN (:P104_TIP_IMPUESTO,:P104_TIP_IMPUESTO_1,:P104_TIP_IMPUESTO_2)'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_display_when=>'P108_CANT_IMPUESTO'
,p_display_when2=>'3'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_api.id(5119886074344255)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(103595367273110349)
,p_name=>'P108_IMPUESTO_FIRMAR_7'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_api.id(103594972815110345)
,p_prompt=>'Impuesto a firmar:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT PKG_MAESTRO_CONTRIBUYENTE.RETORNA_DESCRIP_TIPO_IMPUESTO (ID_TIPO_IMPUESTO)NOM_IMPUESTO,',
'ID_TIPO_IMPUESTO',
'FROM TIPO_IMPUESTO_CONTRIB',
'WHERE ID_TIPO_CONTRIB = :P102_TIPO_CONTRIBUYENTE',
'AND   ID_TIPO_IMPUESTO IN (:P104_TIP_IMPUESTO,:P104_TIP_IMPUESTO_1,:P104_TIP_IMPUESTO_2)'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_grid_column=>5
,p_display_when=>'P108_CANT_IMPUESTO'
,p_display_when2=>'1'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_NOT_EQ_COND2'
,p_field_template=>wwv_flow_api.id(5119886074344255)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(103595491592110350)
,p_name=>'P108_IMPUESTO_FIRMAR_8'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_api.id(103594972815110345)
,p_prompt=>'Impuesto a firmar:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT PKG_MAESTRO_CONTRIBUYENTE.RETORNA_DESCRIP_TIPO_IMPUESTO (ID_TIPO_IMPUESTO)NOM_IMPUESTO,',
'ID_TIPO_IMPUESTO',
'FROM TIPO_IMPUESTO_CONTRIB',
'WHERE ID_TIPO_CONTRIB = :P102_TIPO_CONTRIBUYENTE',
'AND   ID_TIPO_IMPUESTO IN (:P104_TIP_IMPUESTO,:P104_TIP_IMPUESTO_1,:P104_TIP_IMPUESTO_2)'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_display_when=>'P108_CANT_IMPUESTO'
,p_display_when2=>'3'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_api.id(5119886074344255)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(110607940659197301)
,p_name=>'P108_IMP_FIRMAR_T_6'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_api.id(6485617766953637)
,p_prompt=>'Impuesto a firmar:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT PKG_MAESTRO_CONTRIBUYENTE.RETORNA_DESCRIP_TIPO_IMPUESTO (ID_TIPO_IMPUESTO)NOM_IMPUESTO,',
'ID_TIPO_IMPUESTO',
'FROM TIPO_IMPUESTO_CONTRIB',
'WHERE ID_TIPO_CONTRIB = :P102_TIPO_CONTRIBUYENTE',
'AND   ID_TIPO_IMPUESTO IN (:P104_TIP_IMPUESTO,:P104_TIP_IMPUESTO_1,:P104_TIP_IMPUESTO_2)'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_grid_column=>6
,p_display_when=>'P108_CANT_IMPUESTO'
,p_display_when2=>'3'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_api.id(5119886074344255)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(110608088596197302)
,p_name=>'P108_IMP_FIRMAR_T_7'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_api.id(6485617766953637)
,p_prompt=>'Impuesto a firmar:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT PKG_MAESTRO_CONTRIBUYENTE.RETORNA_DESCRIP_TIPO_IMPUESTO (ID_TIPO_IMPUESTO)NOM_IMPUESTO,',
'ID_TIPO_IMPUESTO',
'FROM TIPO_IMPUESTO_CONTRIB',
'WHERE ID_TIPO_CONTRIB = :P102_TIPO_CONTRIBUYENTE',
'AND   ID_TIPO_IMPUESTO IN (:P104_TIP_IMPUESTO,:P104_TIP_IMPUESTO_1,:P104_TIP_IMPUESTO_2)'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_grid_column=>4
,p_display_when=>'P108_CANT_IMPUESTO'
,p_display_when2=>'1'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_NOT_EQ_COND2'
,p_field_template=>wwv_flow_api.id(5119886074344255)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(110608158874197303)
,p_name=>'P108_IMP_FIRMAR_T_8'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_api.id(6485617766953637)
,p_prompt=>'Impuesto a firmar:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT PKG_MAESTRO_CONTRIBUYENTE.RETORNA_DESCRIP_TIPO_IMPUESTO (ID_TIPO_IMPUESTO)NOM_IMPUESTO,',
'ID_TIPO_IMPUESTO',
'FROM TIPO_IMPUESTO_CONTRIB',
'WHERE ID_TIPO_CONTRIB = :P102_TIPO_CONTRIBUYENTE',
'AND   ID_TIPO_IMPUESTO IN (:P104_TIP_IMPUESTO,:P104_TIP_IMPUESTO_1,:P104_TIP_IMPUESTO_2)'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_grid_column=>4
,p_display_when=>'P108_CANT_IMPUESTO'
,p_display_when2=>'1'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_NOT_EQ_COND2'
,p_field_template=>wwv_flow_api.id(5119886074344255)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(110608225891197304)
,p_name=>'P108_IMP_FIRMAR_T_9'
,p_item_sequence=>200
,p_item_plug_id=>wwv_flow_api.id(6485617766953637)
,p_prompt=>'Impuesto a firmar:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT PKG_MAESTRO_CONTRIBUYENTE.RETORNA_DESCRIP_TIPO_IMPUESTO (ID_TIPO_IMPUESTO)NOM_IMPUESTO,',
'ID_TIPO_IMPUESTO',
'FROM TIPO_IMPUESTO_CONTRIB',
'WHERE ID_TIPO_CONTRIB = :P102_TIPO_CONTRIBUYENTE',
'AND   ID_TIPO_IMPUESTO IN (:P104_TIP_IMPUESTO,:P104_TIP_IMPUESTO_1,:P104_TIP_IMPUESTO_2)'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_grid_column=>6
,p_display_when=>'P108_CANT_IMPUESTO'
,p_display_when2=>'3'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_api.id(5119886074344255)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(110608304108197305)
,p_name=>'P108_IMP_FIRMAR_T_10'
,p_item_sequence=>270
,p_item_plug_id=>wwv_flow_api.id(6485617766953637)
,p_prompt=>'Impuesto a firmar:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT PKG_MAESTRO_CONTRIBUYENTE.RETORNA_DESCRIP_TIPO_IMPUESTO (ID_TIPO_IMPUESTO)NOM_IMPUESTO,',
'ID_TIPO_IMPUESTO',
'FROM TIPO_IMPUESTO_CONTRIB',
'WHERE ID_TIPO_CONTRIB = :P102_TIPO_CONTRIBUYENTE',
'AND   ID_TIPO_IMPUESTO IN (:P104_TIP_IMPUESTO,:P104_TIP_IMPUESTO_1,:P104_TIP_IMPUESTO_2)'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_grid_column=>4
,p_display_when=>'P108_CANT_IMPUESTO'
,p_display_when2=>'1'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_NOT_EQ_COND2'
,p_field_template=>wwv_flow_api.id(5119886074344255)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(110608472130197306)
,p_name=>'P108_IMP_FIRMAR_T_11'
,p_item_sequence=>280
,p_item_plug_id=>wwv_flow_api.id(6485617766953637)
,p_prompt=>'Impuesto a firmar:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT PKG_MAESTRO_CONTRIBUYENTE.RETORNA_DESCRIP_TIPO_IMPUESTO (ID_TIPO_IMPUESTO)NOM_IMPUESTO,',
'ID_TIPO_IMPUESTO',
'FROM TIPO_IMPUESTO_CONTRIB',
'WHERE ID_TIPO_CONTRIB = :P102_TIPO_CONTRIBUYENTE',
'AND   ID_TIPO_IMPUESTO IN (:P104_TIP_IMPUESTO,:P104_TIP_IMPUESTO_1,:P104_TIP_IMPUESTO_2)'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_grid_column=>6
,p_display_when=>'P108_CANT_IMPUESTO'
,p_display_when2=>'3'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_api.id(5119886074344255)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(110608512011197307)
,p_name=>'P108_IMP_FIRMAR_T_12'
,p_item_sequence=>360
,p_item_plug_id=>wwv_flow_api.id(6485617766953637)
,p_prompt=>'Impuesto a firmar:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT PKG_MAESTRO_CONTRIBUYENTE.RETORNA_DESCRIP_TIPO_IMPUESTO (ID_TIPO_IMPUESTO)NOM_IMPUESTO,',
'ID_TIPO_IMPUESTO',
'FROM TIPO_IMPUESTO_CONTRIB',
'WHERE ID_TIPO_CONTRIB = :P102_TIPO_CONTRIBUYENTE',
'AND   ID_TIPO_IMPUESTO IN (:P104_TIP_IMPUESTO,:P104_TIP_IMPUESTO_1,:P104_TIP_IMPUESTO_2)'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_grid_column=>4
,p_display_when=>'P108_CANT_IMPUESTO'
,p_display_when2=>'1'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_NOT_EQ_COND2'
,p_field_template=>wwv_flow_api.id(5119886074344255)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(110608628153197308)
,p_name=>'P108_IMP_FIRMAR_T_13'
,p_item_sequence=>370
,p_item_plug_id=>wwv_flow_api.id(6485617766953637)
,p_prompt=>'Impuesto a firmar:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT PKG_MAESTRO_CONTRIBUYENTE.RETORNA_DESCRIP_TIPO_IMPUESTO (ID_TIPO_IMPUESTO)NOM_IMPUESTO,',
'ID_TIPO_IMPUESTO',
'FROM TIPO_IMPUESTO_CONTRIB',
'WHERE ID_TIPO_CONTRIB = :P102_TIPO_CONTRIBUYENTE',
'AND   ID_TIPO_IMPUESTO IN (:P104_TIP_IMPUESTO,:P104_TIP_IMPUESTO_1,:P104_TIP_IMPUESTO_2)'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_grid_column=>6
,p_display_when=>'P108_CANT_IMPUESTO'
,p_display_when2=>'3'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_api.id(5119886074344255)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(110608722839197309)
,p_name=>'P108_IMP_FIRMAR_T_14'
,p_item_sequence=>440
,p_item_plug_id=>wwv_flow_api.id(6485617766953637)
,p_prompt=>'Impuesto a firmar:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT PKG_MAESTRO_CONTRIBUYENTE.RETORNA_DESCRIP_TIPO_IMPUESTO (ID_TIPO_IMPUESTO)NOM_IMPUESTO,',
'ID_TIPO_IMPUESTO',
'FROM TIPO_IMPUESTO_CONTRIB',
'WHERE ID_TIPO_CONTRIB = :P102_TIPO_CONTRIBUYENTE',
'AND   ID_TIPO_IMPUESTO IN (:P104_TIP_IMPUESTO,:P104_TIP_IMPUESTO_1,:P104_TIP_IMPUESTO_2)'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_grid_column=>4
,p_display_when=>'P108_CANT_IMPUESTO'
,p_display_when2=>'1'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_NOT_EQ_COND2'
,p_field_template=>wwv_flow_api.id(5119886074344255)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(110608866790197310)
,p_name=>'P108_IMP_FIRMAR_T_15'
,p_item_sequence=>450
,p_item_plug_id=>wwv_flow_api.id(6485617766953637)
,p_prompt=>'Impuesto a firmar:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT PKG_MAESTRO_CONTRIBUYENTE.RETORNA_DESCRIP_TIPO_IMPUESTO (ID_TIPO_IMPUESTO)NOM_IMPUESTO,',
'ID_TIPO_IMPUESTO',
'FROM TIPO_IMPUESTO_CONTRIB',
'WHERE ID_TIPO_CONTRIB = :P102_TIPO_CONTRIBUYENTE',
'AND   ID_TIPO_IMPUESTO IN (:P104_TIP_IMPUESTO,:P104_TIP_IMPUESTO_1,:P104_TIP_IMPUESTO_2)'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_grid_column=>6
,p_display_when=>'P108_CANT_IMPUESTO'
,p_display_when2=>'3'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_api.id(5119886074344255)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(110608925982197311)
,p_name=>'P108_IMP_FIRMAR_T_16'
,p_item_sequence=>530
,p_item_plug_id=>wwv_flow_api.id(6485617766953637)
,p_prompt=>'Impuesto a firmar:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT PKG_MAESTRO_CONTRIBUYENTE.RETORNA_DESCRIP_TIPO_IMPUESTO (ID_TIPO_IMPUESTO)NOM_IMPUESTO,',
'ID_TIPO_IMPUESTO',
'FROM TIPO_IMPUESTO_CONTRIB',
'WHERE ID_TIPO_CONTRIB = :P102_TIPO_CONTRIBUYENTE',
'AND   ID_TIPO_IMPUESTO IN (:P104_TIP_IMPUESTO,:P104_TIP_IMPUESTO_1,:P104_TIP_IMPUESTO_2)'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_grid_column=>4
,p_display_when=>'P108_CANT_IMPUESTO'
,p_display_when2=>'1'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_NOT_EQ_COND2'
,p_field_template=>wwv_flow_api.id(5119886074344255)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(110609068068197312)
,p_name=>'P108_IMP_FIRMAR_T_17'
,p_item_sequence=>540
,p_item_plug_id=>wwv_flow_api.id(6485617766953637)
,p_prompt=>'Impuesto a firmar:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT PKG_MAESTRO_CONTRIBUYENTE.RETORNA_DESCRIP_TIPO_IMPUESTO (ID_TIPO_IMPUESTO)NOM_IMPUESTO,',
'ID_TIPO_IMPUESTO',
'FROM TIPO_IMPUESTO_CONTRIB',
'WHERE ID_TIPO_CONTRIB = :P102_TIPO_CONTRIBUYENTE',
'AND   ID_TIPO_IMPUESTO IN (:P104_TIP_IMPUESTO,:P104_TIP_IMPUESTO_1,:P104_TIP_IMPUESTO_2)'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_grid_column=>6
,p_display_when=>'P108_CANT_IMPUESTO'
,p_display_when2=>'3'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_api.id(5119886074344255)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(110609189532197313)
,p_name=>'P108_CANT_IMPUESTO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(6485563896953636)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(110609539234197317)
,p_name=>'P108_ALERTA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(6485563896953636)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(11621776167478639)
,p_validation_name=>'VAL_FORMATO_EMAIL'
,p_validation_sequence=>10
,p_validation=>'P108_EMAIL_APODERADO'
,p_validation2=>'@'
,p_validation_type=>'ITEM_IN_VALIDATION_CONTAINS_AT_LEAST_ONE_CHAR_IN_STRING2'
,p_error_message=>'Formato del email no valido'
,p_validation_condition=>'P108_EMAIL_APODERADO'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_associated_item=>wwv_flow_api.id(6484753521953628)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(11621830759478640)
,p_validation_name=>'VAL_FORMATO_EMAIL1'
,p_validation_sequence=>20
,p_validation=>'P108_EMAIL_APODERADO_1'
,p_validation2=>'@'
,p_validation_type=>'ITEM_IN_VALIDATION_CONTAINS_AT_LEAST_ONE_CHAR_IN_STRING2'
,p_error_message=>'Formato del email no valido'
,p_validation_condition=>'P108_EMAIL_APODERADO_1'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_associated_item=>wwv_flow_api.id(6485019735953631)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(11621990310478641)
,p_validation_name=>'VAL_FORMATO_EMAIL2'
,p_validation_sequence=>30
,p_validation=>'P108_EMAIL_APODERADO_2'
,p_validation2=>'@'
,p_validation_type=>'ITEM_IN_VALIDATION_CONTAINS_AT_LEAST_ONE_CHAR_IN_STRING2'
,p_error_message=>'Formato del email no valido'
,p_validation_condition=>'P108_EMAIL_APODERADO_2'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_associated_item=>wwv_flow_api.id(6485362560953634)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(11622006067478642)
,p_validation_name=>'VAL_FORMAT_EMAIL'
,p_validation_sequence=>40
,p_validation=>'P108_EMAIL_APO_T'
,p_validation2=>'@'
,p_validation_type=>'ITEM_IN_VALIDATION_CONTAINS_AT_LEAST_ONE_CHAR_IN_STRING2'
,p_error_message=>'Formato del email no valido'
,p_validation_condition=>'P108_EMAIL_APO_T'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_associated_item=>wwv_flow_api.id(6486755262953648)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(11622149976478643)
,p_validation_name=>'VAL_FORMAT_EMAIL1'
,p_validation_sequence=>50
,p_validation=>'P108_EMAIL_APO_T_1'
,p_validation2=>'@'
,p_validation_type=>'ITEM_IN_VALIDATION_CONTAINS_AT_LEAST_ONE_CHAR_IN_STRING2'
,p_error_message=>'Formato del email no valido'
,p_validation_condition=>'P108_EMAIL_APO_T_1'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_associated_item=>wwv_flow_api.id(6604744590928901)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(11622286039478644)
,p_validation_name=>'VAL_FORMAT_EMAIL2'
,p_validation_sequence=>60
,p_validation=>'P108_EMAIL_APO_T_2'
,p_validation2=>'@'
,p_validation_type=>'ITEM_IN_VALIDATION_CONTAINS_AT_LEAST_ONE_CHAR_IN_STRING2'
,p_error_message=>'Formato del email no valido'
,p_validation_condition=>'P108_EMAIL_APO_T_2'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_associated_item=>wwv_flow_api.id(6605140409928905)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(11622365403478645)
,p_validation_name=>'VAL_FORMAT_EMAIL3'
,p_validation_sequence=>70
,p_validation=>'P108_EMAIL_APO_T_3'
,p_validation2=>'@'
,p_validation_type=>'ITEM_IN_VALIDATION_CONTAINS_AT_LEAST_ONE_CHAR_IN_STRING2'
,p_error_message=>'Formato del email no valido'
,p_validation_condition=>'P108_EMAIL_APO_T_3'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_associated_item=>wwv_flow_api.id(6605585671928909)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(11622401840478646)
,p_validation_name=>'VAL_FORMAT_EMAIL4'
,p_validation_sequence=>80
,p_validation=>'P108_EMAIL_APO_T_4'
,p_validation2=>'@'
,p_validation_type=>'ITEM_IN_VALIDATION_CONTAINS_AT_LEAST_ONE_CHAR_IN_STRING2'
,p_error_message=>'Formato del email no valido'
,p_validation_condition=>'P108_EMAIL_APO_T_4'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_associated_item=>wwv_flow_api.id(6606162799928915)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(11622526061478647)
,p_validation_name=>'VAL_FORMAT_EMAIL5'
,p_validation_sequence=>90
,p_validation=>'P108_EMAIL_APO_T_5'
,p_validation2=>'@'
,p_validation_type=>'ITEM_IN_VALIDATION_CONTAINS_AT_LEAST_ONE_CHAR_IN_STRING2'
,p_error_message=>'Formato del email no valido'
,p_validation_condition=>'P108_EMAIL_APO_T_5'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_associated_item=>wwv_flow_api.id(6606546203928919)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(12306041882925029)
,p_validation_name=>'VAL_CED_APO_T_4'
,p_validation_sequence=>230
,p_validation=>'P108_CED_APO_T_4'
,p_validation_type=>'ITEM_IS_ALPHANUMERIC'
,p_error_message=>unistr('Por favor ingresar el n\00FAmero de c\00E9dula sin espacios y sin guiones ejemplo (102220333)')
,p_validation_condition=>'P108_TERCEROS'
,p_validation_condition2=>'S'
,p_validation_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_associated_item=>wwv_flow_api.id(6606093737928914)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(12306472091925033)
,p_validation_name=>'VAL_CED_APO_T_5'
,p_validation_sequence=>240
,p_validation=>'P108_CED_APO_T_5'
,p_validation_type=>'ITEM_IS_ALPHANUMERIC'
,p_error_message=>unistr('Por favor ingresar el n\00FAmero de c\00E9dula sin espacios y sin guiones ejemplo (102220333)')
,p_validation_condition=>'P108_TERCEROS'
,p_validation_condition2=>'S'
,p_validation_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_associated_item=>wwv_flow_api.id(6606488555928918)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(25656850369811240)
,p_validation_name=>'VAL_CEDULA_APO'
,p_validation_sequence=>250
,p_validation=>'P108_CEDULA_APRODERADO'
,p_validation_type=>'ITEM_IS_ALPHANUMERIC'
,p_error_message=>unistr('Por favor ingresar el n\00FAmero de c\00E9dula sin espacios y sin guiones ejemplo (102220333)')
,p_associated_item=>wwv_flow_api.id(6484526435953626)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(25656961889811241)
,p_validation_name=>'VAL_CEDULA_APO_1'
,p_validation_sequence=>260
,p_validation=>'P108_CEDULA_APRODERADO_1'
,p_validation_type=>'ITEM_IS_ALPHANUMERIC'
,p_error_message=>unistr('Por favor ingresar el n\00FAmero de c\00E9dula sin espacios y sin guiones ejemplo (102220333)')
,p_associated_item=>wwv_flow_api.id(6484951901953630)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(25657057787811242)
,p_validation_name=>'VAL_CEDULA_APO_2'
,p_validation_sequence=>270
,p_validation=>'P108_CEDULA_APRODERADO_2'
,p_validation_type=>'ITEM_IS_ALPHANUMERIC'
,p_error_message=>unistr('Por favor ingresar el n\00FAmero de c\00E9dula sin espacios y sin guiones ejemplo (102220333)')
,p_associated_item=>wwv_flow_api.id(6485262227953633)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(25657182709811243)
,p_validation_name=>'VAL_CED_APO_T1'
,p_validation_sequence=>280
,p_validation=>'P108_CED_APO_T'
,p_validation_type=>'ITEM_IS_ALPHANUMERIC'
,p_error_message=>unistr('Por favor ingresar el n\00FAmero de c\00E9dula sin espacios y sin guiones ejemplo (102220333)')
,p_associated_item=>wwv_flow_api.id(6486628162953647)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(25657245752811244)
,p_validation_name=>'VAL_CED_APO_T3'
,p_validation_sequence=>290
,p_validation=>'P108_CED_APO_T_3'
,p_validation_type=>'ITEM_IS_ALPHANUMERIC'
,p_error_message=>unistr('Por favor ingresar el n\00FAmero de c\00E9dula sin espacios y sin guiones ejemplo (102220333)')
,p_associated_item=>wwv_flow_api.id(6605433123928908)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(25657410022811246)
,p_validation_name=>'VAL_CED_APOT1'
,p_validation_sequence=>300
,p_validation=>'P108_CED_APO_T_1'
,p_validation_type=>'ITEM_IS_ALPHANUMERIC'
,p_error_message=>unistr('Por favor ingresar el n\00FAmero de c\00E9dula sin espacios y sin guiones ejemplo (102220333)')
,p_associated_item=>wwv_flow_api.id(6486907745953650)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(25657559175811247)
,p_validation_name=>'VAL_CED_APO_T2'
,p_validation_sequence=>310
,p_validation=>'P108_CED_APO_T_2'
,p_validation_type=>'ITEM_IS_ALPHANUMERIC'
,p_error_message=>unistr('Por favor ingresar el n\00FAmero de c\00E9dula sin espacios y sin guiones ejemplo (102220333)')
,p_associated_item=>wwv_flow_api.id(6605089998928904)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(36449520139960737)
,p_validation_name=>'VAL_PODER_LEGAL'
,p_validation_sequence=>320
,p_validation=>'P108_PODER_LEGAL'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Debe Adjuntar un Archivo.'
,p_validation_condition=>'P108_NOM_APO_T'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_associated_item=>wwv_flow_api.id(13252653117850215)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(36449645210960738)
,p_validation_name=>'VAL_PODER_ESPECIAL'
,p_validation_sequence=>330
,p_validation=>'P108_PODER_ESPECIAL'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Debe Adjuntar un Archivo.'
,p_validation_condition=>'P108_NOM_APO_T'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_associated_item=>wwv_flow_api.id(34487165786508227)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(36449824644960740)
,p_validation_name=>'VAL_PODER_ESPECIAL_1'
,p_validation_sequence=>340
,p_validation=>'P108_PODER_ESPECIAL_1'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Debe Adjuntar un Archivo.'
,p_validation_condition=>'P108_NOM_APO_T_1'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_associated_item=>wwv_flow_api.id(34487298386508228)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(36450056423960742)
,p_validation_name=>'VAL_PODER_ESPECIAL_2'
,p_validation_sequence=>350
,p_validation=>'P108_PODER_ESPECIAL_21'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Debe Adjuntar un Archivo.'
,p_validation_condition=>'P108_NOM_APO_T_2'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_associated_item=>wwv_flow_api.id(34487337605508229)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>5801312104779619
,p_default_application_id=>102
,p_default_id_offset=>0
,p_default_owner=>'DESA_SIT'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(36450287674960744)
,p_validation_name=>'VAL_PODER_ESPECIAL_3'
,p_validation_sequence=>370
,p_validation=>'P108_PODER_ESPECIAL_3'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Debe Adjuntar un Archivo.'
,p_validation_condition=>'P108_NOM_APO_T_3'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_associated_item=>wwv_flow_api.id(34487411404508230)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(36450680257960748)
,p_validation_name=>'VAL_PODER_ESPECIAL_4'
,p_validation_sequence=>380
,p_validation=>'P108_PODER_ESPECIAL_4'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Debe Adjuntar un Archivo.'
,p_validation_condition=>'P108_NOM_APO_T_4'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_associated_item=>wwv_flow_api.id(34487537893508231)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(36450808994960750)
,p_validation_name=>'VAL_PODER_ESPECIAL_5'
,p_validation_sequence=>390
,p_validation=>'P108_PODER_ESPECIAL_5'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Debe Adjuntar un Archivo.'
,p_validation_condition=>'P108_NOM_APO_T_5'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_associated_item=>wwv_flow_api.id(34487629439508232)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(36449783886960739)
,p_validation_name=>'VAL_PODER_LEGAL_1'
,p_validation_sequence=>400
,p_validation=>'P108_PODER_LEGAL_1'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Debe Adjuntar un Archivo.'
,p_validation_condition=>'P108_NOM_APO_T_1'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_associated_item=>wwv_flow_api.id(13252748819850216)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(36449959324960741)
,p_validation_name=>'VAL_PODER_LEGAL_2'
,p_validation_sequence=>410
,p_validation=>'P108_PODER_LEGAL_2'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Debe Adjuntar un Archivo.'
,p_validation_condition=>'P108_NOM_APO_T_2'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_associated_item=>wwv_flow_api.id(13252846214850217)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(36450190244960743)
,p_validation_name=>'VAL_PODER_LEGAL_3'
,p_validation_sequence=>420
,p_validation=>'P108_PODER_LEGAL_3'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Debe Adjuntar un Archivo.'
,p_validation_condition=>'P108_NOM_APO_T_3'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_associated_item=>wwv_flow_api.id(13252999554850218)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(36450440218960746)
,p_validation_name=>'VAL_PODER_LEGAL_4'
,p_validation_sequence=>430
,p_validation=>'P108_PODER_LEGAL_4'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Debe Adjuntar un Archivo.'
,p_validation_condition=>'P108_NOM_APO_T_4'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_associated_item=>wwv_flow_api.id(13253076938850219)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(36450755336960749)
,p_validation_name=>'VAL_PODER_LEGAL_5'
,p_validation_sequence=>440
,p_validation=>'P108_PODER_LEGAL_5'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Debe Adjuntar un Archivo.'
,p_validation_condition=>'P108_NOM_APO_T_5'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_associated_item=>wwv_flow_api.id(13253174999850220)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(14732903101202450)
,p_validation_name=>'VAL_COMAS_APO1'
,p_validation_sequence=>450
,p_validation=>'P108_EMAIL_APODERADO'
,p_validation2=>','
,p_validation_type=>'ITEM_IN_VALIDATION_CONTAINS_NO_CHAR_IN_STRING2'
,p_error_message=>'Formato de correo no valido, por favor verificar'
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(13957951711744224)
,p_validation_name=>'VAL_COMAS_APO2'
,p_validation_sequence=>460
,p_validation=>'P108_EMAIL_APODERADO_1'
,p_validation2=>','
,p_validation_type=>'ITEM_IN_VALIDATION_CONTAINS_NO_CHAR_IN_STRING2'
,p_error_message=>'Formato de correo no valido, por favor verificar'
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(13958046800744225)
,p_validation_name=>'VAL_COMAS_APO3'
,p_validation_sequence=>470
,p_validation=>'P108_EMAIL_APODERADO_2'
,p_validation2=>','
,p_validation_type=>'ITEM_IN_VALIDATION_CONTAINS_NO_CHAR_IN_STRING2'
,p_error_message=>'Formato de correo no valido, por favor verificar'
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(13958121281744226)
,p_validation_name=>'VAL_COMAS_TER'
,p_validation_sequence=>480
,p_validation=>'P108_EMAIL_APO_T'
,p_validation2=>','
,p_validation_type=>'ITEM_IN_VALIDATION_CONTAINS_NO_CHAR_IN_STRING2'
,p_error_message=>'Formato de correo no valido, por favor verificar'
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(13958215729744227)
,p_validation_name=>'VAL_COMAS_TER_2'
,p_validation_sequence=>490
,p_validation=>'P108_EMAIL_APO_T_1'
,p_validation2=>','
,p_validation_type=>'ITEM_IN_VALIDATION_CONTAINS_NO_CHAR_IN_STRING2'
,p_error_message=>'Formato de correo no valido, por favor verificar'
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(13958340509744228)
,p_validation_name=>'VAL_COMAS_TER_3'
,p_validation_sequence=>500
,p_validation=>'P108_EMAIL_APO_T_2'
,p_validation2=>','
,p_validation_type=>'ITEM_IN_VALIDATION_CONTAINS_NO_CHAR_IN_STRING2'
,p_error_message=>'Formato de correo no valido, por favor verificar'
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(13958476045744229)
,p_validation_name=>'VAL_COMAS_TER_4'
,p_validation_sequence=>510
,p_validation=>'P108_EMAIL_APO_T_3'
,p_validation2=>','
,p_validation_type=>'ITEM_IN_VALIDATION_CONTAINS_NO_CHAR_IN_STRING2'
,p_error_message=>'Formato de correo no valido, por favor verificar'
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(13958580084744230)
,p_validation_name=>'VAL_COMAS_TER_5'
,p_validation_sequence=>520
,p_validation=>'P108_EMAIL_APO_T_4'
,p_validation2=>','
,p_validation_type=>'ITEM_IN_VALIDATION_CONTAINS_NO_CHAR_IN_STRING2'
,p_error_message=>'Formato de correo no valido, por favor verificar'
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(13958629273744231)
,p_validation_name=>'VAL_COMAS_TER_6'
,p_validation_sequence=>530
,p_validation=>'P108_EMAIL_APO_T_5'
,p_validation2=>','
,p_validation_type=>'ITEM_IN_VALIDATION_CONTAINS_NO_CHAR_IN_STRING2'
,p_error_message=>'Formato de correo no valido, por favor verificar'
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(6486161149953642)
,p_name=>'DAC_TERCEROS'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P108_TERCEROS'
,p_condition_element=>'P108_TERCEROS'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'S'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(6486290770953643)
,p_event_id=>wwv_flow_api.id(6486161149953642)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(6485617766953637)
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(6486335010953644)
,p_event_id=>wwv_flow_api.id(6486161149953642)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(6485617766953637)
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(43134762970105902)
,p_event_id=>wwv_flow_api.id(6486161149953642)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'IF :P102_TIPO_CONTRIBUYENTE = 2 THEN ',
'   :P108_IMP_FIRMAR_T := 1;',
'END IF;',
'END;'))
,p_attribute_03=>'P108_IMP_FIRMAR_T'
,p_attribute_04=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(43134846433105903)
,p_event_id=>wwv_flow_api.id(6486161149953642)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'IF :P102_TIPO_CONTRIBUYENTE = 2 THEN ',
'   :P108_IMP_FIRMAR_T := NULL;',
'END IF;',
'END;'))
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(43032019168942015)
,p_name=>'DAC_UPPER_NOM_APODERADO'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P108_NOM_APODERADO'
,p_bind_type=>'bind'
,p_bind_event_type=>'focusout'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(43032138030942016)
,p_event_id=>wwv_flow_api.id(43032019168942015)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$("#P108_NOM_APODERADO").val($("#P108_NOM_APODERADO").val().toUpperCase());'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(43032262273942017)
,p_name=>'DAC_UPPER_NOM_APO1'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P108_NOM_APODERADO_1'
,p_bind_type=>'bind'
,p_bind_event_type=>'focusout'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(43032359932942018)
,p_event_id=>wwv_flow_api.id(43032262273942017)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$("#P108_NOM_APODERADO_1").val($("#P108_NOM_APODERADO_1").val().toUpperCase());'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(43032458741942019)
,p_name=>'DAC_UPPER_NOM_APO2'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P108_NOM_APODERADO_2'
,p_bind_type=>'bind'
,p_bind_event_type=>'focusout'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(43032515339942020)
,p_event_id=>wwv_flow_api.id(43032458741942019)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$("#P108_NOM_APODERADO_2").val($("#P108_NOM_APODERADO_2").val().toUpperCase());'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(43032610949942021)
,p_name=>'DAC_UPPER_NOM_APOT'
,p_event_sequence=>50
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P108_NOM_APO_T'
,p_bind_type=>'bind'
,p_bind_event_type=>'focusout'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(43032798748942022)
,p_event_id=>wwv_flow_api.id(43032610949942021)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$("#P108_NOM_APO_T").val($("#P108_NOM_APO_T").val().toUpperCase());'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(43032886856942023)
,p_name=>'DAC_UPPER_NOM_APOT1'
,p_event_sequence=>60
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P108_NOM_APO_T_1'
,p_bind_type=>'bind'
,p_bind_event_type=>'focusout'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(43032961796942024)
,p_event_id=>wwv_flow_api.id(43032886856942023)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$("#P108_NOM_APO_T_1").val($("#P108_NOM_APO_T_1").val().toUpperCase());'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(43033016344942025)
,p_name=>'DAC_UPPER_NOM_APOT2'
,p_event_sequence=>70
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P108_NOM_APO_T_2'
,p_bind_type=>'bind'
,p_bind_event_type=>'focusout'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(43033101720942026)
,p_event_id=>wwv_flow_api.id(43033016344942025)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$("#P108_NOM_APO_T_2").val($("#P108_NOM_APO_T_2").val().toUpperCase());'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(43033269838942027)
,p_name=>'DAC_NOM_APOT3'
,p_event_sequence=>80
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P108_NOM_APO_T_3'
,p_bind_type=>'bind'
,p_bind_event_type=>'focusout'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(43033352096942028)
,p_event_id=>wwv_flow_api.id(43033269838942027)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$("#P108_NOM_APO_T_3").val($("#P108_NOM_APO_T_3").val().toUpperCase());'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(43033412748942029)
,p_name=>'DAC_UPPER_NOM_APOT4'
,p_event_sequence=>90
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P108_NOM_APO_T_4'
,p_bind_type=>'bind'
,p_bind_event_type=>'focusout'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(43033517615942030)
,p_event_id=>wwv_flow_api.id(43033412748942029)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$("#P108_NOM_APO_T_4").val($("#P108_NOM_APO_T_4").val().toUpperCase());'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(43033679544942031)
,p_name=>'DAC_UPPER_NOM_APOT5'
,p_event_sequence=>100
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P108_NOM_APO_T_5'
,p_bind_type=>'bind'
,p_bind_event_type=>'focusout'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(43033740519942032)
,p_event_id=>wwv_flow_api.id(43033679544942031)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$("#P108_NOM_APO_T_5").val($("#P108_NOM_APO_T_5").val().toUpperCase());'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(110609637196197318)
,p_name=>'DAC_ALERTA_IMP'
,p_event_sequence=>120
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P108_ALERTA'
,p_condition_element=>'P108_ALERTA'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'N'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(110609785879197319)
,p_event_id=>wwv_flow_api.id(110609637196197318)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>'No se puede seleccionar el mismo impuesto mas de una vez, por favor valide.'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(110609857756197320)
,p_name=>'DAC_REPITE_IMP_APO1'
,p_event_sequence=>130
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P108_IMPUESTO_FIRMAR,P108_IMPUESTO_FIRMAR_3,P108_IMPUESTO_FIRMAR_4'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(110609973954197321)
,p_event_id=>wwv_flow_api.id(110609857756197320)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF :P108_IMPUESTO_FIRMAR = :P108_IMPUESTO_FIRMAR_3  OR :P108_IMPUESTO_FIRMAR = :P108_IMPUESTO_FIRMAR_4 OR :P108_IMPUESTO_FIRMAR_3 = :P108_IMPUESTO_FIRMAR_4 THEN',
'    :P108_ALERTA := ''N'';',
'ELSE',
' :P108_ALERTA := ''S'';',
'END IF;            '))
,p_attribute_02=>'P108_IMPUESTO_FIRMAR,P108_IMPUESTO_FIRMAR_3,P108_IMPUESTO_FIRMAR_4'
,p_attribute_03=>'P108_ALERTA'
,p_attribute_04=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(110609260909197314)
,p_name=>'DAC_REPITE_IMP_APO2'
,p_event_sequence=>131
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P108_IMPUESTO_FIRMAR_1,P108_IMPUESTO_FIRMAR_5,P108_IMPUESTO_FIRMAR_6'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(110609377020197315)
,p_event_id=>wwv_flow_api.id(110609260909197314)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF :P108_IMPUESTO_FIRMAR_1= :P108_IMPUESTO_FIRMAR_5 OR :P108_IMPUESTO_FIRMAR_1= :P108_IMPUESTO_FIRMAR_6 OR :P108_IMPUESTO_FIRMAR_5 = :P108_IMPUESTO_FIRMAR_6 THEN',
'    :P108_ALERTA := ''N'';',
'ELSE',
' :P108_ALERTA := ''S'';',
'END IF;          '))
,p_attribute_02=>'P108_IMPUESTO_FIRMAR_1,P108_IMPUESTO_FIRMAR_5,P108_IMPUESTO_FIRMAR_6'
,p_attribute_03=>'P108_ALERTA'
,p_attribute_04=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(110610201857197324)
,p_name=>'DAC_REPITE_IMP_APO3'
,p_event_sequence=>132
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P108_IMPUESTO_FIRMAR_2,P108_IMPUESTO_FIRMAR_7,P108_IMPUESTO_FIRMAR_8'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(110610352146197325)
,p_event_id=>wwv_flow_api.id(110610201857197324)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF :P108_IMPUESTO_FIRMAR_2 = :P108_IMPUESTO_FIRMAR_7 OR :P108_IMPUESTO_FIRMAR_2 = :P108_IMPUESTO_FIRMAR_8 OR :P108_IMPUESTO_FIRMAR_7 = :P108_IMPUESTO_FIRMAR_8 THEN',
'    :P108_ALERTA := ''N'';',
'ELSE',
' :P108_ALERTA := ''S'';',
'END IF; '))
,p_attribute_02=>'P108_IMPUESTO_FIRMAR_2,P108_IMPUESTO_FIRMAR_7,P108_IMPUESTO_FIRMAR_8'
,p_attribute_03=>'P108_ALERTA'
,p_attribute_04=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(110610672809197328)
,p_name=>'DAC_REPITE_IMP_TERC1'
,p_event_sequence=>140
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P108_IMP_FIRMAR_T,P108_IMP_FIRMAR_T_7,P108_IMP_FIRMAR_T_6'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(110610716621197329)
,p_event_id=>wwv_flow_api.id(110610672809197328)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF :P108_IMP_FIRMAR_T = :P108_IMP_FIRMAR_T_7 OR :P108_IMP_FIRMAR_T = :P108_IMP_FIRMAR_T_6 OR :P108_IMP_FIRMAR_T_7 = :P108_IMP_FIRMAR_T_6 THEN',
'    :P108_ALERTA := ''N'';',
'ELSE',
' :P108_ALERTA := ''S'';',
'END IF;             '))
,p_attribute_02=>'P108_IMP_FIRMAR_T,P108_IMP_FIRMAR_T_6 ,P108_IMP_FIRMAR_T_7'
,p_attribute_03=>'P108_ALERTA'
,p_attribute_04=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(110610834276197330)
,p_name=>'DAC_REPITE_IMP_TERC2'
,p_event_sequence=>150
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P108_IMP_FIRMAR_T_1,P108_IMP_FIRMAR_T_8,P108_IMP_FIRMAR_T_9'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(110610936713197331)
,p_event_id=>wwv_flow_api.id(110610834276197330)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF :P108_IMP_FIRMAR_T_1 = :P108_IMP_FIRMAR_T_8 OR :P108_IMP_FIRMAR_T_1 = :P108_IMP_FIRMAR_T_9 OR :P108_IMP_FIRMAR_T_8 = :P108_IMP_FIRMAR_T_9 THEN',
'    :P108_ALERTA := ''N'';',
'ELSE',
' :P108_ALERTA := ''S'';',
'END IF;            '))
,p_attribute_02=>'P108_IMP_FIRMAR_T_1,P108_IMP_FIRMAR_T_8,P108_IMP_FIRMAR_T_9'
,p_attribute_03=>'P108_ALERTA'
,p_attribute_04=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(110611046483197332)
,p_name=>'DAC_REPITE_IMP_TERC3'
,p_event_sequence=>160
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P108_IMP_FIRMAR_T_2,P108_IMP_FIRMAR_T_10,P108_IMP_FIRMAR_T_11'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(110611114487197333)
,p_event_id=>wwv_flow_api.id(110611046483197332)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF :P108_IMP_FIRMAR_T_2 = :P108_IMP_FIRMAR_T_10 OR :P108_IMP_FIRMAR_T_2 = :P108_IMP_FIRMAR_T_11 OR :P108_IMP_FIRMAR_T_10 = :P108_IMP_FIRMAR_T_11 THEN',
'    :P108_ALERTA := ''N'';',
'ELSE',
' :P108_ALERTA := ''S'';',
'END IF;             '))
,p_attribute_02=>'P108_IMP_FIRMAR_T_2,P108_IMP_FIRMAR_T_10,P108_IMP_FIRMAR_T_11'
,p_attribute_03=>'P108_ALERTA'
,p_attribute_04=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(110611409165197336)
,p_name=>'DAC_REPITE_IMP_TERC4'
,p_event_sequence=>170
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P108_IMP_FIRMAR_T_3,P108_IMP_FIRMAR_T_12,P108_IMP_FIRMAR_T_13'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(110611580645197337)
,p_event_id=>wwv_flow_api.id(110611409165197336)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF :P108_IMP_FIRMAR_T_3 = :P108_IMP_FIRMAR_T_12 OR :P108_IMP_FIRMAR_T_3 = :P108_IMP_FIRMAR_T_13 OR :P108_IMP_FIRMAR_T_12 = :P108_IMP_FIRMAR_T_13 THEN',
'    :P108_ALERTA := ''N'';',
'ELSE',
' :P108_ALERTA := ''S'';',
'END IF;             '))
,p_attribute_02=>'P108_IMP_FIRMAR_T_3,P108_IMP_FIRMAR_T_12,P108_IMP_FIRMAR_T_13'
,p_attribute_03=>'P108_ALERTA'
,p_attribute_04=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(110611693902197338)
,p_name=>'DAC_REPITE_IMP_TERC5'
,p_event_sequence=>180
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P108_IMP_FIRMAR_T_4,P108_IMP_FIRMAR_T_14,P108_IMP_FIRMAR_T_15'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(110611732937197339)
,p_event_id=>wwv_flow_api.id(110611693902197338)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF :P108_IMP_FIRMAR_T_4 = :P108_IMP_FIRMAR_T_14 OR :P108_IMP_FIRMAR_T_4 = :P108_IMP_FIRMAR_T_15 OR :P108_IMP_FIRMAR_T_14 = :P108_IMP_FIRMAR_T_15 THEN',
'    :P108_ALERTA := ''N'';',
'ELSE',
' :P108_ALERTA := ''S'';',
'END IF;             '))
,p_attribute_02=>'P108_IMP_FIRMAR_T_4,P108_IMP_FIRMAR_T_14,P108_IMP_FIRMAR_T_15'
,p_attribute_03=>'P108_ALERTA'
,p_attribute_04=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(110611870017197340)
,p_name=>'DAC_REPITE_IMP_TERC6'
,p_event_sequence=>190
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P108_IMP_FIRMAR_T_5,P108_IMP_FIRMAR_T_16,P108_IMP_FIRMAR_T_17'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(110611989166197341)
,p_event_id=>wwv_flow_api.id(110611870017197340)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF :P108_IMP_FIRMAR_T_5 = :P108_IMP_FIRMAR_T_16 OR :P108_IMP_FIRMAR_T_5 = :P108_IMP_FIRMAR_T_17 OR :P108_IMP_FIRMAR_T_16 = :P108_IMP_FIRMAR_T_17 THEN',
'    :P108_ALERTA := ''N'';',
'ELSE',
' :P108_ALERTA := ''S'';',
'END IF;             '))
,p_attribute_02=>'P108_IMP_FIRMAR_T_5,P108_IMP_FIRMAR_T_16,P108_IMP_FIRMAR_T_17'
,p_attribute_03=>'P108_ALERTA'
,p_attribute_04=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(43134641123105901)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_DATOS'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'/*IF :P102_TIPO_CONTRIBUYENTE = 2 THEN',
'   :P108_IMPUESTO_FIRMAR := 1; ',
'END IF;*/',
'',
':P108_CANT_IMPUESTO := PKG_MAESTRO_CONTRIBUYENTE.CANT_IMPUESTO_TIP_CONTRIB (:P102_TIPO_CONTRIBUYENTE);',
'END;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
