prompt --application/pages/page_00112
begin
--   Manifest
--     PAGE: 00112
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>5801312104779619
,p_default_application_id=>102
,p_default_id_offset=>0
,p_default_owner=>'DESA_SIT'
);
wwv_flow_api.create_page(
 p_id=>112
,p_user_interface_id=>wwv_flow_api.id(5143571665344221)
,p_name=>'112-Datos Maestro Contribuyente'
,p_alias=>'112-DATOS-MAESTRO-CONTRIBUYENTE'
,p_step_title=>'Datos Maestro Contribuyente'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_browser_cache=>'N'
,p_last_updated_by=>'JORGE.ROJAS'
,p_last_upd_yyyymmddhh24miss=>'20241119145851'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(20102188476899430)
,p_plug_name=>'Tabs'
,p_region_template_options=>'#DEFAULT#:js-useLocalStorage:t-TabsRegion-mod--fillLabels:t-TabsRegion-mod--pill:t-TabsRegion-mod--large'
,p_plug_template=>wwv_flow_api.id(5065793333344285)
,p_plug_display_sequence=>5
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'STANDARD'
,p_attribute_02=>'Y'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(22468875790585807)
,p_plug_name=>unistr('Informaci\00F3n General')
,p_parent_plug_id=>wwv_flow_api.id(20102188476899430)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(5058998562344289)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'TABLE'
,p_query_table=>'MAESTRO_CONTRIBUYENTE'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(20102354299899432)
,p_plug_name=>unistr('Informaci\00F3n')
,p_parent_plug_id=>wwv_flow_api.id(22468875790585807)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(5058998562344289)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(20102494035899433)
,p_plug_name=>'&P112_NOMBRE_REGION.'
,p_parent_plug_id=>wwv_flow_api.id(22468875790585807)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(5058998562344289)
,p_plug_display_sequence=>40
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_NOT_EQ_COND2'
,p_plug_display_when_condition=>'P112_TIPO_INSCRIPCION'
,p_plug_display_when_cond2=>'IVC'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(20103429228899443)
,p_plug_name=>unistr('Direcci\00F3n para Notificaciones')
,p_parent_plug_id=>wwv_flow_api.id(22468875790585807)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(5058998562344289)
,p_plug_display_sequence=>50
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P112_TIPO_INSCRIPCION'
,p_plug_display_when_cond2=>'IR'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(23268473583778510)
,p_plug_name=>unistr('Informaci\00F3n Gerente')
,p_parent_plug_id=>wwv_flow_api.id(22468875790585807)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(5058998562344289)
,p_plug_display_sequence=>80
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P112_TIPO_INSCRIPCION'
,p_plug_display_when_cond2=>'IR'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(23268529494778511)
,p_plug_name=>'Representante Legal'
,p_parent_plug_id=>wwv_flow_api.id(22468875790585807)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(5058998562344289)
,p_plug_display_sequence=>90
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(69632959857589333)
,p_plug_name=>'Actualizar Representante Legal'
,p_region_name=>'ID_REP_LEG'
,p_parent_plug_id=>wwv_flow_api.id(23268529494778511)
,p_region_template_options=>'#DEFAULT#:js-dialog-size600x400'
,p_plug_template=>wwv_flow_api.id(5051409310344291)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(23268679688778512)
,p_plug_name=>unistr('Informaci\00F3n Asistente en Tierra en Costa Rica')
,p_parent_plug_id=>wwv_flow_api.id(22468875790585807)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(5058998562344289)
,p_plug_display_sequence=>100
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P112_TIPO_INSCRIPCION'
,p_plug_display_when_cond2=>'IVC'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(29017723106693938)
,p_name=>'Impuesto a Declarar'
,p_parent_plug_id=>wwv_flow_api.id(22468875790585807)
,p_template=>wwv_flow_api.id(5058998562344289)
,p_display_sequence=>30
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_new_grid_row=>false
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID_TIPO_IMPUESTO,',
'       ID_CONTRIBUYENTE,',
'       NOMBRE_ENCARGADO_IMP,',
'       CEDULA_ENCARGADO_IMP,',
'       CORREO_ENCARGADO_IMP',
'  from IMPUESTO_X_MAESTRO_CONTRIBUYE',
'  where ID_CONTRIBUYENTE = :P112_ID_CONTRIBUYENTE',
'  and   CODIGO_ESTADO = ''AC'''))
,p_ajax_enabled=>'Y'
,p_query_row_template=>wwv_flow_api.id(5085249619344274)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(29017858595693939)
,p_query_column_id=>1
,p_column_alias=>'ID_TIPO_IMPUESTO'
,p_column_display_sequence=>1
,p_column_heading=>'Tipo Impuesto'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_api.id(12378667772254658)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(29017978756693940)
,p_query_column_id=>2
,p_column_alias=>'ID_CONTRIBUYENTE'
,p_column_display_sequence=>2
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(29018006757693941)
,p_query_column_id=>3
,p_column_alias=>'NOMBRE_ENCARGADO_IMP'
,p_column_display_sequence=>3
,p_column_heading=>'Encargado'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_condition=>'P112_TIPO_INSCRIPCION'
,p_display_when_condition2=>'IR'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(29018144750693942)
,p_query_column_id=>4
,p_column_alias=>'CEDULA_ENCARGADO_IMP'
,p_column_display_sequence=>4
,p_column_heading=>'Cedula'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_condition=>'P112_TIPO_INSCRIPCION'
,p_display_when_condition2=>'IR'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(29018220695693943)
,p_query_column_id=>5
,p_column_alias=>'CORREO_ENCARGADO_IMP'
,p_column_display_sequence=>5
,p_column_heading=>'Correo'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_condition=>'P112_TIPO_INSCRIPCION'
,p_display_when_condition2=>'IR'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(81497822966069048)
,p_query_column_id=>6
,p_column_alias=>'DERIVED$01'
,p_column_display_sequence=>6
,p_column_heading=>'Inactivar'
,p_use_as_row_header=>'N'
,p_column_link=>'javascript:$s(''P112_ID_IMPUESTO'',''#ID_TIPO_IMPUESTO#'');javascript:openModal(''ID_INAC_IMP''); $("#ID_INAC_IMP").trigger("apexrefresh");'
,p_column_linktext=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_column_alignment=>'CENTER'
,p_display_when_cond_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_condition=>'P112_CANT_IMPUESTOS'
,p_display_when_condition2=>'S'
,p_derived_column=>'Y'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(27639086773385609)
,p_query_column_id=>7
,p_column_alias=>'DERIVED$02'
,p_column_display_sequence=>7
,p_column_heading=>'Editar'
,p_use_as_row_header=>'N'
,p_column_link=>'javascript:$s(''P112_IMPUESTO_1'',''#ID_TIPO_IMPUESTO#'');javascript:$s(''P112_NOMBRE_ENCAR_1'',''#NOMBRE_ENCARGADO_IMP#'');javascript:$s(''P112_CEDULA_ENCAR_1'',''#CEDULA_ENCARGADO_IMP#'');javascript:$s(''P112_CORREO_ENCAR_1'',''#CORREO_ENCARGADO_IMP#'');javascript'
||':openModal(''M_ID_IMPUESTO''); $("#M_ID_IMPUESTO").trigger("apexrefresh");'
,p_column_linktext=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_column_alignment=>'CENTER'
,p_derived_column=>'Y'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(27639156730385610)
,p_plug_name=>'Actualizar Impuesto'
,p_region_name=>'M_ID_IMPUESTO'
,p_parent_plug_id=>wwv_flow_api.id(29017723106693938)
,p_region_template_options=>'#DEFAULT#:js-dialog-size600x400'
,p_plug_template=>wwv_flow_api.id(5051409310344291)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(69634519214589349)
,p_plug_name=>'Agregar Impuesto'
,p_region_name=>'ID_IMPUESTO'
,p_parent_plug_id=>wwv_flow_api.id(29017723106693938)
,p_region_template_options=>'#DEFAULT#:js-dialog-size600x400'
,p_plug_template=>wwv_flow_api.id(5051409310344291)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(81497967607069049)
,p_plug_name=>'Inactivar Impuesto'
,p_region_name=>'ID_INAC_IMP'
,p_parent_plug_id=>wwv_flow_api.id(29017723106693938)
,p_region_template_options=>'#DEFAULT#:js-dialog-autoheight:js-dialog-size480x320'
,p_plug_template=>wwv_flow_api.id(5051409310344291)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(29018309478693944)
,p_name=>unistr('Tel\00E9fonos ')
,p_parent_plug_id=>wwv_flow_api.id(22468875790585807)
,p_template=>wwv_flow_api.id(5058998562344289)
,p_display_sequence=>60
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID_TELEFONO,',
'       ID_CONTRIBUYENTE,',
'       ID_TIPO_TELEFONO,',
'       TELEFONO',
'  from TELEFONO_X_MAESTRO_CONTRIBU',
'  where ID_CONTRIBUYENTE= :P112_ID_CONTRIBUYENTE'))
,p_ajax_enabled=>'Y'
,p_query_row_template=>wwv_flow_api.id(5085249619344274)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'ROWS_X_TO_Y'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(29018457295693945)
,p_query_column_id=>1
,p_column_alias=>'ID_TELEFONO'
,p_column_display_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(29018508080693946)
,p_query_column_id=>2
,p_column_alias=>'ID_CONTRIBUYENTE'
,p_column_display_sequence=>2
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(29018680241693947)
,p_query_column_id=>3
,p_column_alias=>'ID_TIPO_TELEFONO'
,p_column_display_sequence=>3
,p_column_heading=>unistr('Tipo Tel\00E9fono')
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_api.id(25335221527312654)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(29018763221693948)
,p_query_column_id=>4
,p_column_alias=>'TELEFONO'
,p_column_display_sequence=>4
,p_column_heading=>unistr('Tel\00E9fono')
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(31076145625718304)
,p_query_column_id=>5
,p_column_alias=>'DERIVED$01'
,p_column_display_sequence=>5
,p_column_heading=>'Editar'
,p_use_as_row_header=>'N'
,p_column_link=>'javascript:$s(''P112_ID_TEL'',''#ID_TELEFONO#'');javascript:openModal(''TEL_ID''); $("#TEL_ID").trigger("apexrefresh");'
,p_column_linktext=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_derived_column=>'Y'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(31076046638718303)
,p_plug_name=>unistr('Actualizar Tel\00E9fono ')
,p_region_name=>'TEL_ID'
,p_parent_plug_id=>wwv_flow_api.id(29018309478693944)
,p_region_template_options=>'#DEFAULT#:js-dialog-autoheight:js-dialog-size480x320'
,p_plug_template=>wwv_flow_api.id(5051409310344291)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(37064306880503236)
,p_plug_name=>unistr('Agregar Tel\00E9fono ')
,p_region_name=>'NEWTEL_ID'
,p_parent_plug_id=>wwv_flow_api.id(29018309478693944)
,p_region_template_options=>'#DEFAULT#:js-dialog-autoheight:js-dialog-size480x320'
,p_plug_template=>wwv_flow_api.id(5051409310344291)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(29018885092693949)
,p_name=>'Correos para Notificaciones'
,p_parent_plug_id=>wwv_flow_api.id(22468875790585807)
,p_template=>wwv_flow_api.id(5058998562344289)
,p_display_sequence=>70
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_new_grid_row=>false
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID_CORREO_NOTIFICA,',
'       ID_CONTRIBUYENTE,',
'       CORREO_NOTIFICA,',
'       CODIGO_ESTADO',
'  from CORREO_NOTIFICACIONES',
'  where ID_CONTRIBUYENTE = :P112_ID_CONTRIBUYENTE',
'  and   CODIGO_ESTADO = ''AC'''))
,p_ajax_enabled=>'Y'
,p_query_row_template=>wwv_flow_api.id(5085249619344274)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'ROWS_X_TO_Y'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(29018941504693950)
,p_query_column_id=>1
,p_column_alias=>'ID_CORREO_NOTIFICA'
,p_column_display_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(31075813806718301)
,p_query_column_id=>2
,p_column_alias=>'ID_CONTRIBUYENTE'
,p_column_display_sequence=>2
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(31075988061718302)
,p_query_column_id=>3
,p_column_alias=>'CORREO_NOTIFICA'
,p_column_display_sequence=>3
,p_column_heading=>'Correo'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(84934326750861602)
,p_query_column_id=>4
,p_column_alias=>'CODIGO_ESTADO'
,p_column_display_sequence=>4
,p_column_heading=>'Estado'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_api.id(30271022373201996)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(31076960893718312)
,p_query_column_id=>5
,p_column_alias=>'DERIVED$01'
,p_column_display_sequence=>5
,p_column_heading=>'Editar'
,p_use_as_row_header=>'N'
,p_column_link=>'javascript:$s(''P112_NEW_CORREO'',''#CORREO_NOTIFICA#'');javascript:$s(''P112_ID_CORREO'',''#ID_CORREO_NOTIFICA#'');javascript:openModal(''ID_CORREO''); $("#ID_CORREO").trigger("apexrefresh");'
,p_column_linktext=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_column_alignment=>'CENTER'
,p_derived_column=>'Y'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(31076891351718311)
,p_plug_name=>'Actualizar Correos'
,p_region_name=>'ID_CORREO'
,p_parent_plug_id=>wwv_flow_api.id(29018885092693949)
,p_region_template_options=>'#DEFAULT#:js-dialog-autoheight:js-dialog-size480x320'
,p_plug_template=>wwv_flow_api.id(5051409310344291)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(37065168528503244)
,p_plug_name=>'Agregar Correos'
,p_region_name=>'ID_CORREONEW'
,p_parent_plug_id=>wwv_flow_api.id(29018885092693949)
,p_region_template_options=>'#DEFAULT#:js-dialog-autoheight:js-dialog-size480x320'
,p_plug_template=>wwv_flow_api.id(5051409310344291)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(34485394396508209)
,p_name=>'Tipo Ventas'
,p_parent_plug_id=>wwv_flow_api.id(22468875790585807)
,p_template=>wwv_flow_api.id(5058998562344289)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID_VENTAS,',
'       ID_CONTRIBUYENTE,',
'       ID_TIPO_VENTAS',
'  from VENTAS_X_MAESTRO_CONTRIBU',
'  where ID_CONTRIBUYENTE = :P112_ID_CONTRIBUYENTE'))
,p_display_when_condition=>'P112_TIPO_INSCRIPCION'
,p_display_when_cond2=>'IR'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_ajax_enabled=>'Y'
,p_query_row_template=>wwv_flow_api.id(5085249619344274)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(34485425232508210)
,p_query_column_id=>1
,p_column_alias=>'ID_VENTAS'
,p_column_display_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(34485724270508213)
,p_query_column_id=>2
,p_column_alias=>'ID_CONTRIBUYENTE'
,p_column_display_sequence=>3
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(34485622718508212)
,p_query_column_id=>3
,p_column_alias=>'ID_TIPO_VENTAS'
,p_column_display_sequence=>2
,p_column_heading=>'Tipo Ventas'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_api.id(12268996730616129)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(43137042287105925)
,p_query_column_id=>4
,p_column_alias=>'DERIVED$01'
,p_column_display_sequence=>4
,p_column_heading=>'Editar'
,p_use_as_row_header=>'N'
,p_column_link=>'javascript:$s(''P112_ID_VENTA'',''#ID_VENTAS#'');javascript:openModal(''VENTA''); $("#VENTA").trigger("apexrefresh");'
,p_column_linktext=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_derived_column=>'Y'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(43137188945105926)
,p_plug_name=>'Actualizar Tipo venta'
,p_region_name=>'VENTA'
,p_parent_plug_id=>wwv_flow_api.id(34485394396508209)
,p_region_template_options=>'#DEFAULT#:js-dialog-autoheight:js-dialog-size480x320'
,p_plug_template=>wwv_flow_api.id(5051409310344291)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(43137782083105932)
,p_plug_name=>'Agregar Tipo venta'
,p_region_name=>'NUEVA_VENTA'
,p_parent_plug_id=>wwv_flow_api.id(34485394396508209)
,p_region_template_options=>'#DEFAULT#:js-dialog-autoheight:js-dialog-size480x320'
,p_plug_template=>wwv_flow_api.id(5051409310344291)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(23270111654778527)
,p_plug_name=>unistr('Informaci\00F3n Apoderados')
,p_parent_plug_id=>wwv_flow_api.id(20102188476899430)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(5058998562344289)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(20102260121899431)
,p_name=>'Apoderados'
,p_parent_plug_id=>wwv_flow_api.id(23270111654778527)
,p_template=>wwv_flow_api.id(5058998562344289)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID_APODERADO,',
'       ID_CONTRIBUYENTE,',
'       ID_TIPO_APODERADO,',
'       NOMBRE_APODERADO,',
'       CEDULA_APODERADO,',
'       CORREO_APODERADO,',
'       ID_TIPO_IMPUESTO,',
'       INDICA_AUTORIZO,',
'       FECHA_INICIO_AUTORIZA,',
'       FECHA_FIN_AUTORIZA',
'  from APODERADOS',
'  where ID_CONTRIBUYENTE = :P112_ID_CONTRIBUYENTE',
'  and  ID_TIPO_APODERADO IS NOT NULL',
'  and  FECHA_FIN_AUTORIZA IS NULL',
'  and  INDICA_AUTORIZO = ''A''',
'  and  CODIGO_ESTADO = ''AC'''))
,p_ajax_enabled=>'Y'
,p_query_row_template=>wwv_flow_api.id(5085249619344274)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(23269158112778517)
,p_query_column_id=>1
,p_column_alias=>'ID_APODERADO'
,p_column_display_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(23269229004778518)
,p_query_column_id=>2
,p_column_alias=>'ID_CONTRIBUYENTE'
,p_column_display_sequence=>2
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(23269341038778519)
,p_query_column_id=>3
,p_column_alias=>'ID_TIPO_APODERADO'
,p_column_display_sequence=>3
,p_column_heading=>'Tipo Apoderado'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_api.id(12367820500557158)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(23269463954778520)
,p_query_column_id=>4
,p_column_alias=>'NOMBRE_APODERADO'
,p_column_display_sequence=>4
,p_column_heading=>'Nombre'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(23269554777778521)
,p_query_column_id=>5
,p_column_alias=>'CEDULA_APODERADO'
,p_column_display_sequence=>5
,p_column_heading=>unistr('C\00E9dula ')
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(23269653199778522)
,p_query_column_id=>6
,p_column_alias=>'CORREO_APODERADO'
,p_column_display_sequence=>6
,p_column_heading=>'Correo'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'VAL_OF_ITEM_IN_COND_NOT_EQ_COND2'
,p_display_when_condition=>'P112_TIPO_INSCRIPCION'
,p_display_when_condition2=>'ANRI'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(23269749343778523)
,p_query_column_id=>7
,p_column_alias=>'ID_TIPO_IMPUESTO'
,p_column_display_sequence=>7
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(23269866037778524)
,p_query_column_id=>8
,p_column_alias=>'INDICA_AUTORIZO'
,p_column_display_sequence=>8
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(23269984252778525)
,p_query_column_id=>9
,p_column_alias=>'FECHA_INICIO_AUTORIZA'
,p_column_display_sequence=>9
,p_column_heading=>unistr('Fecha Inicio Autorizaci\00F3n ')
,p_use_as_row_header=>'N'
,p_column_format=>'DD/MM/YYYY'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(23270035543778526)
,p_query_column_id=>10
,p_column_alias=>'FECHA_FIN_AUTORIZA'
,p_column_display_sequence=>10
,p_column_heading=>unistr('Fecha Fin Autorizaci\00F3n')
,p_use_as_row_header=>'N'
,p_column_format=>'DD/MM/YYYY'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'NEVER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(23271350644778539)
,p_query_column_id=>11
,p_column_alias=>'DERIVED$01'
,p_column_display_sequence=>11
,p_column_heading=>'Inactivar'
,p_use_as_row_header=>'N'
,p_column_link=>'javascript:$s(''P112_ID_APODERADO'',''#ID_APODERADO#'');javascript:openModal(''APO_ID''); $("#APO_ID").trigger("apexrefresh");'
,p_column_linktext=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_column_alignment=>'CENTER'
,p_display_when_cond_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_condition=>'P112_VAL_CANT_APO'
,p_display_when_condition2=>'N'
,p_derived_column=>'Y'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(23271747382778543)
,p_plug_name=>'Inactivar Apoderado'
,p_region_name=>'APO_ID'
,p_parent_plug_id=>wwv_flow_api.id(20102260121899431)
,p_region_template_options=>'#DEFAULT#:js-dialog-size480x320:t-Form--large'
,p_plug_template=>wwv_flow_api.id(5051409310344291)
,p_plug_display_sequence=>40
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(24903586174518614)
,p_plug_name=>'Agregar Apoderado'
,p_region_name=>'AGREGAR_APO_ID'
,p_parent_plug_id=>wwv_flow_api.id(20102260121899431)
,p_region_template_options=>'#DEFAULT#:js-dialog-size720x480'
,p_plug_template=>wwv_flow_api.id(5051409310344291)
,p_plug_display_sequence=>50
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(40840353266463601)
,p_name=>unistr('Autorizaci\00F3n Uso Firma Digital a Terceros (Autorizados por Apoderado/ Due\00F1o)')
,p_parent_plug_id=>wwv_flow_api.id(23270111654778527)
,p_template=>wwv_flow_api.id(5058998562344289)
,p_display_sequence=>50
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID_APODERADO,',
'       ID_CONTRIBUYENTE,',
'       ID_TIPO_APODERADO,',
'       NOMBRE_APODERADO,',
'       CEDULA_APODERADO,',
'       CORREO_APODERADO,',
'       --ID_TIPO_IMPUESTO,',
'       INDICA_AUTORIZO,',
'       FECHA_INICIO_AUTORIZA,',
'       FECHA_FIN_AUTORIZA',
'  from APODERADOS',
'  where ID_CONTRIBUYENTE = :P112_ID_CONTRIBUYENTE',
'  and   ID_TIPO_APODERADO IS NULL',
'  and  FECHA_FIN_AUTORIZA IS NULL ',
'  and  INDICA_AUTORIZO IN (''T'')',
'  and  CODIGO_ESTADO = ''AC'''))
,p_display_when_condition=>'P112_TIPO_INSCRIPCION'
,p_display_when_cond2=>'IR'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_ajax_enabled=>'Y'
,p_query_row_template=>wwv_flow_api.id(5085249619344274)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(40840679730463604)
,p_query_column_id=>1
,p_column_alias=>'ID_APODERADO'
,p_column_display_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(40840746273463605)
,p_query_column_id=>2
,p_column_alias=>'ID_CONTRIBUYENTE'
,p_column_display_sequence=>2
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(40840841622463606)
,p_query_column_id=>3
,p_column_alias=>'ID_TIPO_APODERADO'
,p_column_display_sequence=>3
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(40840921179463607)
,p_query_column_id=>4
,p_column_alias=>'NOMBRE_APODERADO'
,p_column_display_sequence=>4
,p_column_heading=>'Nombre'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(40841048937463608)
,p_query_column_id=>5
,p_column_alias=>'CEDULA_APODERADO'
,p_column_display_sequence=>5
,p_column_heading=>unistr('C\00E9dula ')
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(40841145147463609)
,p_query_column_id=>6
,p_column_alias=>'CORREO_APODERADO'
,p_column_display_sequence=>6
,p_column_heading=>'Correo'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>5801312104779619
,p_default_application_id=>102
,p_default_id_offset=>0
,p_default_owner=>'DESA_SIT'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(40841339103463611)
,p_query_column_id=>7
,p_column_alias=>'INDICA_AUTORIZO'
,p_column_display_sequence=>7
,p_column_heading=>'Indica Autorizo'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_inline_lov=>unistr('STATIC:Autorizaci\00F3n Uso Firma Digital;F,Autorizaci\00F3n a terceras personas;T')
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(40841435828463612)
,p_query_column_id=>8
,p_column_alias=>'FECHA_INICIO_AUTORIZA'
,p_column_display_sequence=>8
,p_column_heading=>unistr('Fecha Inicio Autorizaci\00F3n ')
,p_use_as_row_header=>'N'
,p_column_format=>'DD/MM/YYYY'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(40841562285463613)
,p_query_column_id=>9
,p_column_alias=>'FECHA_FIN_AUTORIZA'
,p_column_display_sequence=>9
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(40840536556463603)
,p_query_column_id=>10
,p_column_alias=>'DERIVED$01'
,p_column_display_sequence=>11
,p_column_heading=>'Inactivar'
,p_use_as_row_header=>'N'
,p_column_link=>'javascript:$s(''P112_ID_APO_TER'',''#ID_APODERADO#'');javascript:openModal(''AUT_ID''); $("#AUT_ID").trigger("apexrefresh");'
,p_column_linktext=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_column_alignment=>'CENTER'
,p_derived_column=>'Y'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(111927029278574202)
,p_query_column_id=>11
,p_column_alias=>'DERIVED$02'
,p_column_display_sequence=>10
,p_column_heading=>'Impuestos'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:208:&SESSION.::&DEBUG.::P208_ID_APODERADO:#ID_APODERADO#'
,p_column_linktext=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-view.png" class="apex-edit-view" alt="">'
,p_column_alignment=>'CENTER'
,p_derived_column=>'Y'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(43138861997105943)
,p_plug_name=>'Mensaje'
,p_parent_plug_id=>wwv_flow_api.id(40840353266463601)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(5058998562344289)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_source=>unistr('En mi condici\00F3n de Apoderado/Due\00F1o con facultades para otorgar el poder especial que se adjunta, autorizo a las personas abajo indicadas en el apartado \201CAutorizaci\00F3n Uso Firma Digital a Terceros (Autorizados por Apoderado/ Due\00F1o)\201D, para que firmen di')
||unistr('gitalmente en mi nombre, cualquier declaraci\00F3n jurada de impuestos sobre pasajes internacionales que recauda mi representada a favor del ICT, de conformidad con la Ley N\00B08454 de Certificados, Firmas Digitales y Documentos Electr\00F3nicos, y su Reglament')
||'o.'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(45120006360705743)
,p_plug_name=>unistr('Autorizaci\00F3n Uso Firma Digital en declaraciones juradas (Apoderado o Due\00F1o)')
,p_parent_plug_id=>wwv_flow_api.id(23270111654778527)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(5058998562344289)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_plug_source=>unistr('El suscrito en mi condici\00F3n de Due\00F1o/Apoderado con facultades solicito firmar digitalmente las declaraciones juradas de impuestos sobre pasajes internacionales que recauda mi representada a favor del ICT. De conformidad con la Ley N\00B08454 de Certifica')
||unistr('dos, Firmas Digitales y Documentos Electr\00F3nicos, y su Reglamento')
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P112_TIPO_INSCRIPCION'
,p_plug_display_when_cond2=>'IR'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(23270256938778528)
,p_name=>unistr('Autorizaci\00F3n Uso Firma Digital en declaraciones juradas (Apoderado o Due\00F1o)')
,p_parent_plug_id=>wwv_flow_api.id(45120006360705743)
,p_template=>wwv_flow_api.id(5058998562344289)
,p_display_sequence=>40
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID_APODERADO,',
'       ID_CONTRIBUYENTE,',
'       ID_TIPO_APODERADO,',
'       NOMBRE_APODERADO,',
'       CEDULA_APODERADO,',
'       CORREO_APODERADO,',
'       --ID_TIPO_IMPUESTO,',
'       INDICA_AUTORIZO,',
'       FECHA_INICIO_AUTORIZA,',
'       FECHA_FIN_AUTORIZA',
'  from APODERADOS',
'  where ID_CONTRIBUYENTE = :P112_ID_CONTRIBUYENTE',
'  and   ID_TIPO_APODERADO IS NULL',
'  and  FECHA_FIN_AUTORIZA IS NULL ',
'  and  INDICA_AUTORIZO IN (''F'')',
'  and  CODIGO_ESTADO = ''AC'''))
,p_display_when_condition=>'P112_TIPO_INSCRIPCION'
,p_display_when_cond2=>'IR'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_ajax_enabled=>'Y'
,p_query_row_template=>wwv_flow_api.id(5085249619344274)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(23270351004778529)
,p_query_column_id=>1
,p_column_alias=>'ID_APODERADO'
,p_column_display_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(23270466140778530)
,p_query_column_id=>2
,p_column_alias=>'ID_CONTRIBUYENTE'
,p_column_display_sequence=>2
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(23270523239778531)
,p_query_column_id=>3
,p_column_alias=>'ID_TIPO_APODERADO'
,p_column_display_sequence=>3
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(23270679798778532)
,p_query_column_id=>4
,p_column_alias=>'NOMBRE_APODERADO'
,p_column_display_sequence=>4
,p_column_heading=>'Nombre'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(23270735137778533)
,p_query_column_id=>5
,p_column_alias=>'CEDULA_APODERADO'
,p_column_display_sequence=>5
,p_column_heading=>unistr('C\00E9dula ')
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(23270866488778534)
,p_query_column_id=>6
,p_column_alias=>'CORREO_APODERADO'
,p_column_display_sequence=>6
,p_column_heading=>'Correo'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(23271060970778536)
,p_query_column_id=>7
,p_column_alias=>'INDICA_AUTORIZO'
,p_column_display_sequence=>7
,p_column_heading=>'Indica Autorizo'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_inline_lov=>unistr('STATIC:Autorizaci\00F3n Uso Firma Digital;F,Autorizaci\00F3n a terceras personas;T')
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(23271103369778537)
,p_query_column_id=>8
,p_column_alias=>'FECHA_INICIO_AUTORIZA'
,p_column_display_sequence=>8
,p_column_heading=>unistr('Fecha Inicio Autorizaci\00F3n ')
,p_use_as_row_header=>'N'
,p_column_format=>'DD/MM/YYYY'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(23271274128778538)
,p_query_column_id=>9
,p_column_alias=>'FECHA_FIN_AUTORIZA'
,p_column_display_sequence=>9
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(23271413983778540)
,p_query_column_id=>10
,p_column_alias=>'DERIVED$01'
,p_column_display_sequence=>11
,p_column_heading=>'Inactivar'
,p_use_as_row_header=>'N'
,p_column_link=>'javascript:$s(''P112_ID_APO_TER'',''#ID_APODERADO#'');javascript:openModal(''AUT_ID''); $("#AUT_ID").trigger("apexrefresh");'
,p_column_linktext=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_column_alignment=>'CENTER'
,p_display_when_cond_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_condition=>'P112_VAL_CANT_APO_FIRM'
,p_display_when_condition2=>'N'
,p_derived_column=>'Y'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(111926987973574201)
,p_query_column_id=>11
,p_column_alias=>'DERIVED$02'
,p_column_display_sequence=>10
,p_column_heading=>'Impuestos'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:208:&SESSION.::&DEBUG.::P208_ID_APODERADO:#ID_APODERADO#'
,p_column_linktext=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-view.png" class="apex-edit-view" alt="">'
,p_column_alignment=>'CENTER'
,p_derived_column=>'Y'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(23271851436778544)
,p_plug_name=>unistr('Inactivar Autorizaci\00F3n Uso Firma Digital')
,p_region_name=>'AUT_ID'
,p_parent_plug_id=>wwv_flow_api.id(23270256938778528)
,p_region_template_options=>'#DEFAULT#:js-dialog-size480x320'
,p_plug_template=>wwv_flow_api.id(5051409310344291)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(24904823978518627)
,p_plug_name=>unistr('Agregar Autorizaci\00F3n Uso Firma Digital')
,p_region_name=>'AGREGAR_APOTERC_ID'
,p_parent_plug_id=>wwv_flow_api.id(23270256938778528)
,p_region_template_options=>'#DEFAULT#:js-dialog-size720x480'
,p_plug_template=>wwv_flow_api.id(5051409310344291)
,p_plug_display_sequence=>40
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(24905568940518634)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(24904823978518627)
,p_button_name=>'BTN_GUARDA_APO_TERC'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5121094921344251)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Guardar'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(37064656967503239)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(37064306880503236)
,p_button_name=>'BTN_INSERTAR_TEL'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5121094921344251)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Agregar'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(37065488758503247)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(37065168528503244)
,p_button_name=>'BTN_INSERTAR_CORREO'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5121094921344251)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Agregar'
,p_button_position=>'BELOW_BOX'
,p_button_execute_validations=>'N'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(43138050860105935)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(43137782083105932)
,p_button_name=>'BTN_GUARDAR_NUEVA_VENTA'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5121094921344251)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Guardar'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(81496444029069034)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(69634519214589349)
,p_button_name=>'BTN_GUARDAR_IMP'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5121094921344251)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Guardar'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(82514017290876803)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(81497967607069049)
,p_button_name=>'BTN_INACTIVA_IMPUESTO'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5121094921344251)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Inactivar Impuesto'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(31076423841718307)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(31076046638718303)
,p_button_name=>'BTN_GUARDAR_TEL'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5121094921344251)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Guardar'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(31077262973718315)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(31076891351718311)
,p_button_name=>'BTN_GUARDAR_CORREO'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5121094921344251)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Actualizar'
,p_button_position=>'BELOW_BOX'
,p_button_execute_validations=>'N'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(83172529779933750)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(31076891351718311)
,p_button_name=>'BTN_INACTIVAR_CORREO'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5121094921344251)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Inactivar'
,p_button_position=>'BELOW_BOX'
,p_button_condition=>'P112_CANT_CORREOS'
,p_button_condition2=>'S'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_button_css_classes=>'u-color-39'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(27640319279385622)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_api.id(27639156730385610)
,p_button_name=>'BTN_GUARDAR_IMP_1'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5121094921344251)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Guardar'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(69633501644589339)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_api.id(69632959857589333)
,p_button_name=>'BTN_GUARDAR_REP_LEG'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5121094921344251)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Guardar'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(43137476786105929)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(43137188945105926)
,p_button_name=>'BTN_GUARDAR_VENTA'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5121094921344251)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Guardar'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(22508183631585765)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(22468875790585807)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5121094921344251)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Guardar'
,p_button_position=>'REGION_TEMPLATE_CHANGE'
,p_button_condition=>'P112_ID_CONTRIBUYENTE'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(22506930115585769)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(22468875790585807)
,p_button_name=>'CANCEL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5121094921344251)
,p_button_image_alt=>'Regresar'
,p_button_position=>'REGION_TEMPLATE_CREATE'
,p_button_redirect_url=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-angle-double-left'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(22508589326585764)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(22468875790585807)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5121094921344251)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Crear'
,p_button_position=>'REGION_TEMPLATE_CREATE'
,p_button_condition_type=>'NEVER'
,p_database_action=>'INSERT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(22507745335585765)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(22468875790585807)
,p_button_name=>'DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5121094921344251)
,p_button_image_alt=>'Eliminar'
,p_button_position=>'REGION_TEMPLATE_DELETE'
,p_button_redirect_url=>'javascript:apex.confirm(htmldb_delete_message,''DELETE'');'
,p_button_execute_validations=>'N'
,p_button_condition_type=>'NEVER'
,p_database_action=>'DELETE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(37064765275503240)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(29018309478693944)
,p_button_name=>'BTN_AGREGAR_TEL'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5121094921344251)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Agregar Nuevo'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_button_redirect_url=>'javascript:openModal(''NEWTEL_ID''); $("#NEWTEL_ID").trigger("apexrefresh");'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(37065061796503243)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(29018885092693949)
,p_button_name=>'BTN_AGREGAR_CORREO'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5121094921344251)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Agregar Nuevo'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_button_redirect_url=>'javascript:openModal(''ID_CORREONEW''); $("#ID_CORREONEW").trigger("apexrefresh");'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(43137689311105931)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(34485394396508209)
,p_button_name=>'BTN_AGREGAR_NUEVA_VENTA'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5121094921344251)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Agregar Nuevo'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_button_redirect_url=>'javascript:openModal(''NUEVA_VENTA''); $("#NUEVA_VENTA").trigger("apexrefresh");'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(23272370742778549)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(23271747382778543)
,p_button_name=>'BTN_INACTIVA_APO'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5121094921344251)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Inactivar'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(24903273855518611)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(23271851436778544)
,p_button_name=>'BTN_INACTIVA_TERC'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5121094921344251)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Inactivar'
,p_button_position=>'REGION_TEMPLATE_NEXT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(24904144156518620)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_api.id(24903586174518614)
,p_button_name=>'BTN_GUARDA_APO'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5121094921344251)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Guardar'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_button_execute_validations=>'N'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(23271591709778541)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(20102260121899431)
,p_button_name=>'BTN_AGREGAR_APO'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5121094921344251)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Agregar Nuevo'
,p_button_position=>'TOP'
,p_button_redirect_url=>'javascript:openModal(''AGREGAR_APO_ID''); $("#AGREGAR_APO_ID").trigger("apexrefresh");'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(23271685865778542)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(23270256938778528)
,p_button_name=>'BTN_AGREGAR_FIRMA'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5121094921344251)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Agregar Nuevo'
,p_button_position=>'TOP'
,p_button_redirect_url=>'javascript:$s(''P112_TIPO_AUT'',''F'');javascript:openModal(''AGREGAR_APOTERC_ID''); $("#AGREGAR_APOTERC_ID").trigger("apexrefresh");'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(40840444667463602)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(40840353266463601)
,p_button_name=>'BTN_AGREGAR_TERCERO'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5121094921344251)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Agregar Nuevo'
,p_button_position=>'TOP'
,p_button_redirect_url=>'javascript:$s(''P112_TIPO_AUT'',''T'');javascript:openModal(''AGREGAR_APOTERC_ID''); $("#AGREGAR_APOTERC_ID").trigger("apexrefresh");'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(69632856690589332)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(23268529494778511)
,p_button_name=>'BTN_ACT_REPRE_LEGAL'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5121094921344251)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Actualizar Rep. Legal'
,p_button_position=>'TOP'
,p_button_redirect_url=>'javascript:$s(''P112_CORREO_REP_LEG'',''&P112_CORREO_REPRE_LEGAL.'');javascript:$s(''P112_CED_REP_LEG'',''&P112_CEDULA_REPRE_LEGAL.'');javascript:$s(''P112_NOM_REP_LEG'',''&P112_NOMBRE_REPRE_LEGAL.'');javascript:openModal(''ID_REP_LEG''); $("#ID_REP_LEG").trigger("apexrefresh");'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(69634445852589348)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(29017723106693938)
,p_button_name=>'BTN_AGREGAR_IMPUESTO'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5121094921344251)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Agregar Impuesto'
,p_button_position=>'TOP'
,p_button_redirect_url=>'javascript:openModal(''ID_IMPUESTO''); $("#ID_IMPUESTO").trigger("apexrefresh");'
,p_button_condition=>'P112_TIPO_CONTRIB'
,p_button_condition2=>'S'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(22508885627585764)
,p_branch_name=>'Go To Page 112'
,p_branch_action=>'f?p=&APP_ID.:112:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(22508183631585765)
,p_branch_sequence=>1
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(43432777719015949)
,p_branch_name=>'Go To Page 126'
,p_branch_action=>'f?p=&APP_ID.:126:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>11
,p_branch_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_branch_condition=>'P112_BRANCH'
,p_branch_condition_text=>'S'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(22469108483585800)
,p_name=>'P112_ID_CONTRIBUYENTE'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(20102354299899432)
,p_item_source_plug_id=>wwv_flow_api.id(22468875790585807)
,p_source=>'ID_CONTRIBUYENTE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(22469587767585794)
,p_name=>'P112_NOMBRE_ENTIDAD'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(20102354299899432)
,p_item_source_plug_id=>wwv_flow_api.id(22468875790585807)
,p_prompt=>'Nombre de la entidad:'
,p_source=>'NOMBRE_ENTIDAD'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(5119791289344256)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(22469945940585790)
,p_name=>'P112_ID_TIPO_IDENTIFICACION'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(20102354299899432)
,p_item_source_plug_id=>wwv_flow_api.id(22468875790585807)
,p_prompt=>unistr('Tipo Identificaci\00F3n:')
,p_source=>'ID_TIPO_IDENTIFICACION'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT NOMBRE_IDENTIFICA, ID_TIPO_IDENTIFICACION FROM TIPO_IDENTIFICACION',
'WHERE ID_TIPO_IDENTIFICACION = :P112_ID_TIPO_IDENTIFICACION'))
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(5119791289344256)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(22470332400585789)
,p_name=>'P112_RAZON_SOCIAL'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(20102354299899432)
,p_item_source_plug_id=>wwv_flow_api.id(22468875790585807)
,p_prompt=>unistr('Raz\00F3n Social:')
,p_source=>'RAZON_SOCIAL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_display_when=>'P112_ID_TIPO_IDENTIFICACION'
,p_display_when2=>'1'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_api.id(5119791289344256)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(22470701850585789)
,p_name=>'P112_PERSONA_FISICA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(20102354299899432)
,p_item_source_plug_id=>wwv_flow_api.id(22468875790585807)
,p_prompt=>'Persona Fisica:'
,p_source=>'PERSONA_FISICA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>100
,p_display_when=>'P112_VALIDA_PERS_FISICA'
,p_display_when2=>'S'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_api.id(5119791289344256)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(22471199901585789)
,p_name=>'P112_CEDULA_JURIDICA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(20102354299899432)
,p_item_source_plug_id=>wwv_flow_api.id(22468875790585807)
,p_prompt=>unistr('Documento Identificaci\00F3n:')
,p_source=>'CEDULA_JURIDICA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_display_when=>'P112_CEDULA_JURIDICA'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>wwv_flow_api.id(5119791289344256)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(22471545863585789)
,p_name=>'P112_CEDULA_FISICA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_api.id(20102354299899432)
,p_item_source_plug_id=>wwv_flow_api.id(22468875790585807)
,p_prompt=>unistr('Documento Identificaci\00F3n:')
,p_source=>'CEDULA_FISICA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_display_when=>'P112_CEDULA_FISICA'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>wwv_flow_api.id(5119791289344256)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(22471994738585788)
,p_name=>'P112_ID_TIPO_CONTRIBUYENTE'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(20102354299899432)
,p_item_source_plug_id=>wwv_flow_api.id(22468875790585807)
,p_prompt=>'Tipo Contribuyente:'
,p_source=>'ID_TIPO_CONTRIBUYENTE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DESCRIPCION,ID_TIPO_CONTRIBUYENTE',
'FROM   TIPO_CONTRIBUYENTE',
'WHERE CODIGO_ESTADO = ''AC''',
'AND IND_TIPO_INSCRIP IN (:P112_TIPO_INSCRIPCION)',
'AND  ID_TIPO_CONTRIBUYENTE = :P112_ID_TIPO_CONTRIBUYENTE'))
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(5119791289344256)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(22472388800585788)
,p_name=>'P112_CODIGO_IATA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(20102354299899432)
,p_item_source_plug_id=>wwv_flow_api.id(22468875790585807)
,p_prompt=>unistr('C\00F3digo Iata:')
,p_source=>'CODIGO_IATA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_display_when=>'P112_VAL_COD_IATA'
,p_display_when2=>'S'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_api.id(5119791289344256)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(22473176029585788)
,p_name=>'P112_FECHA_INICIO_OPERA'
,p_source_data_type=>'DATE'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_api.id(20102354299899432)
,p_item_source_plug_id=>wwv_flow_api.id(22468875790585807)
,p_prompt=>'Inicio Operaciones:'
,p_format_mask=>'DD/MM/YYYY'
,p_source=>'FECHA_INICIO_OPERA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_display_when=>'P112_TIPO_INSCRIPCION'
,p_display_when2=>'ANRI'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_NOT_EQ_COND2'
,p_field_template=>wwv_flow_api.id(5119791289344256)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(22473533986585788)
,p_name=>'P112_DIRECCION_ENTIDAD'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_api.id(20102494035899433)
,p_item_source_plug_id=>wwv_flow_api.id(22468875790585807)
,p_prompt=>unistr('Direcci\00F3n:')
,p_source=>'DIRECCION_ENTIDAD'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>70
,p_cMaxlength=>1000
,p_cHeight=>4
,p_display_when=>'P112_TIPO_INSCRIPCION'
,p_display_when2=>'IVC'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_NOT_EQ_COND2'
,p_field_template=>wwv_flow_api.id(5119791289344256)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>5801312104779619
,p_default_application_id=>102
,p_default_id_offset=>0
,p_default_owner=>'DESA_SIT'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(22473939205585787)
,p_name=>'P112_ID_PROVINCIA_ENTIDAD'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_api.id(20102494035899433)
,p_item_source_plug_id=>wwv_flow_api.id(22468875790585807)
,p_prompt=>'Provincia:'
,p_source=>'ID_PROVINCIA_ENTIDAD'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'SELECT DESCRIPCION, ID FROM PROVINCIAS@consulta_ictx'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_display_when=>'P112_TIPO_INSCRIPCION'
,p_display_when2=>'ANRI'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_NOT_EQ_COND2'
,p_field_template=>wwv_flow_api.id(5119791289344256)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(22474389910585787)
,p_name=>'P112_ID_CANTON_ENTIDAD'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_api.id(20102494035899433)
,p_item_source_plug_id=>wwv_flow_api.id(22468875790585807)
,p_prompt=>unistr('Cant\00F3n:')
,p_source=>'ID_CANTON_ENTIDAD'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'SELECT DESCRIPCION, ID FROM CANTONES@consulta_ictx WHERE PROV_ID = :P112_ID_PROVINCIA_ENTIDAD'
,p_lov_display_null=>'YES'
,p_lov_cascade_parent_items=>'P112_ID_PROVINCIA_ENTIDAD'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_display_when=>'P112_TIPO_INSCRIPCION'
,p_display_when2=>'ANRI'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_NOT_EQ_COND2'
,p_field_template=>wwv_flow_api.id(5119791289344256)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(22474704293585787)
,p_name=>'P112_ID_DISTRITO_ENTIDAD'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_api.id(20102494035899433)
,p_item_source_plug_id=>wwv_flow_api.id(22468875790585807)
,p_prompt=>'Distrito:'
,p_source=>'ID_DISTRITO_ENTIDAD'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DESCRIPCION, ID ',
'FROM DISTRITOS@consulta_ictx ',
'WHERE PROV_ID = :P112_ID_PROVINCIA_ENTIDAD',
'AND CANTON_ID = :P112_ID_CANTON_ENTIDAD'))
,p_lov_display_null=>'YES'
,p_lov_cascade_parent_items=>'P112_ID_PROVINCIA_ENTIDAD,P112_ID_CANTON_ENTIDAD'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_display_when=>'P112_TIPO_INSCRIPCION'
,p_display_when2=>'ANRI'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_NOT_EQ_COND2'
,p_field_template=>wwv_flow_api.id(5119791289344256)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(22475100675585786)
,p_name=>'P112_DIRECCION_NOTIFICA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>210
,p_item_plug_id=>wwv_flow_api.id(20103429228899443)
,p_item_source_plug_id=>wwv_flow_api.id(22468875790585807)
,p_prompt=>unistr('Direcci\00F3n:')
,p_source=>'DIRECCION_NOTIFICA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>70
,p_cMaxlength=>800
,p_cHeight=>4
,p_field_template=>wwv_flow_api.id(5119791289344256)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(22475523018585786)
,p_name=>'P112_ID_PROVINCIA_NOTIFICA'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_api.id(20103429228899443)
,p_item_source_plug_id=>wwv_flow_api.id(22468875790585807)
,p_prompt=>'Provincia:'
,p_source=>'ID_PROVINCIA_NOTIFICA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'SELECT DESCRIPCION, ID FROM PROVINCIAS@consulta_ictx'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(5119791289344256)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(22475912218585786)
,p_name=>'P112_ID_CANTON_NOTIFICA'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_api.id(20103429228899443)
,p_item_source_plug_id=>wwv_flow_api.id(22468875790585807)
,p_prompt=>unistr('Cant\00F3n:')
,p_source=>'ID_CANTON_NOTIFICA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'SELECT DESCRIPCION, ID FROM CANTONES@consulta_ictx WHERE PROV_ID = :P112_ID_PROVINCIA_NOTIFICA'
,p_lov_display_null=>'YES'
,p_lov_cascade_parent_items=>'P112_ID_PROVINCIA_NOTIFICA'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(5119791289344256)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(22476398392585786)
,p_name=>'P112_ID_DISTRITO_NOTIFICA'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>200
,p_item_plug_id=>wwv_flow_api.id(20103429228899443)
,p_item_source_plug_id=>wwv_flow_api.id(22468875790585807)
,p_prompt=>'Distrito:'
,p_source=>'ID_DISTRITO_NOTIFICA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DESCRIPCION, ID ',
'FROM DISTRITOS@consulta_ictx ',
'WHERE PROV_ID = :P112_ID_PROVINCIA_NOTIFICA',
'AND CANTON_ID = :P112_ID_CANTON_NOTIFICA'))
,p_lov_display_null=>'YES'
,p_lov_cascade_parent_items=>'P112_ID_PROVINCIA_NOTIFICA,P112_ID_CANTON_NOTIFICA'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(5119791289344256)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(22476733771585786)
,p_name=>'P112_CEDULA_GERENTE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>220
,p_item_plug_id=>wwv_flow_api.id(23268473583778510)
,p_item_source_plug_id=>wwv_flow_api.id(22468875790585807)
,p_prompt=>unistr('C\00E9dula:')
,p_source=>'CEDULA_GERENTE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>25
,p_field_template=>wwv_flow_api.id(5119791289344256)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(22477134045585785)
,p_name=>'P112_NOMBRE_GERENTE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>210
,p_item_plug_id=>wwv_flow_api.id(23268473583778510)
,p_item_source_plug_id=>wwv_flow_api.id(22468875790585807)
,p_prompt=>'Nombre:'
,p_source=>'NOMBRE_GERENTE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>80
,p_field_template=>wwv_flow_api.id(5119791289344256)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(22477597390585785)
,p_name=>'P112_CORREO_GERENTE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>230
,p_item_plug_id=>wwv_flow_api.id(23268473583778510)
,p_item_source_plug_id=>wwv_flow_api.id(22468875790585807)
,p_prompt=>'Correo:'
,p_source=>'CORREO_GERENTE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>50
,p_field_template=>wwv_flow_api.id(5119791289344256)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(22477906234585785)
,p_name=>'P112_NOMBRE_REPRE_LEGAL'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>230
,p_item_plug_id=>wwv_flow_api.id(23268529494778511)
,p_item_source_plug_id=>wwv_flow_api.id(22468875790585807)
,p_prompt=>'Nombre:'
,p_source=>'NOMBRE_REPRE_LEGAL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(5119791289344256)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(22478319777585785)
,p_name=>'P112_CEDULA_REPRE_LEGAL'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>240
,p_item_plug_id=>wwv_flow_api.id(23268529494778511)
,p_item_source_plug_id=>wwv_flow_api.id(22468875790585807)
,p_prompt=>unistr('C\00E9dula:')
,p_source=>'CEDULA_REPRE_LEGAL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(5119791289344256)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(22478740913585785)
,p_name=>'P112_CORREO_REPRE_LEGAL'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>250
,p_item_plug_id=>wwv_flow_api.id(23268529494778511)
,p_item_source_plug_id=>wwv_flow_api.id(22468875790585807)
,p_prompt=>'Correo:'
,p_source=>'CORREO_REPRE_LEGAL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_display_when=>'P112_TIPO_INSCRIPCION'
,p_display_when2=>'ANRI'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_NOT_EQ_COND2'
,p_field_template=>wwv_flow_api.id(5119791289344256)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(22479112609585785)
,p_name=>'P112_CODIGO_ESTADO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_api.id(20102354299899432)
,p_item_source_plug_id=>wwv_flow_api.id(22468875790585807)
,p_source=>'CODIGO_ESTADO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(22479564437585784)
,p_name=>'P112_FECHA_INSCRIPCION'
,p_source_data_type=>'DATE'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_api.id(20102354299899432)
,p_item_source_plug_id=>wwv_flow_api.id(22468875790585807)
,p_prompt=>unistr('Fecha Inscripci\00F3n:')
,p_format_mask=>'DD/MM/YYYY'
,p_source=>'FECHA_INSCRIPCION'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(5119791289344256)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(22479944349585784)
,p_name=>'P112_FECHA_CESE_OPERA'
,p_source_data_type=>'DATE'
,p_item_sequence=>280
,p_item_plug_id=>wwv_flow_api.id(22468875790585807)
,p_item_source_plug_id=>wwv_flow_api.id(22468875790585807)
,p_source=>'FECHA_CESE_OPERA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(22480396134585784)
,p_name=>'P112_FECHA_INICIO_VENTAS'
,p_source_data_type=>'DATE'
,p_item_sequence=>290
,p_item_plug_id=>wwv_flow_api.id(22468875790585807)
,p_item_source_plug_id=>wwv_flow_api.id(22468875790585807)
,p_source=>'FECHA_INICIO_VENTAS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(22480705028585784)
,p_name=>'P112_OBSERVA_EMPRESA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>300
,p_item_plug_id=>wwv_flow_api.id(22468875790585807)
,p_item_source_plug_id=>wwv_flow_api.id(22468875790585807)
,p_source=>'OBSERVA_EMPRESA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(22481145061585784)
,p_name=>'P112_OBSERVA_ADM_TRIBUTA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>310
,p_item_plug_id=>wwv_flow_api.id(22468875790585807)
,p_item_source_plug_id=>wwv_flow_api.id(22468875790585807)
,p_source=>'OBSERVA_ADM_TRIBUTA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(22481552484585783)
,p_name=>'P112_ID_MODALIDAD'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>320
,p_item_plug_id=>wwv_flow_api.id(22468875790585807)
,p_item_source_plug_id=>wwv_flow_api.id(22468875790585807)
,p_source=>'ID_MODALIDAD'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(22481910866585783)
,p_name=>'P112_CODIGO_FUENTE'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>330
,p_item_plug_id=>wwv_flow_api.id(22468875790585807)
,p_item_source_plug_id=>wwv_flow_api.id(22468875790585807)
,p_source=>'CODIGO_FUENTE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(22482375234585783)
,p_name=>'P112_CEDULA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>340
,p_item_plug_id=>wwv_flow_api.id(22468875790585807)
,p_item_source_plug_id=>wwv_flow_api.id(22468875790585807)
,p_source=>'CEDULA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(22482775511585783)
,p_name=>'P112_CODIGO_EMPLEADO'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>350
,p_item_plug_id=>wwv_flow_api.id(22468875790585807)
,p_item_source_plug_id=>wwv_flow_api.id(22468875790585807)
,p_source=>'CODIGO_EMPLEADO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(22483144351585783)
,p_name=>'P112_ID_DEUDOR'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(20102354299899432)
,p_item_source_plug_id=>wwv_flow_api.id(22468875790585807)
,p_prompt=>unistr('C\00F3digo Registro:')
,p_source=>'ID_DEUDOR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(5119791289344256)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(22483503150585781)
,p_name=>'P112_FECHA_SUSCRITO'
,p_source_data_type=>'DATE'
,p_item_sequence=>370
,p_item_plug_id=>wwv_flow_api.id(22468875790585807)
,p_item_source_plug_id=>wwv_flow_api.id(22468875790585807)
,p_source=>'FECHA_SUSCRITO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(22483925083585781)
,p_name=>'P112_LUGAR_SUSCRITO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>380
,p_item_plug_id=>wwv_flow_api.id(22468875790585807)
,p_item_source_plug_id=>wwv_flow_api.id(22468875790585807)
,p_source=>'LUGAR_SUSCRITO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(22484374153585781)
,p_name=>'P112_ID_TIPO_PUESTO'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>390
,p_item_plug_id=>wwv_flow_api.id(22468875790585807)
,p_item_source_plug_id=>wwv_flow_api.id(22468875790585807)
,p_source=>'ID_TIPO_PUESTO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(22484764678585781)
,p_name=>'P112_ID_CHARTER'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>400
,p_item_plug_id=>wwv_flow_api.id(22468875790585807)
,p_item_source_plug_id=>wwv_flow_api.id(22468875790585807)
,p_source=>'ID_CHARTER'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(22485172060585780)
,p_name=>'P112_NUM_EXPEDIENTE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>410
,p_item_plug_id=>wwv_flow_api.id(22468875790585807)
,p_item_source_plug_id=>wwv_flow_api.id(22468875790585807)
,p_source=>'NUM_EXPEDIENTE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(22485572995585780)
,p_name=>'P112_OTRA_ID'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>420
,p_item_plug_id=>wwv_flow_api.id(22468875790585807)
,p_item_source_plug_id=>wwv_flow_api.id(22468875790585807)
,p_source=>'OTRA_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(22485917630585780)
,p_name=>'P112_PROPIETARIO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>430
,p_item_plug_id=>wwv_flow_api.id(22468875790585807)
,p_item_source_plug_id=>wwv_flow_api.id(22468875790585807)
,p_source=>'PROPIETARIO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(22486395871585780)
,p_name=>'P112_DOMICILIO_FISCAL'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>440
,p_item_plug_id=>wwv_flow_api.id(22468875790585807)
,p_item_source_plug_id=>wwv_flow_api.id(22468875790585807)
,p_source=>'DOMICILIO_FISCAL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(22486704117585780)
,p_name=>'P112_RESPONSABLE_TRIBUTARIO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_api.id(20102354299899432)
,p_item_source_plug_id=>wwv_flow_api.id(22468875790585807)
,p_prompt=>'Encargado Reporte Semestral:'
,p_source=>'RESPONSABLE_TRIBUTARIO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_display_when=>'P112_TIPO_INSCRIPCION'
,p_display_when2=>'ANRI'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_api.id(5119791289344256)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(22487133848585780)
,p_name=>'P112_SITIO_WEB'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>460
,p_item_plug_id=>wwv_flow_api.id(22468875790585807)
,p_item_source_plug_id=>wwv_flow_api.id(22468875790585807)
,p_source=>'SITIO_WEB'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(22487546336585779)
,p_name=>'P112_HABITACIONES'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>470
,p_item_plug_id=>wwv_flow_api.id(22468875790585807)
,p_item_source_plug_id=>wwv_flow_api.id(22468875790585807)
,p_source=>'HABITACIONES'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(22487963375585779)
,p_name=>'P112_FECHA_INGRESO'
,p_source_data_type=>'DATE'
,p_item_sequence=>480
,p_item_plug_id=>wwv_flow_api.id(22468875790585807)
,p_item_source_plug_id=>wwv_flow_api.id(22468875790585807)
,p_source=>'FECHA_INGRESO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(22488342576585779)
,p_name=>'P112_TIPO_PAGO_TARIFA'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>490
,p_item_plug_id=>wwv_flow_api.id(22468875790585807)
,p_item_source_plug_id=>wwv_flow_api.id(22468875790585807)
,p_source=>'TIPO_PAGO_TARIFA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(22488756034585779)
,p_name=>'P112_EMPLEO_TEMPORADA_BAJA'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>500
,p_item_plug_id=>wwv_flow_api.id(22468875790585807)
,p_item_source_plug_id=>wwv_flow_api.id(22468875790585807)
,p_source=>'EMPLEO_TEMPORADA_BAJA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(22489127513585779)
,p_name=>'P112_EMPLEO_TEMPORADA_ALTA'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>510
,p_item_plug_id=>wwv_flow_api.id(22468875790585807)
,p_item_source_plug_id=>wwv_flow_api.id(22468875790585807)
,p_source=>'EMPLEO_TEMPORADA_ALTA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(22489561322585778)
,p_name=>'P112_ID_TIPO_SERVICIO'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>520
,p_item_plug_id=>wwv_flow_api.id(22468875790585807)
,p_item_source_plug_id=>wwv_flow_api.id(22468875790585807)
,p_source=>'ID_TIPO_SERVICIO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(22489948342585778)
,p_name=>'P112_NUMERO_ESTRELLAS'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>530
,p_item_plug_id=>wwv_flow_api.id(22468875790585807)
,p_item_source_plug_id=>wwv_flow_api.id(22468875790585807)
,p_source=>'NUMERO_ESTRELLAS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(22490320047585777)
,p_name=>'P112_ID_NUM_INSCRIPCION'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>540
,p_item_plug_id=>wwv_flow_api.id(22468875790585807)
,p_item_source_plug_id=>wwv_flow_api.id(22468875790585807)
,p_source=>'ID_NUM_INSCRIPCION'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(23271929495778545)
,p_name=>'P112_NOM_APODERADO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(23271747382778543)
,p_prompt=>'Apoderado'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT NOMBRE_APODERADO, ID_APODERADO',
'FROM APODERADOS ',
'WHERE ID_APODERADO = :P112_ID_APODERADO',
'--AND   ID_CONTRIBUYENTE = :P112_ID_CONTRIBUYENTE',
''))
,p_lov_cascade_parent_items=>'P112_ID_APODERADO'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(5119886074344255)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(23272001594778546)
,p_name=>'P112_ID_APO_TER'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(23271851436778544)
,p_display_as=>'NATIVE_HIDDEN'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(23272169431778547)
,p_name=>'P112_ID_APODERADO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(23271747382778543)
,p_display_as=>'NATIVE_HIDDEN'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(24903310716518612)
,p_name=>'P112_NOM_APO_TERC'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(23271851436778544)
,p_prompt=>'Apoderado'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT NOMBRE_APODERADO, ID_APODERADO',
'FROM APODERADOS ',
'WHERE ID_APODERADO = :P112_ID_APO_TER',
'--AND   ID_CONTRIBUYENTE = :P112_ID_CONTRIBUYENTE',
''))
,p_lov_cascade_parent_items=>'P112_ID_APO_TER'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(5119886074344255)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(24903664943518615)
,p_name=>'P112_ID_CONTRIBU'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(24903586174518614)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(24903753671518616)
,p_name=>'P112_TIPO_APODERADO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(24903586174518614)
,p_prompt=>'Tipo:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_TIPO_APODERADO'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(5119791289344256)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(24903888107518617)
,p_name=>'P112_NOMBRE_APODERADO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(24903586174518614)
,p_prompt=>'Nombre:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>50
,p_field_template=>wwv_flow_api.id(5119791289344256)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(24903990571518618)
,p_name=>'P112_CEDULA_APODERADO'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(24903586174518614)
,p_prompt=>unistr('C\00E9dula: ')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(5119791289344256)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_help_text=>unistr('Por favor ingresar el n\00FAmero de c\00E9dula sin espacios y sin guiones ejemplo (102220333)')
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(24904087796518619)
,p_name=>'P112_CORREO_APODERADO'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(24903586174518614)
,p_prompt=>'Correo:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(5119791289344256)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(24904709674518626)
,p_name=>'P112_PODER_LEGAL_APO'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(24903586174518614)
,p_prompt=>unistr('Adjuntar Personer\00EDa Jur\00EDdica:')
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_tag_attributes=>'accept=".pdf,.jpeg,.png"'
,p_field_template=>wwv_flow_api.id(5120038037344255)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(24905163730518630)
,p_name=>'P112_NOMBRE_APO_TERC'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(24904823978518627)
,p_prompt=>'Nombre:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>50
,p_field_template=>wwv_flow_api.id(5119791289344256)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(24905206436518631)
,p_name=>'P112_CEDULA_APO_TERC'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(24904823978518627)
,p_prompt=>unistr('C\00E9dula: ')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(5119791289344256)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(24905322415518632)
,p_name=>'P112_CORREO_APO_TERC'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(24904823978518627)
,p_prompt=>'Correo:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(5119791289344256)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(24905418300518633)
,p_name=>'P112_PODER_LEGAL_TERC'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(24904823978518627)
,p_prompt=>unistr('Personer\00EDa Jur\00EDdica:')
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_tag_attributes=>'accept=".pdf,.jpeg,.png"'
,p_field_template=>wwv_flow_api.id(5120038037344255)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(24906108523518640)
,p_name=>'P112_TIPO_IMPUESTO'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(24904823978518627)
,p_prompt=>'Tipo Impuesto:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT PKG_MAESTRO_CONTRIBUYENTE.RETORNA_DESCRIP_TIPO_IMPUESTO (ID_TIPO_IMPUESTO)NOM_IMPUESTO,',
'       ID_TIPO_IMPUESTO',
'FROM IMPUESTO_X_MAESTRO_CONTRIBUYE',
'WHERE ID_CONTRIBUYENTE = :P112_ID_CONTRIBUYENTE',
'AND   CODIGO_ESTADO = ''AC''',
'--AND   ID_TIPO_IMPUESTO NOT IN (SELECT ID_TIPO_IMPUESTO FROM IMPUESTO_X_MAESTRO_CONTRIBUYE WHERE ID_CONTRIBUYENTE = :P112_ID_CONTRIBUYENTE)'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(5119791289344256)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(27639213928385611)
,p_name=>'P112_IMPUESTO_1'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(27639156730385610)
,p_prompt=>'Tipo Impuesto:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT PKG_MAESTRO_CONTRIBUYENTE.RETORNA_DESCRIP_TIPO_IMPUESTO (ID_TIPO_IMPUESTO)NOM_IMPUESTO,',
'       ID_TIPO_IMPUESTO',
'FROM TIPO_IMPUESTO_CONTRIB',
'WHERE ID_TIPO_CONTRIB = :P112_ID_TIPO_CONTRIBUYENTE',
'--AND   ID_IMPUESTO = :P112_ID_IMPUESTO',
'AND   ID_TIPO_IMPUESTO IN (SELECT ID_TIPO_IMPUESTO FROM IMPUESTO_X_MAESTRO_CONTRIBUYE WHERE ID_CONTRIBUYENTE = :P112_ID_CONTRIBU ',
'                            AND CODIGO_ESTADO = ''AC'')',
''))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_colspan=>5
,p_grid_column=>3
,p_field_template=>wwv_flow_api.id(5119886074344255)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(27639315876385612)
,p_name=>'P112_NOMBRE_ENCAR_1'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(27639156730385610)
,p_prompt=>'Nombre Encargado:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>50
,p_grid_column=>3
,p_field_template=>wwv_flow_api.id(5120101748344255)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(27639549197385614)
,p_name=>'P112_CEDULA_ENCAR_1'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(27639156730385610)
,p_prompt=>'Cedula Encargado:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>50
,p_grid_column=>3
,p_field_template=>wwv_flow_api.id(5120101748344255)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>5801312104779619
,p_default_application_id=>102
,p_default_id_offset=>0
,p_default_owner=>'DESA_SIT'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(27639720167385616)
,p_name=>'P112_CORREO_ENCAR_1'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(27639156730385610)
,p_prompt=>'Correo Encargado:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_grid_column=>3
,p_field_template=>wwv_flow_api.id(5119973298344255)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(31076211674718305)
,p_name=>'P112_ID_TEL'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(31076046638718303)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(31076319313718306)
,p_name=>'P112_NEW_TELEFONO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(31076046638718303)
,p_prompt=>unistr('Nuevo Tel\00E9fono:')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(5119973298344255)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(31077060973718313)
,p_name=>'P112_ID_CORREO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(31076891351718311)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(31077107043718314)
,p_name=>'P112_NEW_CORREO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(31076891351718311)
,p_prompt=>'Correo Nuevo:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(5119973298344255)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(31077654772718319)
,p_name=>'P112_TIPO_INSCRIPCION'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(20102188476899430)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(31077719750718320)
,p_name=>'P112_NOM_ASISTENTE_CHARTER'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(23268679688778512)
,p_item_source_plug_id=>wwv_flow_api.id(22468875790585807)
,p_prompt=>'Nombre:'
,p_source=>'NOM_ASISTENTE_CHARTER'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>80
,p_field_template=>wwv_flow_api.id(5119791289344256)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(31077831046718321)
,p_name=>'P112_CEDULA_ASISTENTE_CHARTER'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(23268679688778512)
,p_item_source_plug_id=>wwv_flow_api.id(22468875790585807)
,p_prompt=>'Cedula:'
,p_source=>'CEDULA_ASISTENTE_CHARTER'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>20
,p_field_template=>wwv_flow_api.id(5119791289344256)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(31077995161718322)
,p_name=>'P112_CORREO_ASISTENTE_CHARTER'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(23268679688778512)
,p_item_source_plug_id=>wwv_flow_api.id(22468875790585807)
,p_prompt=>'Correo:'
,p_source=>'CORREO_ASISTENTE_CHARTER'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>40
,p_field_template=>wwv_flow_api.id(5119791289344256)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(34182376981231303)
,p_name=>'P112_CONTRIBUYENTE_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(20102354299899432)
,p_prompt=>'# Contribuyente:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(5119791289344256)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(34915218764293011)
,p_name=>'P112_TIPO_AUT'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(24904823978518627)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(35184865257676620)
,p_name=>'P112_NOMBRE_REGION'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(20102188476899430)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(37064521096503238)
,p_name=>'P112_TELEFONO_NUEVO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(37064306880503236)
,p_prompt=>unistr('Nuevo Tel\00E9fono:')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(5119973298344255)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(37064932778503242)
,p_name=>'P112_TIPO_TEL'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(37064306880503236)
,p_prompt=>unistr('Tipo Tel\00E9fono:')
,p_display_as=>'NATIVE_RADIOGROUP'
,p_named_lov=>'TIPO_TELEFONO'
,p_field_template=>wwv_flow_api.id(5119886074344255)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'3'
,p_attribute_02=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(37065302206503246)
,p_name=>'P112_CORREO_NUEVO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(37065168528503244)
,p_prompt=>'Correo Nuevo:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(5119973298344255)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(37922040494042515)
,p_name=>'P112_VALIDA_PERS_FISICA'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(20102188476899430)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(43137296582105927)
,p_name=>'P112_ID_VENTA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(43137188945105926)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(43137355364105928)
,p_name=>'P112_ID_TIPO_VENTA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(43137188945105926)
,p_prompt=>'Nuevo Tipo Venta:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_TIPO_VENTA'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(5119973298344255)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(43137976637105934)
,p_name=>'P112_ID_TIPO_VENTA_NUEVA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(43137782083105932)
,p_prompt=>'Nuevo Tipo Venta:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_TIPO_VENTA'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(5119973298344255)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(43138716388105942)
,p_name=>'P112_VAL_CANT_APO_FIRM'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(20102188476899430)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(43138951047105944)
,p_name=>'P112_VAL_COD_IATA'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(20102188476899430)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(43432810997015950)
,p_name=>'P112_BRANCH'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(23270111654778527)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(45120107092705744)
,p_name=>'P112_VAL_CANT_APO'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(20102188476899430)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(69633070630589334)
,p_name=>'P112_NOM_REP_LEG'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(69632959857589333)
,p_prompt=>'Nombre:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_field_template=>wwv_flow_api.id(5119791289344256)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(69633112114589335)
,p_name=>'P112_CED_REP_LEG'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(69632959857589333)
,p_prompt=>'Cedula:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(5119791289344256)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(69633293240589336)
,p_name=>'P112_CORREO_REP_LEG'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(69632959857589333)
,p_prompt=>'Correo:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(5119791289344256)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(69633336423589337)
,p_name=>'P112_ARC_REP_LEG1'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(69632959857589333)
,p_prompt=>'Cedula representante:'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(5120038037344255)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
,p_attribute_11=>'.pdf'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(69633427080589338)
,p_name=>'P112_ARC_REP_LEG2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(69632959857589333)
,p_prompt=>unistr('Personer\00EDa jur\00EDdica:')
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(5120038037344255)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
,p_attribute_11=>'.pdf'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(69633692408589340)
,p_name=>'P112_ARC_CED_APO'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(24903586174518614)
,p_prompt=>'Cedula Apoderado:'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_tag_attributes=>'accept=".pdf,.jpeg,.png"'
,p_field_template=>wwv_flow_api.id(5120038037344255)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(69634640869589350)
,p_name=>'P112_IMPUESTO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(69634519214589349)
,p_prompt=>'Tipo Impuesto:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT PKG_MAESTRO_CONTRIBUYENTE.RETORNA_DESCRIP_TIPO_IMPUESTO (ID_TIPO_IMPUESTO)NOM_IMPUESTO,',
'       ID_TIPO_IMPUESTO',
'FROM TIPO_IMPUESTO_CONTRIB',
'WHERE ID_TIPO_CONTRIB = :P112_ID_TIPO_CONTRIBUYENTE',
'AND   CODIGO_ESTADO = ''AC''',
'AND   ID_TIPO_IMPUESTO NOT IN (SELECT ID_TIPO_IMPUESTO ',
'                               FROM IMPUESTO_X_MAESTRO_CONTRIBUYE ',
'                               WHERE ID_CONTRIBUYENTE = :P112_ID_CONTRIBUYENTE ',
'                               AND CODIGO_ESTADO = ''AC'')'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_grid_column=>3
,p_field_template=>wwv_flow_api.id(5120101748344255)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(81496552126069035)
,p_name=>'P112_NOMBRE_ENCAR'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(69634519214589349)
,p_prompt=>'Nombre Encargado:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>50
,p_grid_column=>3
,p_field_template=>wwv_flow_api.id(5120101748344255)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(81496662761069036)
,p_name=>'P112_CORREO_ENCAR'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(69634519214589349)
,p_prompt=>'Correo Encargado:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>50
,p_grid_column=>3
,p_field_template=>wwv_flow_api.id(5120101748344255)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(81496722492069037)
,p_name=>'P112_CEDULA_ENCAR'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(69634519214589349)
,p_prompt=>'Cedula Encargado:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>50
,p_grid_column=>3
,p_field_template=>wwv_flow_api.id(5120101748344255)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(81498046713069050)
,p_name=>'P112_ID_IMPUESTO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(81497967607069049)
,p_prompt=>'Impuesto'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT PKG_MAESTRO_CONTRIBUYENTE.RETORNA_DESCRIP_TIPO_IMPUESTO (ID_TIPO_IMPUESTO)NOM_IMPUESTO,',
'       ID_TIPO_IMPUESTO',
'FROM TIPO_IMPUESTO_CONTRIB',
'WHERE ID_TIPO_CONTRIB = :P112_ID_TIPO_CONTRIBUYENTE',
'--AND   ID_IMPUESTO = :P112_ID_IMPUESTO',
'AND   ID_TIPO_IMPUESTO IN (SELECT ID_TIPO_IMPUESTO FROM IMPUESTO_X_MAESTRO_CONTRIBUYE WHERE ID_CONTRIBUYENTE = :P112_ID_CONTRIBU AND CODIGO_ESTADO = ''AC'')'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(5119973298344255)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(82513888923876801)
,p_name=>'P112_TIPO_CONTRIB'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(20102188476899430)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(82513951394876802)
,p_name=>'P112_CANT_IMPUESTOS'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(20102188476899430)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(82514476564876807)
,p_name=>'P112_PODER_ESPECIAL'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(24904823978518627)
,p_prompt=>'Poder Especial:'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_tag_attributes=>'accept=".pdf,.jpeg,.png"'
,p_field_template=>wwv_flow_api.id(5120038037344255)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(83172383128933748)
,p_name=>'P112_CANT_CORREOS'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(20102188476899430)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(111927172788574203)
,p_name=>'P112_TIPO_IMPUESTO_1'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(24904823978518627)
,p_prompt=>'Tipo Impuesto:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT PKG_MAESTRO_CONTRIBUYENTE.RETORNA_DESCRIP_TIPO_IMPUESTO (ID_TIPO_IMPUESTO)NOM_IMPUESTO,',
'       ID_TIPO_IMPUESTO',
'FROM IMPUESTO_X_MAESTRO_CONTRIBUYE',
'WHERE ID_CONTRIBUYENTE = :P112_ID_CONTRIBUYENTE',
'AND   CODIGO_ESTADO = ''AC''',
'--AND   ID_TIPO_IMPUESTO NOT IN (SELECT ID_TIPO_IMPUESTO FROM IMPUESTO_X_MAESTRO_CONTRIBUYE WHERE ID_CONTRIBUYENTE = :P112_ID_CONTRIBUYENTE)'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_display_when=>'P112_CANT_IMP_CONTRIB'
,p_display_when2=>'1'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_NOT_EQ_COND2'
,p_field_template=>wwv_flow_api.id(5119791289344256)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(111927225478574204)
,p_name=>'P112_TIPO_IMPUESTO_2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(24904823978518627)
,p_prompt=>'Tipo Impuesto:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT PKG_MAESTRO_CONTRIBUYENTE.RETORNA_DESCRIP_TIPO_IMPUESTO (ID_TIPO_IMPUESTO)NOM_IMPUESTO,',
'       ID_TIPO_IMPUESTO',
'FROM IMPUESTO_X_MAESTRO_CONTRIBUYE',
'WHERE ID_CONTRIBUYENTE = :P112_ID_CONTRIBUYENTE',
'AND   CODIGO_ESTADO = ''AC''',
'--AND   ID_TIPO_IMPUESTO NOT IN (SELECT ID_TIPO_IMPUESTO FROM IMPUESTO_X_MAESTRO_CONTRIBUYE WHERE ID_CONTRIBUYENTE = :P112_ID_CONTRIBUYENTE)'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_display_when=>'P112_CANT_IMP_CONTRIB'
,p_display_when2=>'3'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_api.id(5119791289344256)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(111927330516574205)
,p_name=>'P112_CANT_IMP_CONTRIB'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(20102188476899430)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(34182415871231304)
,p_validation_name=>'VAL_CORREO_NUEVO_FORMATO'
,p_validation_sequence=>10
,p_validation=>'select 1 from dual where not regexp_like (nvl(:P112_CORREO_NUEVO,''n/a''), ''^[A-Za-z]+[A-Za-z0-9.]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}$'');'
,p_validation_type=>'NOT_EXISTS'
,p_error_message=>'Formato de correo incorrecto'
,p_always_execute=>'Y'
,p_validation_condition=>'P112_CORREO_NUEVO'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_when_button_pressed=>wwv_flow_api.id(37065488758503247)
,p_associated_item=>wwv_flow_api.id(37065302206503246)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(27640825739385627)
,p_validation_name=>'VAL_CORREO_NUEVO_NOT_NULL'
,p_validation_sequence=>20
,p_validation=>'P112_CORREO_NUEVO'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Debe ingresar el valor del correo.'
,p_always_execute=>'Y'
,p_when_button_pressed=>wwv_flow_api.id(37065488758503247)
,p_associated_item=>wwv_flow_api.id(37065302206503246)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(34182528391231305)
,p_validation_name=>'VAL_CORREO_APODERADO_FORMATO'
,p_validation_sequence=>30
,p_validation=>'select 1 from dual where not regexp_like (nvl(:P112_CORREO_APODERADO,''n/a''), ''^[A-Za-z]+[A-Za-z0-9.]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}$'');'
,p_validation_type=>'NOT_EXISTS'
,p_error_message=>'Formato de correo incorrecto'
,p_always_execute=>'Y'
,p_validation_condition=>'P112_CORREO_APODERADO'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_when_button_pressed=>wwv_flow_api.id(24904144156518620)
,p_associated_item=>wwv_flow_api.id(24904087796518619)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(34182645700231306)
,p_validation_name=>'VAL_CEDULA'
,p_validation_sequence=>40
,p_validation=>'P112_CEDULA_APODERADO'
,p_validation_type=>'ITEM_IS_ALPHANUMERIC'
,p_error_message=>unistr('Por favor ingresar el n\00FAmero de c\00E9dula sin espacios y sin guiones ejemplo (102220333)')
,p_validation_condition=>'P112_CEDULA_APODERADO'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_associated_item=>wwv_flow_api.id(24903990571518618)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(18684818852810201)
,p_validation_name=>'VAL_NOM_ENCAR'
,p_validation_sequence=>50
,p_validation=>'P112_NOMBRE_ENCAR'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Debe indicar el nombre del encargado del impuesto.'
,p_validation_condition=>'P112_IMPUESTO'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_associated_item=>wwv_flow_api.id(81496552126069035)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(18684974290810202)
,p_validation_name=>'VAL_CEDULA_ENCAR'
,p_validation_sequence=>60
,p_validation=>'P112_CEDULA_ENCAR'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Debe indicar la cedula del encargado del impuesto.'
,p_validation_condition=>'P112_IMPUESTO'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_associated_item=>wwv_flow_api.id(81496722492069037)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(18685005989810203)
,p_validation_name=>'VAL_CORREO_ENCAR'
,p_validation_sequence=>70
,p_validation=>'P112_CORREO_ENCAR'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Debe indicar el correo del encargado del impuesto.'
,p_validation_condition=>'P112_IMPUESTO'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_associated_item=>wwv_flow_api.id(81496662761069036)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(27639458742385613)
,p_validation_name=>'VAL_NOM_ENCAR_1'
,p_validation_sequence=>80
,p_validation=>'P112_NOMBRE_ENCAR_1'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Debe indicar el nombre del encargado del impuesto.'
,p_validation_condition=>'P112_IMPUESTO_1'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_associated_item=>wwv_flow_api.id(27639315876385612)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(27639648990385615)
,p_validation_name=>'VAL_CEDULA_ENCAR_1'
,p_validation_sequence=>90
,p_validation=>'P112_CEDULA_ENCAR_1'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Debe indicar la cedula del encargado del impuesto.'
,p_validation_condition=>'P112_IMPUESTO_1'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_associated_item=>wwv_flow_api.id(27639549197385614)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(27639868702385617)
,p_validation_name=>'VAL_CORREO_ENCAR_1'
,p_validation_sequence=>100
,p_validation=>'P112_CORREO_ENCAR_1'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Debe indicar el correo del encargado del impuesto.'
,p_validation_condition=>'P112_IMPUESTO_1'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_associated_item=>wwv_flow_api.id(27639720167385616)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(27640131069385620)
,p_validation_name=>'VAL_COMAS'
,p_validation_sequence=>120
,p_validation=>'P112_CORREO_ENCAR_1'
,p_validation2=>','
,p_validation_type=>'ITEM_IN_VALIDATION_CONTAINS_NO_CHAR_IN_STRING2'
,p_error_message=>'Formato de correo no valido, por favor verificar'
,p_associated_item=>wwv_flow_api.id(27639720167385616)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(27640777673385626)
,p_validation_name=>'VAL_NEW_CORREO_FORMATO'
,p_validation_sequence=>140
,p_validation=>'select 1 from dual where not regexp_like (nvl(:P112_NEW_CORREO,''n/a''), ''^[A-Za-z]+[A-Za-z0-9.]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}$'');'
,p_validation_type=>'NOT_EXISTS'
,p_error_message=>'Formato de correo incorrecto'
,p_validation_condition=>'P112_NEW_CORREO'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_when_button_pressed=>wwv_flow_api.id(31077262973718315)
,p_associated_item=>wwv_flow_api.id(31077107043718314)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(262180285118466449)
,p_validation_name=>'VAL_CORREO_APODERADO_NOT_NULL'
,p_validation_sequence=>150
,p_validation=>'P112_CORREO_APODERADO'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Debe ingresar un correo'
,p_when_button_pressed=>wwv_flow_api.id(24904144156518620)
,p_associated_item=>wwv_flow_api.id(24904087796518619)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(262180312176466450)
,p_validation_name=>'VAL_ARC_CED_APO_NOT_NULL'
,p_validation_sequence=>160
,p_validation=>'P112_ARC_CED_APO'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>unistr('Debe de adjuntar la c\00E9dula del apoderado')
,p_always_execute=>'Y'
,p_when_button_pressed=>wwv_flow_api.id(24904144156518620)
,p_associated_item=>wwv_flow_api.id(69633692408589340)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(263042522292648201)
,p_validation_name=>'VAL_PODER_LEGAL_APO_NULL'
,p_validation_sequence=>170
,p_validation=>'P112_PODER_LEGAL_APO'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>unistr('Debe de adjuntar la Personer\00EDa Jur\00EDdica')
,p_always_execute=>'Y'
,p_when_button_pressed=>wwv_flow_api.id(24904144156518620)
,p_associated_item=>wwv_flow_api.id(24904709674518626)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(23272448960778550)
,p_name=>'DAC_INACTIVA_APO'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(23272370742778549)
,p_condition_element=>'P112_ID_APODERADO'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(24902277437518601)
,p_event_id=>wwv_flow_api.id(23272448960778550)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'UPDATE APODERADOS SET FECHA_FIN_AUTORIZA = sysdate,CODIGO_ESTADO = ''IA'',USUARIO_SIT = :APP_USER WHERE ID_APODERADO = :P112_ID_APODERADO;',
'commit;',
'END;'))
,p_attribute_02=>'P112_ID_APODERADO'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(24902344846518602)
,p_event_id=>wwv_flow_api.id(23272448960778550)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>'El apoderado fue inactivado!!'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(24902701272518606)
,p_event_id=>wwv_flow_api.id(23272448960778550)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(79991312438253509)
,p_name=>'DAC_UPPER_RESP'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P112_RESPONSABLE_TRIBUTARIO'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(79991499147253510)
,p_event_id=>wwv_flow_api.id(79991312438253509)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$("#P112_RESPONSABLE_TRIBUTARIO").val($("#P112_RESPONSABLE_TRIBUTARIO").val().toUpperCase());'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(79991576115253511)
,p_name=>'DAC_UPPER_DIRECCION'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P112_DIRECCION_ENTIDAD'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(79991663569253512)
,p_event_id=>wwv_flow_api.id(79991576115253511)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$("#P112_DIRECCION_ENTIDAD").val($("#P112_DIRECCION_ENTIDAD").val().toUpperCase());'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(79991738965253513)
,p_name=>'DAC_UPPER_NOM_REP'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P112_NOM_REP_LEG'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(79991850864253514)
,p_event_id=>wwv_flow_api.id(79991738965253513)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$("#P112_NOM_REP_LEG").val($("#P112_NOM_REP_LEG").val().toUpperCase());'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(79991951830253515)
,p_name=>'DAC_UPPER_NOM_APO'
,p_event_sequence=>50
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P112_NOMBRE_APODERADO'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(79992072583253516)
,p_event_id=>wwv_flow_api.id(79991951830253515)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$("#P112_NOMBRE_APODERADO").val($("#P112_NOMBRE_APODERADO").val().toUpperCase());'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(79992185303253517)
,p_name=>'DAC_UPPER_NOM_APO_TER'
,p_event_sequence=>60
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P112_NOMBRE_APO_TERC'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(79992240362253518)
,p_event_id=>wwv_flow_api.id(79992185303253517)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$("#P112_NOMBRE_APO_TERC").val($("#P112_NOMBRE_APO_TERC").val().toUpperCase());'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(82514578978876808)
,p_name=>'New'
,p_event_sequence=>70
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P112_TIPO_AUT'
,p_condition_element=>'P112_TIPO_AUT'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'T'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(82514658733876809)
,p_event_id=>wwv_flow_api.id(82514578978876808)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P112_PODER_ESPECIAL'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(82514701756876810)
,p_event_id=>wwv_flow_api.id(82514578978876808)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P112_PODER_ESPECIAL'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(22509781562585760)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_api.id(22468875790585807)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form 112-Datos Maestro Contribuyente'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>5801312104779619
,p_default_application_id=>102
,p_default_id_offset=>0
,p_default_owner=>'DESA_SIT'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(20102045400899429)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_DATOS_MC'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    vId_contribuyente NUMBER;',
'    vTipo_Contrib NUMBER;',
'    vTipo_Inscrip VARCHAR2(5);',
'    vTipo_Identifica NUMBER ;',
'    vCantApoFir NUMBER;',
'    vCantApo NUMBER;',
'    vCantImpuesto NUMBER;',
'    vCantCorreos NUMBER;',
'    ',
'    --Obtenemos el id_contribuyente del usuario logueado',
'    cursor C_MC IS',
'    SELECT ID_CONTRIBUYENTE',
'    FROM   USUARIOS_EXTERNOS',
'    WHERE ID_USUARIO = :APP_USER;',
'    ',
'    --Obtenemos el tipo contribuyente del usuario logueado',
'    CURSOR C_TIPO_CONTRIB (p_id_contribuyente NUMBER)IS',
'    SELECT ID_TIPO_CONTRIBUYENTE,ID_TIPO_IDENTIFICACION',
'    FROM   MAESTRO_CONTRIBUYENTE',
'    WHERE  ID_CONTRIBUYENTE = p_id_contribuyente;',
'   ',
'    ',
'    --Obtenemos el tipo de inscripcion del contribuyente',
'    CURSOR C_TIPO_INSCRIP(p_tipo_contrib NUMBER) IS',
'    SELECT IND_TIPO_INSCRIP',
'    FROM TIPO_CONTRIBUYENTE',
'    WHERE ID_TIPO_CONTRIBUYENTE = p_tipo_contrib;',
'    ',
'    --Obtenemos la cantidad de apoderados a firma digital',
'    CURSOR C_CANT_APO_FIR (p_id_contribuyente NUMBER)IS',
'    SELECT COUNT (*)',
'    FROM APODERADOS ',
'     WHERE INDICA_AUTORIZO IN (''F'')',
'       AND CODIGO_ESTADO = ''AC'' ',
'       AND ID_CONTRIBUYENTE = p_id_contribuyente;',
'    ',
'     --Obtenemos la cantidad de apoderados',
'    CURSOR C_CANT_APO (p_id_contribuyente NUMBER)IS',
'    SELECT COUNT (*)',
'    FROM APODERADOS ',
'    WHERE INDICA_AUTORIZO IN (''A'') ',
'      AND CODIGO_ESTADO = ''AC'' ',
'      AND ID_CONTRIBUYENTE = p_id_contribuyente;',
'      ',
'    --Obtenemos la cantidad de impuestos activos del contribuyente',
'    CURSOR C_CANT_IMP (p_id_contribuyente NUMBER) IS',
'    SELECT COUNT(ID_TIPO_IMPUESTO)',
'    FROM IMPUESTO_X_MAESTRO_CONTRIBUYE',
'    WHERE ID_CONTRIBUYENTE = p_id_contribuyente',
'    AND   CODIGO_ESTADO = ''AC'';',
'    ',
'    --Obtenemos la cantodad de correos del contribuyente',
'    CURSOR C_CANT_CORREOS (p_id_contribuyente NUMBER) IS',
'    SELECT COUNT (*)',
'    FROM   CORREO_NOTIFICACIONES',
'    WHERE  ID_CONTRIBUYENTE = p_id_contribuyente',
'    and    CODIGO_ESTADO = ''AC'';',
'    ',
'BEGIN',
'    OPEN  C_MC;',
'    FETCH C_MC INTO vId_contribuyente;',
'    CLOSE C_MC;',
'    ',
'    OPEN  C_TIPO_CONTRIB (vId_contribuyente);',
'    FETCH C_TIPO_CONTRIB INTO vTipo_Contrib,vTipo_Identifica;',
'    CLOSE C_TIPO_CONTRIB;',
'    ',
'    OPEN  C_TIPO_INSCRIP (vTipo_Contrib);',
'    FETCH C_TIPO_INSCRIP INTO vTipo_Inscrip;',
'    CLOSE C_TIPO_INSCRIP;',
'    ',
'    OPEN  C_CANT_APO_FIR(vId_contribuyente);',
'    FETCH C_CANT_APO_FIR INTO vCantApoFir;',
'    CLOSE C_CANT_APO_FIR;',
'    ',
'    OPEN  C_CANT_APO(vId_contribuyente);',
'    FETCH C_CANT_APO INTO vCantApo;',
'    CLOSE C_CANT_APO;',
'    ',
'    OPEN  C_CANT_IMP (vId_contribuyente);',
'    FETCH C_CANT_IMP INTO vCantImpuesto;',
'    CLOSE C_CANT_IMP;',
'    ',
'    OPEN  C_CANT_CORREOS (vId_contribuyente);',
'    FETCH C_CANT_CORREOS INTO vCantCorreos;',
'    CLOSE C_CANT_CORREOS;',
'    ',
'    ',
'    :P112_ID_CONTRIBUYENTE := vId_contribuyente;',
'    :P112_ID_CONTRIBU      := vId_contribuyente;',
'    :P112_CONTRIBUYENTE_ID := vId_contribuyente;',
'    :P112_TIPO_INSCRIPCION := vTipo_Inscrip;',
'    :P112_ID_TIPO_IDENTIFICACION := vTipo_Identifica;',
'    :P112_BRANCH := ''N'';',
'    :P112_CANT_IMP_CONTRIB := PKG_MAESTRO_CONTRIBUYENTE.CANT_IMPUESTO_TIP_CONTRIB (vTipo_Contrib);',
'    ',
'    IF vTipo_Inscrip = ''IR'' AND vTipo_Identifica = 2 THEN',
'    :P112_VALIDA_PERS_FISICA := ''S'';',
'    END IF;',
'    ',
'    IF  vTipo_Inscrip != ''ANRI'' THEN',
'        :P112_NOMBRE_REGION := ''Domicilio Fiscal'';',
'    ELSE',
unistr('        :P112_NOMBRE_REGION := '' Direcci\00F3n f\00EDsica de la Agencia'';'),
'    END IF;',
'    ',
'    IF vCantApoFir = 1 THEN',
'      :P112_VAL_CANT_APO_FIRM := ''S'';',
'    ELSE ',
'      :P112_VAL_CANT_APO_FIRM := ''N'';',
'    END IF;',
'    ',
'     IF vCantApo = 1 THEN',
'      :P112_VAL_CANT_APO := ''S'';',
'    ELSE ',
'      :P112_VAL_CANT_APO := ''N'';',
'    END IF;',
'    ',
'    IF :P112_ID_CONTRIBUYENTE IN (4,5,7) THEN',
'        :P112_VAL_COD_IATA := ''N'';',
'    ELSE',
'        :P112_VAL_COD_IATA := ''S'';',
'    END IF;',
'',
'    IF vTipo_Contrib IN (3,5,7) THEN',
'        :P112_TIPO_CONTRIB := ''S'';',
'    ELSE',
'        :P112_TIPO_CONTRIB := ''N'';',
'    END IF;',
'    ',
'    IF vCantImpuesto > 1 THEN',
'        :P112_CANT_IMPUESTOS := ''S'';',
'    ELSE',
'        :P112_CANT_IMPUESTOS := ''N'';    ',
'    END IF;',
'    ',
'    IF vCantCorreos > 1 THEN',
'        :P112_CANT_CORREOS := ''S'';',
'    ELSE',
'        :P112_CANT_CORREOS := ''N'';',
'    END IF;',
'    ',
'END;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(22509319877585761)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_api.id(22468875790585807)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form 112-Datos Maestro Contribuyente'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(24906341996518642)
,p_process_sequence=>10
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_AGREGA_APO'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'vIdApoderado NUMBER;',
'v_retorno_boolean   boolean;',
'v_mensaje_retorno   varchar2(2000);',
'vArchivo BLOB;',
'vMimetype VARCHAR2(255);',
'vFilename VARCHAR2(255);',
'BEGIN',
'    --Insertamos documentos requeridos',
'    --Para agencias de viajes   ',
'    IF :P112_PODER_LEGAL_APO IS NOT NULL AND :P112_ARC_CED_APO IS NOT NULL THEN',
'    SELECT BLOB_CONTENT, MIME_TYPE, FILENAME INTO vArchivo,vMimetype, vFilename FROM APEX_APPLICATION_TEMP_FILES WHERE NAME = :P112_PODER_LEGAL_APO;',
'    PKG_MAESTRO_CONTRIBUYENTE.P_INSERTA_APODERADOS_MC (vIdApoderado,',
'                             :P112_ID_CONTRIBU,',
'                             :P112_TIPO_APODERADO,',
'                             :P112_NOMBRE_APODERADO,',
'                             :P112_CEDULA_APODERADO,',
'                             :P112_CORREO_APODERADO,',
'                             NULL,',
'                             NULL,',
'                             NULL,',
'                             ''A'',',
'                             vArchivo,',
'                             vFilename,',
'                             vMimetype,',
'                             :APP_USER,',
'                             9,',
'                             ''I'',',
'                             v_mensaje_retorno,',
'                             v_retorno_boolean);',
'                             ',
'    SELECT BLOB_CONTENT, MIME_TYPE, FILENAME INTO vArchivo,vMimetype, vFilename FROM APEX_APPLICATION_TEMP_FILES WHERE NAME = :P112_ARC_CED_APO;',
'    PKG_MAESTRO_CONTRIBUYENTE.P_INSERTA_ARCH_APODERADOS_MC (vArchivo,',
'                                  vFilename,',
'                                  vMimetype,',
'                                  vIdApoderado,',
'                                  :APP_USER);                         ',
'     ELSE',
'     RAISE_APPLICATION_ERROR(-20000,''Debe adjuntar los archivos'');',
'     END IF;',
'     ',
'     :P112_BRANCH := ''S'';',
'   ',
'IF NOT v_retorno_boolean  ',
'   THEN',
'     RAISE_APPLICATION_ERROR(-20000,v_mensaje_retorno);',
'     rollback;',
'     return; ',
'   else ',
'      commit;',
'   end if;',
'END;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(24904144156518620)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(24906488050518643)
,p_process_sequence=>20
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_AGREGA_APO_TERC'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'vIdApoderado NUMBER;',
'v_retorno_boolean   boolean;',
'v_mensaje_retorno   varchar2(2000);',
'vArchivo BLOB;',
'vMimetype VARCHAR2(255);',
'vFilename VARCHAR2(255);',
'BEGIN',
'IF :P112_TIPO_AUT = ''T'' THEN',
'    IF :P112_PODER_LEGAL_TERC IS NOT NULL AND :P112_PODER_ESPECIAL IS NOT NULL THEN',
'    SELECT BLOB_CONTENT, MIME_TYPE, FILENAME INTO vArchivo,vMimetype, vFilename FROM APEX_APPLICATION_TEMP_FILES WHERE NAME = :P112_PODER_LEGAL_TERC;',
'    PKG_MAESTRO_CONTRIBUYENTE.P_INSERTA_APODERADOS_MC (vIdApoderado,',
'                             :P112_ID_CONTRIBU,',
'                             NULL,',
'                             :P112_NOMBRE_APO_TERC,',
'                             :P112_CEDULA_APO_TERC,',
'                             :P112_CORREO_APO_TERC,',
'                             :P112_TIPO_IMPUESTO,',
'                             :P112_TIPO_IMPUESTO_1,',
'                             :P112_TIPO_IMPUESTO_2,',
'                             :P112_TIPO_AUT,',
'                             vArchivo,',
'                             vFilename,',
'                             vMimetype,',
'                             :APP_USER,',
'                             11,',
'                             ''I'',',
'                             v_mensaje_retorno,',
'                             v_retorno_boolean);',
'     ',
'        SELECT BLOB_CONTENT, MIME_TYPE, FILENAME INTO vArchivo,vMimetype, vFilename FROM APEX_APPLICATION_TEMP_FILES WHERE NAME = :P112_PODER_ESPECIAL;',
'        PKG_MAESTRO_CONTRIBUYENTE.P_INSERTA_ARCH_APODERADOS_MC (vArchivo,',
'                                      vFilename,',
'                                      vMimetype,',
'                                      vIdApoderado,',
'                                      :APP_USER);',
'    ELSE',
'     RAISE_APPLICATION_ERROR(-20000,''Debe adjuntar los archivos'');',
'    END IF;',
'ELSIF :P112_TIPO_AUT = ''F'' THEN',
'    IF :P112_PODER_LEGAL_TERC IS NOT NULL THEN',
'    SELECT BLOB_CONTENT, MIME_TYPE, FILENAME INTO vArchivo,vMimetype, vFilename FROM APEX_APPLICATION_TEMP_FILES WHERE NAME = :P112_PODER_LEGAL_TERC;',
'    PKG_MAESTRO_CONTRIBUYENTE.P_INSERTA_APODERADOS_MC (vIdApoderado,',
'                             :P112_ID_CONTRIBU,',
'                             NULL,',
'                             :P112_NOMBRE_APO_TERC,',
'                             :P112_CEDULA_APO_TERC,',
'                             :P112_CORREO_APO_TERC,',
'                             :P112_TIPO_IMPUESTO,',
'                             :P112_TIPO_IMPUESTO_1,',
'                             :P112_TIPO_IMPUESTO_2,',
'                             :P112_TIPO_AUT,',
'                             vArchivo,',
'                             vFilename,',
'                             vMimetype,',
'                             :APP_USER,',
'                             10,',
'                             ''I'',',
'                             v_mensaje_retorno,',
'                             v_retorno_boolean);',
'     ELSE',
unistr('     RAISE_APPLICATION_ERROR(-20000,''Debe adjuntar los la Personer\00EDa Jur\00EDdica'');'),
'     END IF;',
'END IF;',
'    :P112_BRANCH := ''S'';',
'IF NOT v_retorno_boolean  ',
'   THEN',
'     RAISE_APPLICATION_ERROR(-20000,v_mensaje_retorno);',
'     rollback;',
'     return; ',
'   else ',
'      commit;',
'   end if;',
'END;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(24905568940518634)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(37064885159503241)
,p_process_sequence=>30
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_AGREGAR_TEL'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'vId_telefono NUMBER;',
'BEGIN',
'vId_telefono := SEQ_TELEFONO_MAESTRO.NEXTVAL;',
'INSERT INTO TELEFONO_X_MAESTRO_CONTRIBU VALUES(vId_telefono,:P112_ID_CONTRIBUYENTE,:P112_TIPO_TEL,:P112_TELEFONO_NUEVO,:APP_USER);',
'COMMIT;',
'END;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(37064656967503239)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(31076655763718309)
,p_process_sequence=>50
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_ACTUALIZA_TELEFONO'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'UPDATE TELEFONO_X_MAESTRO_CONTRIBU SET TELEFONO = :P112_NEW_TELEFONO,USUARIO_SIT = :APP_USER WHERE ID_TELEFONO = :P112_ID_TEL AND ID_CONTRIBUYENTE = :P112_ID_CONTRIBUYENTE;',
'COMMIT;',
'END;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(31076423841718307)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(37065597383503248)
,p_process_sequence=>60
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_AGREGAR_CORREO'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    vId_correo_notif NUMBER;',
'    VId_valida varchar2(1);',
'    ',
'BEGIN',
'',
'Begin',
'  select 1 into VId_valida from dual ',
'  where not regexp_like (nvl(:P112_CORREO_NUEVO,''n/a''), ''^[A-Za-z]+[A-Za-z0-9.]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}$'');',
'  exception',
'       when no_data_found then',
'         VId_valida := null;',
'End;',
'',
'--raise_application_error(-20000, VId_valida);',
'',
'   if VId_valida is null',
'   then',
'        vId_correo_notif := SEQ_CORREO_NOTIFICA.NEXTVAL;',
'        INSERT INTO CORREO_NOTIFICACIONES VALUES (vId_correo_notif,',
'                                                  :P112_ID_CONTRIBUYENTE,',
'                                                  :P112_CORREO_NUEVO,',
'                                                  :APP_USER,',
'                                                  ''AC''); ',
'        COMMIT;',
'   end if;',
'END;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(37065488758503247)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(31077300898718316)
,p_process_sequence=>70
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_ACTUALIZA_CORREO'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    UPDATE CORREO_NOTIFICACIONES SET CORREO_NOTIFICA = :P112_NEW_CORREO, USUARIO_SIT = :APP_USER ',
'        WHERE ID_CORREO_NOTIFICA = :P112_ID_CORREO AND ID_CONTRIBUYENTE = :P112_ID_CONTRIBUYENTE;',
'    COMMIT;',
'END;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(31077262973718315)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(84934267482861601)
,p_process_sequence=>80
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_INACTIVAR_CORREO'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    UPDATE CORREO_NOTIFICACIONES SET CODIGO_ESTADO = ''AI'', USUARIO_SIT = :APP_USER WHERE ID_CORREO_NOTIFICA = :P112_ID_CORREO AND ID_CONTRIBUYENTE = :P112_ID_CONTRIBUYENTE;',
'    COMMIT;',
'END;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(83172529779933750)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(43137555312105930)
,p_process_sequence=>90
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_ACTUALIZA_VENTA'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'UPDATE VENTAS_X_MAESTRO_CONTRIBU SET ID_TIPO_VENTAS = :P112_ID_TIPO_VENTA, USUARIO_SIT = :APP_USER WHERE ID_VENTAS = :P112_ID_VENTA AND ID_CONTRIBUYENTE = :P112_ID_CONTRIBUYENTE;',
'COMMIT;',
'END;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(43137476786105929)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(43138108548105936)
,p_process_sequence=>100
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_AGREGAR_VENTA'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'vId_venta NUMBER;',
'BEGIN',
'vId_venta := SEQ_VENTAS_MAESTRO.NEXTVAL;',
'INSERT INTO VENTAS_X_MAESTRO_CONTRIBU VALUES(vId_venta,:P112_ID_CONTRIBUYENTE,:P112_ID_TIPO_VENTA_NUEVA,:APP_USER);',
'COMMIT;',
'END;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(43138050860105935)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(43138627452105941)
,p_process_sequence=>110
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_INACTIVA_APO_TER'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'UPDATE APODERADOS SET FECHA_FIN_AUTORIZA = sysdate,CODIGO_ESTADO = ''IA'', USUARIO_SIT = :APP_USER WHERE ID_APODERADO = :P112_ID_APO_TER;',
'commit;',
'END;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(24903273855518611)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(69633718817589341)
,p_process_sequence=>120
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_ACT_REPRE_LEG'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'vIdRepreLegal NUMBER;',
'v_retorno_boolean   boolean;',
'v_mensaje_retorno   varchar2(2000);',
'vArchivo BLOB;',
'vMimetype VARCHAR2(255);',
'vFilename VARCHAR2(255);',
'vId_Archi NUMBER;',
'vId_Deudor NUMBER;',
'BEGIN',
'vId_Deudor:= PKG_MAESTRO_CONTRIBUYENTE.RETORNA_ID_DEUDOR (:APP_USER);',
'PKG_MAESTRO_CONTRIBUYENTE.P_INSERT_TEMP_REP_LEGAL (vIdRepreLegal,',
'                         :P112_ID_CONTRIBUYENTE,',
'                         :P112_NOM_REP_LEG,',
'                         :P112_CED_REP_LEG,',
'                         :P112_CORREO_REP_LEG,',
'                         :APP_USER,',
'                         v_mensaje_retorno,',
'                         v_retorno_boolean);',
'',
'IF vIdRepreLegal IS NOT NULL THEN',
'    IF :P112_ARC_REP_LEG1 IS NULL OR :P112_ARC_REP_LEG2 IS NULL THEN',
'        RAISE_APPLICATION_ERROR(-20000, ''Debe adjuntar un archivo'');',
'    END IF;',
'IF :P112_ARC_REP_LEG1 IS NOT NULL THEN',
'    vId_Archi := SEQ_TEMP_ARCHI_REPRE_LEGAL.NEXTVAL;',
'    SELECT BLOB_CONTENT, MIME_TYPE, FILENAME INTO vArchivo,vMimetype, vFilename FROM APEX_APPLICATION_TEMP_FILES WHERE NAME = :P112_ARC_REP_LEG1;',
'INSERT INTO TEMP_ARCHI_REPRE_LEGAL VALUES (vIdRepreLegal,vFilename,vArchivo,vMimetype,SYSDATE,:APP_USER,vId_Archi);',
'COMMIT;',
'END IF;',
'',
'IF :P112_ARC_REP_LEG2 IS NOT NULL THEN',
'    vId_Archi := SEQ_TEMP_ARCHI_REPRE_LEGAL.NEXTVAL;',
'    SELECT BLOB_CONTENT, MIME_TYPE, FILENAME INTO vArchivo,vMimetype, vFilename FROM APEX_APPLICATION_TEMP_FILES WHERE NAME = :P112_ARC_REP_LEG2;',
'INSERT INTO TEMP_ARCHI_REPRE_LEGAL VALUES (vIdRepreLegal,vFilename,vArchivo,vMimetype,SYSDATE,:APP_USER,vId_Archi);',
'COMMIT;',
'END IF;',
'',
'PKG_ENVIO_NOTIF_ICT_CONTRIB.NOTIFICA_CONTRIBUYENTES (:P112_ID_CONTRIBUYENTE,vId_Deudor,13,''I'',''I'',0);',
'',
':P112_BRANCH := ''S'';',
'END IF;',
'END;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(69633501644589339)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(81496873336069038)
,p_process_sequence=>130
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_INSERT_IMPUESTO'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'vId_Impuesto NUMBER;',
'BEGIN',
'IF :P112_IMPUESTO IS NOT NULL THEN',
'    IF :P112_NOMBRE_ENCAR IS NOT NULL AND :P112_CEDULA_ENCAR IS NOT NULL AND :P112_CORREO_ENCAR IS NOT NULL THEN',
'vId_Impuesto := SEQ_TEMP_IMPUESTO.NEXTVAL;',
'INSERT INTO TEMP_IMPUESTO_MAEST_CONTRIB VALUES (:P112_IMPUESTO,',
'                                                :P112_ID_CONTRIBUYENTE,',
'                                                :P112_NOMBRE_ENCAR,',
'                                                :P112_CEDULA_ENCAR,',
'                                                :P112_CORREO_ENCAR,',
'                                                ''P'',',
'                                                :APP_USER,',
'                                                ''N'',',
'                                               vId_Impuesto);',
'COMMIT;   ',
'PKG_ENVIO_NOTIF_ICT_CONTRIB.NOTIFICA_CONTRIBUYENTES (:P112_ID_CONTRIBUYENTE,:P112_ID_DEUDOR,12,''I'',''I'',0);',
':P112_BRANCH := ''S'';',
'    END IF;',
'END IF;',
'END;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(81496444029069034)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(82514169249876804)
,p_process_sequence=>140
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_INACTIVAR_IMPUESTO'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'vIdDeudor NUMBER;',
'vNomEncar VARCHAR2(80);',
'vCedEncar VARCHAR2(20);',
'vCorreoEncar VARCHAR2(40);',
'vId_Impuesto NUMBER;',
'    CURSOR C_DAT_IMP IS',
'    SELECT NOMBRE_ENCARGADO_IMP,CEDULA_ENCARGADO_IMP,CORREO_ENCARGADO_IMP',
'    FROM   IMPUESTO_X_MAESTRO_CONTRIBUYE',
'    WHERE  ID_TIPO_IMPUESTO = :P112_ID_IMPUESTO',
'    AND    ID_CONTRIBUYENTE = :P112_ID_CONTRIBUYENTE;',
'BEGIN',
'    OPEN   C_DAT_IMP;',
'    FETCH  C_DAT_IMP INTO vNomEncar,vCedEncar,vCorreoEncar;',
'    CLOSE  C_DAT_IMP;',
'    vId_Impuesto := SEQ_TEMP_IMPUESTO.NEXTVAL;',
'INSERT INTO TEMP_IMPUESTO_MAEST_CONTRIB VALUES (:P112_ID_IMPUESTO,',
'                                                :P112_ID_CONTRIBUYENTE,',
'                                                vNomEncar,',
'                                                vCedEncar,',
'                                                vCorreoEncar,',
'                                                ''P'',',
'                                                :APP_USER,',
'                                               ''I'',',
'                                               vId_Impuesto);',
'COMMIT;   ',
'vIdDeudor := PKG_MAESTRO_CONTRIBUYENTE.RETORNA_ID_DEUDOR_CONTRIB (:P112_ID_CONTRIBUYENTE);',
'PKG_ENVIO_NOTIF_ICT_CONTRIB.NOTIFICA_CONTRIBUYENTES (:P112_ID_CONTRIBUYENTE, vIdDeudor,12,''I'',''I'',0);',
':P112_BRANCH := ''S'';',
'END;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(82514017290876803)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(27640457705385623)
,p_process_sequence=>150
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_ACTUALIZA_IMPUESTO'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'vId_Impuesto NUMBER;',
'BEGIN',
'IF :P112_IMPUESTO_1 IS NOT NULL THEN',
'    IF :P112_NOMBRE_ENCAR_1 IS NOT NULL AND :P112_CEDULA_ENCAR_1 IS NOT NULL AND :P112_CORREO_ENCAR_1 IS NOT NULL THEN',
'',
'    UPDATE IMPUESTO_X_MAESTRO_CONTRIBUYE SET --ID_TIPO_IMPUESTO =     :P112_IMPUESTO_1,',
'                                             NOMBRE_ENCARGADO_IMP = :P112_NOMBRE_ENCAR_1,',
'                                             CEDULA_ENCARGADO_IMP = :P112_CEDULA_ENCAR_1,',
'                                             CORREO_ENCARGADO_IMP = :P112_CORREO_ENCAR_1,',
'                                             USUARIO_SIT =          :APP_USER',
'    WHERE  ID_TIPO_IMPUESTO = :P112_IMPUESTO_1 AND                ',
'           ID_CONTRIBUYENTE = :P112_ID_CONTRIBUYENTE;',
'    COMMIT;',
'    /*vId_Impuesto := SEQ_TEMP_IMPUESTO.NEXTVAL;',
'    INSERT INTO TEMP_IMPUESTO_MAEST_CONTRIB VALUES (:P112_IMPUESTO,',
'                                                    :P112_ID_CONTRIBUYENTE,',
'                                                    :P112_NOMBRE_ENCAR,',
'                                                    :P112_CEDULA_ENCAR,',
'                                                    :P112_CORREO_ENCAR,',
'                                                    ''P'',',
'                                                    :APP_USER,',
'                                                    ''N'',',
'                                                   vId_Impuesto);',
'    COMMIT;   ',
'    PKG_ENVIO_NOTIF_ICT_CONTRIB.NOTIFICA_CONTRIBUYENTES (:P112_ID_CONTRIBUYENTE,:P112_ID_DEUDOR,12,''I'',''I'',0);*/',
'--:P112_BRANCH := ''S'';',
'    END IF;',
'END IF;',
'END;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(27640319279385622)
);
wwv_flow_api.component_end;
end;
/
