prompt --application/pages/page_00204
begin
--   Manifest
--     PAGE: 00204
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>5801312104779619
,p_default_application_id=>102
,p_default_id_offset=>0
,p_default_owner=>'DESA_SIT'
);
wwv_flow_api.create_page(
 p_id=>204
,p_user_interface_id=>wwv_flow_api.id(5143571665344221)
,p_name=>'Consulta Cuotas Arreglos Pagos'
,p_alias=>'CONSULTA-CUOTAS-ARREGLOS-PAGOS'
,p_step_title=>'Consulta Cuotas Arreglos Pagos'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_browser_cache=>'N'
,p_last_updated_by=>'KIMBERLYN.SOLANO'
,p_last_upd_yyyymmddhh24miss=>'20221121125605'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(36448257987960724)
,p_plug_name=>'Consulta Cuotas Arreglos Pagos'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(5058998562344289)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(36448316914960725)
,p_plug_name=>'Filtro'
,p_parent_plug_id=>wwv_flow_api.id(36448257987960724)
,p_region_template_options=>'t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(5058998562344289)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(36448452179960726)
,p_name=>'Reporte'
,p_parent_plug_id=>wwv_flow_api.id(36448257987960724)
,p_template=>wwv_flow_api.id(5058998562344289)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Select numero_cuota,',
'       fecha_pago,',
'       monto_cuota_mensual,',
'       monto_intereses,',
'       amortizacion,',
'       saldo_deuda,',
'       codigo_estado',
'from calculo_cuota_arreglo_pago@consulta_ictx ',
'WHERE ID_DEUDOR = PKG_MAESTRO_CONTRIBUYENTE.RETORNA_ID_DEUDOR (:APP_USER) AND',
'      ID_ARREGLO_P = NVL(:P204_ARREGLO_PAGO,ID_ARREGLO_P)',
'ORDER BY numero_cuota',
''))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P204_ARREGLO_PAGO'
,p_query_row_template=>wwv_flow_api.id(5085249619344274)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'SEARCH_ENGINE'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(36448554257960727)
,p_query_column_id=>1
,p_column_alias=>'NUMERO_CUOTA'
,p_column_display_sequence=>1
,p_column_heading=>'Numero Cuota'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(36448637859960728)
,p_query_column_id=>2
,p_column_alias=>'FECHA_PAGO'
,p_column_display_sequence=>2
,p_column_heading=>'Fecha Pago'
,p_use_as_row_header=>'N'
,p_column_format=>'DD/MM/RRRR'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(36448757068960729)
,p_query_column_id=>3
,p_column_alias=>'MONTO_CUOTA_MENSUAL'
,p_column_display_sequence=>3
,p_column_heading=>'Monto Cuota Mensual'
,p_use_as_row_header=>'N'
,p_column_format=>'999,999,999.99'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(36448835844960730)
,p_query_column_id=>4
,p_column_alias=>'MONTO_INTERESES'
,p_column_display_sequence=>4
,p_column_heading=>'Monto Intereses'
,p_use_as_row_header=>'N'
,p_column_format=>'999,999,999.99'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(36448980667960731)
,p_query_column_id=>5
,p_column_alias=>'AMORTIZACION'
,p_column_display_sequence=>5
,p_column_heading=>unistr('Amortizaci\00F3n')
,p_use_as_row_header=>'N'
,p_column_format=>'999,999,999.99'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(36449065844960732)
,p_query_column_id=>6
,p_column_alias=>'SALDO_DEUDA'
,p_column_display_sequence=>6
,p_column_heading=>'Saldo Deuda'
,p_use_as_row_header=>'N'
,p_column_format=>'999,999,999.99'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(36449136404960733)
,p_query_column_id=>7
,p_column_alias=>'CODIGO_ESTADO'
,p_column_display_sequence=>7
,p_column_heading=>'Nombre Estado'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_api.id(36555624753671155)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(43151328376408818)
,p_name=>'P204_ARREGLO_PAGO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(36448316914960725)
,p_prompt=>unistr('N\00FAmero de Arreglo Pago:')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Select id_arreglo_p id_arreglo, id_arreglo_p from arreglos_pagos@consulta_ictx',
'where id_deudor = PKG_MAESTRO_CONTRIBUYENTE.RETORNA_ID_DEUDOR (:APP_USER)'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(5119791289344256)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'SUBMIT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(84957779903006113)
,p_name=>'P204_TASA_INTERES'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(36448316914960725)
,p_prompt=>'Tasa Interes'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Select tasa_mora tasa_mora_p, tasa_mora from arreglos_pagos@consulta_ictx',
'where id_deudor = PKG_MAESTRO_CONTRIBUYENTE.RETORNA_ID_DEUDOR (:APP_USER) and',
'      id_arreglo_p = :P204_ARREGLO_PAGO',
'',
'/*Select id_arreglo_p id_arreglo, id_arreglo_p from arreglos_pagos@consulta_ictx',
'where id_deudor = PKG_MAESTRO_CONTRIBUYENTE.RETORNA_ID_DEUDOR (:APP_USER)*/',
''))
,p_lov_cascade_parent_items=>'P204_ARREGLO_PAGO'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(5119973298344255)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'SUBMIT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(84957898767006114)
,p_name=>'P204_MONTO_DEUDA'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(36448316914960725)
,p_prompt=>'Monto Deuda'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Select to_char(to_number(monto_periodos_anteriores + monto_intereses_acumulados + monto_honorarios + monto_abono),''999,999,999,999.99'') monto_cuota_p, monto',
'from arreglos_pagos@consulta_ictx',
'where id_deudor = PKG_MAESTRO_CONTRIBUYENTE.RETORNA_ID_DEUDOR (:APP_USER) and',
'      id_arreglo_p = :P204_ARREGLO_PAGO'))
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(5119973298344255)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'SUBMIT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(84957952541006115)
,p_name=>'P204_PLAZO'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(36448316914960725)
,p_prompt=>'Plazo'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Select plazo plazo_p, plazo from arreglos_pagos@consulta_ictx',
'where id_deudor = PKG_MAESTRO_CONTRIBUYENTE.RETORNA_ID_DEUDOR (:APP_USER) and',
'      id_arreglo_p = :P204_ARREGLO_PAGO',
'',
'/*Select id_arreglo_p id_arreglo, id_arreglo_p from arreglos_pagos@consulta_ictx',
'where id_deudor = PKG_MAESTRO_CONTRIBUYENTE.RETORNA_ID_DEUDOR (:APP_USER)*/',
''))
,p_lov_cascade_parent_items=>'P204_ARREGLO_PAGO'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(5119973298344255)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'SUBMIT'
,p_attribute_03=>'Y'
);
wwv_flow_api.component_end;
end;
/
