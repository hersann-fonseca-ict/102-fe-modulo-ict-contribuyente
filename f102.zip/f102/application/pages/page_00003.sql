prompt --application/pages/page_00003
begin
--   Manifest
--     PAGE: 00003
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>5801312104779619
,p_default_application_id=>102
,p_default_id_offset=>0
,p_default_owner=>'DESA_SIT'
);
wwv_flow_api.create_page(
 p_id=>3
,p_user_interface_id=>wwv_flow_api.id(5143571665344221)
,p_name=>unistr('Cambiar contrase\00F1a')
,p_alias=>unistr('CAMBIAR-CONTRASE\00D1A')
,p_step_title=>unistr('Cambiar contrase\00F1a')
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>wwv_flow_api.id(5017077679344311)
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_browser_cache=>'N'
,p_last_updated_by=>'KIMBERLYN.SOLANO'
,p_last_upd_yyyymmddhh24miss=>'20230919111423'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(5345732636975017)
,p_plug_name=>unistr('Actualizar contrase\00F1a')
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(5058998562344289)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_region_image=>'#APP_IMAGES#Logo1.png'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(5345019739975010)
,p_plug_name=>unistr('Cambiar Contrase\00F1a')
,p_parent_plug_id=>wwv_flow_api.id(5345732636975017)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_region_attributes=>'style="width: 400px;" '
,p_plug_template=>wwv_flow_api.id(5058998562344289)
,p_plug_display_sequence=>10
,p_plug_display_column=>3
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(6706313463248602)
,p_plug_name=>'GO_LOGIN'
,p_parent_plug_id=>wwv_flow_api.id(5345019739975010)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(5031545193344301)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_source=>unistr('<p><a href="f?p=&APP_ID.:9999:&APP_SESSION.:::">Regresar a p\00E1gina de inicio de sesi\00F3n</a></p>')
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(25655569197811227)
,p_plug_name=>'Indicaciones'
,p_parent_plug_id=>wwv_flow_api.id(5345732636975017)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(5058998562344289)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>5
,p_plug_display_column=>7
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(5345829046975018)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_api.id(6706313463248602)
,p_button_name=>'BTN_GUARDAR'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5121094921344251)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Guardar'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:114:&SESSION.::&DEBUG.:::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(43136228650105917)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_api.id(6706313463248602)
,p_button_name=>'BTN_CANCELAR'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5121094921344251)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Cancelar'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.::P1_CANCELO_CAMBIO:S'
,p_button_condition=>'P3_CAMBIAR_PWD'
,p_button_condition2=>'S'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(25656021258811232)
,p_branch_name=>'Go To Page 114'
,p_branch_action=>'f?p=&APP_ID.:114:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
,p_branch_condition_type=>'NEVER'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5345251799975012)
,p_name=>'P3_USUARIO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(5345019739975010)
,p_prompt=>'Usuario'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(5119973298344255)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5345321045975013)
,p_name=>'P3_ACTUAL_PWD'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(5345019739975010)
,p_prompt=>unistr('Contrase\00F1a actual')
,p_display_as=>'NATIVE_PASSWORD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(5119973298344255)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5345472857975014)
,p_name=>'P3_NUEVO_PWD'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(5345019739975010)
,p_prompt=>unistr('Nueva contrase\00F1a')
,p_display_as=>'NATIVE_PASSWORD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(5119973298344255)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5345582803975015)
,p_name=>'P3_CONFIRMA_PWD'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(5345019739975010)
,p_prompt=>unistr('Confirma contrase\00F1a')
,p_display_as=>'NATIVE_PASSWORD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(5119973298344255)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5345634800975016)
,p_name=>'P3_ALERTA'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(5345019739975010)
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_tag_attributes=>'style="color:red;"'
,p_field_template=>wwv_flow_api.id(5119791289344256)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6609326648928947)
,p_name=>'P3_REDIREC_LOGIN'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(5345019739975010)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(25655011022811222)
,p_name=>'P3_ALERTA2'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(5345019739975010)
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_tag_attributes=>'style="color:blue;"'
,p_field_template=>wwv_flow_api.id(5119973298344255)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(25655636191811228)
,p_name=>'P3_NEW'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(25655569197811227)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('Para realizar el cambio de la contrase\00F1a considere las siguientes recomendaciones de seguridad:'),
'1. No contener el nombre de cuenta del usuario (login).',
unistr('2. Tener un m\00EDnimo de ocho caracteres de longitud.'),
unistr('3. Contener al menos una may\00FAscula y un n\00FAmero del 0 al 9.'),
unistr('4. No usar la letra \00D1 ni la \00F1.'),
unistr('5. Los siguientes caracteres no est\00E1n permitidos ~ ! @ % ^ & *- + =` | \005C () {} []: ;"<>, . ? /'),
unistr('6. Se mantiene un hist\00F3rico de tres claves, por lo que no podr\00E1 utilizar una que haya establecido durante los \00FAltimos tres cambios anteriores.')))
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(5119973298344255)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(25655729037811229)
,p_name=>'P3_CODIGO_ERROR'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(5345019739975010)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(43136094671105915)
,p_name=>'P3_CAMBIAR_PWD'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(5345019739975010)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(5345943089975019)
,p_name=>'DAC_VAL_PWD'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P3_CONFIRMA_PWD'
,p_condition_element=>'P3_CONFIRMA_PWD'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(5346032283975020)
,p_event_id=>wwv_flow_api.id(5345943089975019)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'vCodError VARCHAR2(300);',
'vMensaje VARCHAR2(300);',
'vNumero  NUMBER;',
'BEGIN',
':P3_ALERTA := NULL;',
':P3_ALERTA2:= NULL;',
'',
'IF :P3_NUEVO_PWD <> :P3_CONFIRMA_PWD THEN',
unistr('    :P3_ALERTA := ''Contrase\00F1as deben coincidir, por favor validar'';'),
'ELSE',
'    vNumero := F_VALIDA_CLAVE_SIT(:P3_USUARIO,:P3_CONFIRMA_PWD,vCodError,vMensaje);',
'    IF vCodError IS NOT NULL THEN',
'       :P3_CODIGO_ERROR := vCodError;',
'       :P3_ALERTA := vMensaje;',
'    ELSE ',
'       :P3_ALERTA := null;',
'       :P3_ALERTA2 := vMensaje;',
'    END IF;',
'END IF;',
'',
'END;'))
,p_attribute_02=>'P3_NUEVO_PWD,P3_CONFIRMA_PWD,P3_USUARIO'
,p_attribute_03=>'P3_ALERTA,P3_ALERTA2,P3_CODIGO_ERROR'
,p_attribute_04=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(6708828709248627)
,p_name=>'DAC_VAL_CLAVE_ACT'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P3_ACTUAL_PWD'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(6708908265248628)
,p_event_id=>wwv_flow_api.id(6708828709248627)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'vClave_Actual varchar2(255);',
'BEGIN',
' SELECT F_OBTIENE_CLAVE_EXTERNOS(id_usuario) INTO vClave_Actual FROM USUARIOS_EXTERNOS WHERE ID_USUARIO = UPPER(:P3_USUARIO);',
' IF vClave_Actual <> :P3_ACTUAL_PWD THEN',
unistr(' :P3_ALERTA := ''La contrase\00F1a actual es incorrecta... por favor verifique'';'),
' ELSE',
' :P3_ALERTA := NULL;',
' END IF;',
'END;'))
,p_attribute_02=>'P3_USUARIO,P3_ACTUAL_PWD'
,p_attribute_03=>'P3_ALERTA'
,p_attribute_04=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(6709005585248629)
,p_name=>'DAC_BTN_GUARDAR'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P3_ALERTA'
,p_condition_element=>'P3_ALERTA'
,p_triggering_condition_type=>'NULL'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
,p_display_when_type=>'NEVER'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(6709165482248630)
,p_event_id=>wwv_flow_api.id(6709005585248629)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_api.id(5345829046975018)
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(6709229252248631)
,p_event_id=>wwv_flow_api.id(6709005585248629)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_api.id(5345829046975018)
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(25655181581811223)
,p_name=>'DAC_BTN_GUARDAR_1'
,p_event_sequence=>50
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P3_CODIGO_ERROR'
,p_condition_element=>'P3_ALERTA2'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(25655252994811224)
,p_event_id=>wwv_flow_api.id(25655181581811223)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_api.id(5345829046975018)
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(25655319961811225)
,p_event_id=>wwv_flow_api.id(25655181581811223)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_api.id(5345829046975018)
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(18686521518810218)
,p_event_id=>wwv_flow_api.id(25655181581811223)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'BEGIN',
'    PKG_ENVIO_NOTIF_ICT_CONTRIB.NOTIF_ACTUALIZACION_USR_EXT (:P3_USUARIO, 2,''G'',0);',
'   -- NULL;',
'END;'))
,p_attribute_02=>'P3_USUARIO'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(6709309857248632)
,p_name=>'DAC_VAL_USUARIO'
,p_event_sequence=>60
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P3_USUARIO'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(6709483696248633)
,p_event_id=>wwv_flow_api.id(6709309857248632)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'vExiste varchar2(255):=''N'';',
'BEGIN',
' vExiste := FNC_VALIDA_USR (:P3_USUARIO);',
' IF vExiste = ''N'' THEN',
' :P3_ALERTA := ''El usuario no existe'';',
' ELSE',
' :P3_ALERTA := NULL;',
' END IF;',
'END;'))
,p_attribute_02=>'P3_USUARIO'
,p_attribute_03=>'P3_ALERTA'
,p_attribute_04=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(5346156460975021)
,p_process_sequence=>20
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Set_item'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
':P3_ALERTA := NULL;',
':P3_ALERTA2 := NULL;',
'',
'/*UPDATE USUARIOS_EXTERNOS SET ESTADO = 0 WHERE ID_USUARIO = :APP_USER;',
'COMMIT;*/',
'END;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(43136136114105916)
,p_process_sequence=>30
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_ACT_ESTADO'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
':P3_ALERTA := NULL;',
':P3_ALERTA2 := NULL;',
'UPDATE USUARIOS_EXTERNOS SET ESTADO = 0 WHERE ID_USUARIO = :APP_USER;',
'COMMIT;',
'END;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_type=>'USER_IS_NOT_PUBLIC_USER'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(25655888750811230)
,p_process_sequence=>10
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_CAMBIAR_PWD'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'BEGIN',
'    PKG_ENVIO_NOTIF_ICT_CONTRIB.NOTIF_ACTUALIZACION_USR_EXT (:P3_USUARIO, 2,''G'',0);',
'   -- NULL;',
'END;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_type=>'NEVER'
);
wwv_flow_api.component_end;
end;
/
