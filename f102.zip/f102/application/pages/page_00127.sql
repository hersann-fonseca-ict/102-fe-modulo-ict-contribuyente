prompt --application/pages/page_00127
begin
--   Manifest
--     PAGE: 00127
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>5801312104779619
,p_default_application_id=>102
,p_default_id_offset=>0
,p_default_owner=>'DESA_SIT'
);
wwv_flow_api.create_page(
 p_id=>127
,p_user_interface_id=>wwv_flow_api.id(5143571665344221)
,p_name=>unistr('127-Formulario Declaraci\00F3n Jurada Ocasional Terrestre')
,p_alias=>unistr('127-FORMULARIO-DECLARACI\00D3N-JURADA-OCASIONAL-TERRESTRE')
,p_step_title=>unistr('127-Formulario Declaraci\00F3n Jurada Ocasional Terrestre')
,p_reload_on_submit=>'A'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function validateNumber(event) {',
'  var keyCode = event.keyCode;',
unistr('  var excludedKeys = [8, 37, 39, 46];//Teclas extra que queremos que el campo acepte aparte de los n\00FAmeros, como el backspace'),
unistr('//Realizamos la validaci\00F3n de la tecla ingresada'),
'  if (!((keyCode >= 48 && keyCode <= 57) ||',
'      (keyCode >= 96 && keyCode <= 105) ||',
'      (excludedKeys.includes(keyCode)))) {',
'    event.preventDefault();',
'',
'  }',
'}',
'',
'function validateText(event) {',
'  var keyCode = event.keyCode;',
'  var excludedKeys = [8, 37, 39, 46, 32];',
'',
'  if (!((keyCode >= 65 && keyCode <= 90) ||',
'      (excludedKeys.includes(keyCode)))) {',
'    event.preventDefault();',
'',
'  }',
'} '))
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'JORGE.ROJAS'
,p_last_upd_yyyymmddhh24miss=>'20241114094738'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(541762595599472763)
,p_plug_name=>'Principal'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(5058998562344289)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(429427463369500299)
,p_plug_name=>'TituloTTR'
,p_parent_plug_id=>wwv_flow_api.id(541762595599472763)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(5058998562344289)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<center><h2>Instituto Costarricense de Turismo</h2></center>',
unistr('<center><h4>Solicitud Gesti\00F3n de Tr\00E1mite Terrestre Regular de Transporte Internacional.</h4></center>'),
unistr('<center><h4>Art\00EDculo 46, inciso a) Ley 1917 de 9 de agosto de 1955</h4></center>'),
unistr('<center><h4>Decreto Ejecutivo N\00B037979-MP-H-MEIC-G-J-TUR del 25 de octubre del 2013</h4></center>')))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'GLOBAL_TIPO_CONTRIBUYENTE'
,p_plug_display_when_cond2=>'17'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(541762272761472760)
,p_plug_name=>unistr('Formulario declaraci\00F3n Jurada ')
,p_parent_plug_id=>wwv_flow_api.id(541762595599472763)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(5058998562344289)
,p_plug_display_sequence=>40
,p_plug_display_point=>'BODY'
,p_query_type=>'TABLE'
,p_query_table=>'DECLARA_CHARTER_TERRESTRE_O'
,p_include_rowid_column=>false
,p_is_editable=>false
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(523226813266819183)
,p_plug_name=>'Region Buttons'
,p_parent_plug_id=>wwv_flow_api.id(541762272761472760)
,p_region_template_options=>'#DEFAULT#:margin-top-md'
,p_plug_template=>wwv_flow_api.id(5031758564344301)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(523226885129819184)
,p_plug_name=>'Tabs'
,p_parent_plug_id=>wwv_flow_api.id(541762272761472760)
,p_region_template_options=>'#DEFAULT#:t-TabsRegion-mod--fillLabels:t-TabsRegion-mod--simple:t-TabsRegion-mod--large'
,p_plug_template=>wwv_flow_api.id(5065793333344285)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(523226258658819177)
,p_plug_name=>'Propietario'
,p_parent_plug_id=>wwv_flow_api.id(523226885129819184)
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_plug_template=>wwv_flow_api.id(5068326102344284)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(523226372798819178)
,p_plug_name=>'Contrato de Arrendamiento'
,p_parent_plug_id=>wwv_flow_api.id(523226885129819184)
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_plug_template=>wwv_flow_api.id(5068326102344284)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(523226387853819179)
,p_plug_name=>'Viaje'
,p_parent_plug_id=>wwv_flow_api.id(523226885129819184)
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_plug_template=>wwv_flow_api.id(5068326102344284)
,p_plug_display_sequence=>40
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(523226579380819180)
,p_plug_name=>'Impuestos'
,p_parent_plug_id=>wwv_flow_api.id(523226885129819184)
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_plug_template=>wwv_flow_api.id(5068326102344284)
,p_plug_display_sequence=>50
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(523226662119819181)
,p_plug_name=>'Transporte'
,p_parent_plug_id=>wwv_flow_api.id(523226885129819184)
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_plug_template=>wwv_flow_api.id(5068326102344284)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(523227079802819185)
,p_plug_name=>'Encabezado'
,p_parent_plug_id=>wwv_flow_api.id(541762272761472760)
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_plug_template=>wwv_flow_api.id(5068326102344284)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(576772110809760968)
,p_plug_name=>'Titulo COT'
,p_parent_plug_id=>wwv_flow_api.id(541762595599472763)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(5058998562344289)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<center><h2>Instituto Costarricense de Turismo</h2></center>',
unistr('<center><h4>Declaraci\00F3n Jurada de Ch\00E1rter Terrestre Transporte Internacional.</h4></center>'),
unistr('<center><h4>Art\00EDculo 46, inciso a) Ley 1917 de 9 de agosto de 1955</h4></center>'),
unistr('<center><h4>Decreto Ejecutivo N\00B037979-MP-H-MEIC-G-J-TUR del 25 de octubre del 2013</h4></center>')))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'GLOBAL_TIPO_CONTRIBUYENTE'
,p_plug_display_when_cond2=>'8'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(263248566355233969)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(523226813266819183)
,p_button_name=>'BTN_CANCELAR'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5121094921344251)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Cancelar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(263247356735233968)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(523226813266819183)
,p_button_name=>'BTN_GENERAR_PDF_CONTRATO_COT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5121094921344251)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('Vista Previa Declaraci\00F3n Jurada')
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:130:&SESSION.::&DEBUG.:130::'
,p_button_condition=>'GLOBAL_TIPO_CONTRIBUYENTE'
,p_button_condition2=>'8'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(263247761009233969)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(523226813266819183)
,p_button_name=>'BTN_GENERAR_PDF_CONTRATO_TTR'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5121094921344251)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('Vista Previa Declaraci\00F3n Jurada')
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:130:&SESSION.::&DEBUG.:::'
,p_button_condition=>'GLOBAL_TIPO_CONTRIBUYENTE'
,p_button_condition2=>'17'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(263248154715233969)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(523226813266819183)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5121094921344251)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Continuar'
,p_button_position=>'BELOW_BOX'
,p_button_execute_validations=>'N'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(263283744724234007)
,p_branch_name=>'Go to 129'
,p_branch_action=>'f?p=&APP_ID.:129:&SESSION.::&DEBUG.:129:P129_ID_DECLARA_CTO:&P127_ID_DECLARA_CTO.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(263248154715233969)
,p_branch_sequence=>20
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(263245964440233966)
,p_name=>'P127_CLEAR_1'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(429427463369500299)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(263246311837233967)
,p_name=>'P127_ID_REPORTE_1'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(429427463369500299)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(263249518191233971)
,p_name=>'P127_NOMBRE_ENTIDAD'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(523226258658819177)
,p_prompt=>unistr('Nombre due\00F1o f\00EDsico o jur\00EDdico:')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>100
,p_tag_attributes=>' onKeyUp="this.value = this.value.toUpperCase()"'
,p_colspan=>3
,p_field_template=>wwv_flow_api.id(5120299602344255)
,p_item_icon_css_classes=>'fa-user'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(263249930133233974)
,p_name=>'P127_ID_TIPO_IDENTIFICACION'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(523226258658819177)
,p_prompt=>unistr('Tipo Identificaci\00F3n:')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_TIPO_IDENTIFICACION2'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- Seleccionar -'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_colspan=>3
,p_field_template=>wwv_flow_api.id(5120299602344255)
,p_item_icon_css_classes=>'fa-chevron-down'
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(263250305450233974)
,p_name=>'P127_CEDULA'
,p_is_required=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(523226258658819177)
,p_prompt=>unistr('C\00E9dula:')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>20
,p_begin_on_new_line=>'N'
,p_colspan=>3
,p_field_template=>wwv_flow_api.id(5120299602344255)
,p_item_icon_css_classes=>'fa-id-card-o'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'Y'
,p_attribute_03=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(263250727564233975)
,p_name=>'P127_CORREO_NOTIFICA1'
,p_is_required=>true
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(523226258658819177)
,p_prompt=>'Correo para Notificaciones 1:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>50
,p_tag_attributes=>' onKeyUp="this.value = this.value.toUpperCase()"'
,p_colspan=>3
,p_field_template=>wwv_flow_api.id(5120299602344255)
,p_item_icon_css_classes=>'fa-envelope-o'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(263251133255233975)
,p_name=>'P127_CORREO_NOTIFICA2'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(523226258658819177)
,p_prompt=>'Correo para Notificaciones 2:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>50
,p_tag_attributes=>' onKeyUp="this.value = this.value.toUpperCase()"'
,p_begin_on_new_line=>'N'
,p_colspan=>3
,p_field_template=>wwv_flow_api.id(5119973298344255)
,p_item_icon_css_classes=>'fa-envelope-o'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(263251598216233975)
,p_name=>'P127_TELEFONO1'
,p_is_required=>true
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(523226258658819177)
,p_prompt=>'Telefono1:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_colspan=>3
,p_field_template=>wwv_flow_api.id(5120299602344255)
,p_item_icon_css_classes=>'fa-phone'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(263251983864233976)
,p_name=>'P127_TELEFONO2'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(523226258658819177)
,p_prompt=>'Telefono2:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(5119973298344255)
,p_item_icon_css_classes=>'fa-phone'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(263252640822233976)
,p_name=>'P127_CONTRATO_ARRENDA'
,p_is_required=>true
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_api.id(523226372798819178)
,p_item_default=>'NULL;'
,p_item_default_type=>'PLSQL_FUNCTION_BODY'
,p_prompt=>'Contrato de arrendamiento?'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_SI_NO'
,p_lov=>'.'||wwv_flow_api.id(263284068952234007)||'.'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_colspan=>2
,p_field_template=>wwv_flow_api.id(5120299602344255)
,p_item_icon_css_classes=>'fa-chevron-down'
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(263253072896233977)
,p_name=>'P127_NOMBRE_ARRENDA'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_api.id(523226372798819178)
,p_prompt=>'Nombre de Arrendatario:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>80
,p_tag_attributes=>' onKeyUp="this.value = this.value.toUpperCase()"'
,p_colspan=>3
,p_field_template=>wwv_flow_api.id(5120299602344255)
,p_item_icon_css_classes=>'fa-user'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(263253448260233977)
,p_name=>'P127_ID_TIPO_IDENTIFICA'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_api.id(523226372798819178)
,p_prompt=>unistr('Tipo Identificaci\00F3n:')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_TIPO_IDENTIFICACION2'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- Seleccionar -'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_colspan=>3
,p_field_template=>wwv_flow_api.id(5120299602344255)
,p_item_icon_css_classes=>'fa-chevron-down'
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(263253811674233978)
,p_name=>'P127_CEDULA_ARRE'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_api.id(523226372798819178)
,p_prompt=>unistr('N\00B0 de Identificaci\00F3n:')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>20
,p_tag_attributes=>'onKeyUp="this.value = this.value.toLowerCase()"'
,p_begin_on_new_line=>'N'
,p_colspan=>3
,p_field_template=>wwv_flow_api.id(5120299602344255)
,p_item_icon_css_classes=>'fa-id-card-o'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(263254566402233979)
,p_name=>'P127_FECHA_INI_EXCUSION'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_api.id(523226387853819179)
,p_prompt=>unistr('Fecha Inicio Excursi\00F3n:')
,p_format_mask=>'DD/MM/YYYY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>10
,p_colspan=>3
,p_display_when=>'GLOBAL_TIPO_CONTRIBUYENTE'
,p_display_when2=>'8'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_api.id(5120299602344255)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(263254960815233979)
,p_name=>'P127_FECHA_FIN_EXCUSION'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_api.id(523226387853819179)
,p_prompt=>unistr('Fecha Fin Excursi\00F3n:')
,p_format_mask=>'DD/MM/YYYY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>10
,p_begin_on_new_line=>'N'
,p_colspan=>3
,p_display_when=>'GLOBAL_TIPO_CONTRIBUYENTE'
,p_display_when2=>'8'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_api.id(5120299602344255)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(263255337091233980)
,p_name=>'P127_CODIGO_DESTINO'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_api.id(523226387853819179)
,p_prompt=>'Destino del Viaje:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_TIPOS_DESTINOS'
,p_lov=>'SELECT codigo_destino, UPPER(nombre_destino) FROM tipo_destinos_sit WHERE codigo_estado = ''AC'';'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_colspan=>3
,p_display_when=>'GLOBAL_TIPO_CONTRIBUYENTE'
,p_display_when2=>'8'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_api.id(5120299602344255)
,p_item_icon_css_classes=>'fa-chevron-down'
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(263255727835233980)
,p_name=>'P127_TOTAL_PASAJEROS'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_api.id(523226387853819179)
,p_prompt=>'Cantidad de personas:'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>10
,p_begin_on_new_line=>'N'
,p_colspan=>3
,p_display_when=>'GLOBAL_TIPO_CONTRIBUYENTE'
,p_display_when2=>'8'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_api.id(5120299602344255)
,p_item_icon_css_classes=>'fa-users'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(263256139087233981)
,p_name=>'P127_ID_TIPO_PUESTO'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_api.id(523226387853819179)
,p_prompt=>'Tipo Puesto Fronterizo:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_TIPO_PUESTOF'
,p_lov=>'SELECT ID_TIPO_PUESTO, UPPER(NOMBRE_PUESTO) FROM tipo_puesto_fronterizo WHERE codigo_estado = ''AC'';'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_colspan=>3
,p_display_when=>'GLOBAL_TIPO_CONTRIBUYENTE'
,p_display_when2=>'8'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_api.id(5120299602344255)
,p_item_icon_css_classes=>'fa-chevron-down'
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(263256599669233981)
,p_name=>'P127_CODIGO_ADUANA'
,p_item_sequence=>200
,p_item_plug_id=>wwv_flow_api.id(523226387853819179)
,p_prompt=>'Tipo de Aduana:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    UPPER(NOMBRE_ADUANA),',
'    CODIGO_ADUANA',
'FROM tipo_aduanas_sit ',
'WHERE codigo_estado = ''AC'' ',
'AND id_tipo_puesto = :P127_ID_TIPO_PUESTO ORDER BY UPPER(NOMBRE_ADUANA) DESC;'))
,p_lov_display_null=>'YES'
,p_lov_cascade_parent_items=>'P127_ID_TIPO_PUESTO'
,p_ajax_items_to_submit=>'P127_ID_TIPO_PUESTO'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_colspan=>3
,p_display_when=>'GLOBAL_TIPO_CONTRIBUYENTE'
,p_display_when2=>'8'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_api.id(5120299602344255)
,p_item_icon_css_classes=>'fa-chevron-down'
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(263256906908233981)
,p_name=>'P127_CODIGO_UBICACION'
,p_item_sequence=>210
,p_item_plug_id=>wwv_flow_api.id(523226387853819179)
,p_prompt=>unistr('Tipo de Ubicaci\00F3n:')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    UPPER(nombre_ubicacion),',
'    codigo_ubicacion',
'FROM detalle_aduanas_sit ',
'    WHERE codigo_estado = ''AC'' ',
'    AND ID_TIPO_PUESTO = :P127_ID_TIPO_PUESTO ',
'    AND codigo_aduana = :P127_CODIGO_ADUANA ORDER BY UPPER(nombre_ubicacion) DESC;'))
,p_lov_display_null=>'YES'
,p_lov_cascade_parent_items=>'P127_CODIGO_ADUANA'
,p_ajax_items_to_submit=>'P127_CODIGO_ADUANA'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_colspan=>3
,p_display_when=>'GLOBAL_TIPO_CONTRIBUYENTE'
,p_display_when2=>'8'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_api.id(5120299602344255)
,p_item_icon_css_classes=>'fa-chevron-down'
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(263257671326233982)
,p_name=>'P127_CODIGO_MONEDA'
,p_item_sequence=>220
,p_item_plug_id=>wwv_flow_api.id(523226579380819180)
,p_prompt=>unistr('C\00F3digo Moneda:')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select upper(DESCRIPCION), CODIGO_MONEDA',
'from TIPO_MONEDAS@CONSULTA_ICTX',
'where CODIGO_MONEDA in (1,2)'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- Seleccionar -'
,p_cHeight=>1
,p_display_when=>'GLOBAL_TIPO_CONTRIBUYENTE'
,p_display_when2=>'8'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_api.id(5120299602344255)
,p_item_icon_css_classes=>'fa-chevron-down'
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_inline_help_text=>'<span style="color: #ff0000;">Estimado contribuyente, favor seleccionar la moneda con la cual usted va a realizar el pago de impuestos, una vez realizado el tr&aacute;mite no podr&aacute; ser modificada</span>'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(263258078721233983)
,p_name=>'P127_MONTO_TOTAL_TRANS'
,p_item_sequence=>230
,p_item_plug_id=>wwv_flow_api.id(523226579380819180)
,p_prompt=>'Monto Total por Transporte:'
,p_format_mask=>'999G999G999G999G990D00'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>10
,p_begin_on_new_line=>'N'
,p_display_when=>'GLOBAL_TIPO_CONTRIBUYENTE'
,p_display_when2=>'8'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_api.id(5120299602344255)
,p_item_icon_css_classes=>'fa-money'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(263258499654233984)
,p_name=>'P127_IMPUESTO_PAGAR'
,p_item_sequence=>240
,p_item_plug_id=>wwv_flow_api.id(523226579380819180)
,p_prompt=>'Impuesto por pagar:'
,p_format_mask=>'999G999G999G999G990D00'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>10
,p_begin_on_new_line=>'N'
,p_display_when=>'GLOBAL_TIPO_CONTRIBUYENTE'
,p_display_when2=>'8'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_api.id(5120299602344255)
,p_item_icon_css_classes=>'fa-money'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'Y'
,p_attribute_03=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(263259129909233985)
,p_name=>'P127_NUMERO_PLACA'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(523226662119819181)
,p_prompt=>unistr('N\00BA placa automotora:')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>20
,p_tag_attributes=>' onKeyUp="this.value = this.value.toUpperCase()"'
,p_field_template=>wwv_flow_api.id(5120299602344255)
,p_item_icon_css_classes=>'fa-car'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(263259581120233985)
,p_name=>'P127_NOMBRE_CHOFER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(523226662119819181)
,p_prompt=>'Nombre Chofer:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>80
,p_tag_attributes=>' onKeyUp="this.value = this.value.toUpperCase()"'
,p_begin_on_new_line=>'N'
,p_colspan=>3
,p_display_when=>'GLOBAL_TIPO_CONTRIBUYENTE'
,p_display_when2=>'8'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_api.id(5120299602344255)
,p_item_icon_css_classes=>'fa-user'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(263259940511233985)
,p_name=>'P127_NOMBRE_GUIA'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(523226662119819181)
,p_prompt=>unistr('Nombre Gu\00EDa:')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>80
,p_tag_attributes=>' onKeyUp="this.value = this.value.toUpperCase()"'
,p_begin_on_new_line=>'N'
,p_colspan=>3
,p_display_when=>'GLOBAL_TIPO_CONTRIBUYENTE'
,p_display_when2=>'8'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_api.id(5119973298344255)
,p_item_icon_css_classes=>'fa-user'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(263260362501233986)
,p_name=>'P127_CAPACIDAD'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(523226662119819181)
,p_prompt=>'Capacidad'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_colspan=>3
,p_field_template=>wwv_flow_api.id(5120299602344255)
,p_item_icon_css_classes=>'fa-stock-chart'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(263261099699233987)
,p_name=>'P127_ID_TTR'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(523227079802819185)
,p_prompt=>'TTR'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_tag_css_classes=>'u-bold'
,p_display_when=>'GLOBAL_TIPO_CONTRIBUYENTE'
,p_display_when2=>'4'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_api.id(5119973298344255)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(263261485320233987)
,p_name=>'P127_ID_COT'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(523227079802819185)
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_tag_css_classes=>'u-bold'
,p_display_when=>'GLOBAL_TIPO_CONTRIBUYENTE'
,p_display_when2=>'8'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_api.id(5119973298344255)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(263261859676233987)
,p_name=>'P127_CODIGO_TIBUTARIO'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(523227079802819185)
,p_prompt=>unistr('C\00F3digo Tributario')
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(5119973298344255)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(263262220327233988)
,p_name=>'P127_FECHA'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(523227079802819185)
,p_item_default=>'SYSDATE'
,p_item_default_type=>'PLSQL_EXPRESSION'
,p_prompt=>'Fecha:'
,p_format_mask=>'DD/MM/YYYY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>10
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(5119973298344255)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(263262628508233988)
,p_name=>'P127_ID_DECLARA_CTO'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(523227079802819185)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(263263047065233988)
,p_name=>'P127_CODIGO_ESTADO'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(523227079802819185)
,p_item_default=>'P'
,p_prompt=>'Estado:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_ESTADO_TRAMITE1'
,p_lov=>'SELECT CODIGO_ESTADO, NOMBRE_ESTADO FROM estados_tramite@consulta_ictx where CODIGO_ESTADO IN (''AC'',''IA'',''A'',''R'',''P'',''RG'',''EN'')'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_api.id(5119791289344256)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(263263469704233989)
,p_name=>'P127_ID_CONTRIBUYENTE'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(523227079802819185)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(263264123139233990)
,p_name=>'P127_CLEAR'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(576772110809760968)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(263264575251233991)
,p_name=>'P127_ID_REPORTE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(576772110809760968)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>5801312104779619
,p_default_application_id=>102
,p_default_id_offset=>0
,p_default_owner=>'DESA_SIT'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(263265098428233992)
,p_validation_name=>'VAL_CORREO1_FORMAT'
,p_validation_sequence=>10
,p_validation=>'select 1 from dual where not regexp_like (nvl(:P127_CORREO_NOTIFICA1,''n/a''), ''^[A-Za-z]+[A-Za-z0-9.]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}$'')'
,p_validation_type=>'NOT_EXISTS'
,p_error_message=>'Formato de correo incorrecto'
,p_always_execute=>'Y'
,p_validation_condition=>'P127_CORREO_NOTIFICA1'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_when_button_pressed=>wwv_flow_api.id(263248154715233969)
,p_associated_item=>wwv_flow_api.id(263250727564233975)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(263265463112233992)
,p_validation_name=>'VAL_CORREO2_FORMAT'
,p_validation_sequence=>20
,p_validation=>'select 1 from dual where not regexp_like (nvl(:P127_CORREO_NOTIFICA2,''n/a''), ''^[A-Za-z]+[A-Za-z0-9.]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}$'')'
,p_validation_type=>'NOT_EXISTS'
,p_error_message=>'Formato de correo incorrecto'
,p_always_execute=>'Y'
,p_validation_condition=>'P127_CORREO_NOTIFICA2'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_when_button_pressed=>wwv_flow_api.id(263248154715233969)
,p_associated_item=>wwv_flow_api.id(263251133255233975)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(263265856144233992)
,p_validation_name=>'VAL_NOM_ARRE'
,p_validation_sequence=>30
,p_validation=>'P127_NOMBRE_ARRENDA'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Debe ingresar en nombre del arrendatario'
,p_always_execute=>'Y'
,p_validation_condition=>'P127_CONTRATO_ARRENDA'
,p_validation_condition2=>'S'
,p_validation_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_when_button_pressed=>wwv_flow_api.id(263248154715233969)
,p_associated_item=>wwv_flow_api.id(263253072896233977)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(263266632874233995)
,p_validation_name=>'VAL_CED_ARRE'
,p_validation_sequence=>40
,p_validation=>'P127_CEDULA_ARRE'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>unistr('Debe ingresar el N\00B0 de identificaci\00F3n del arrendatario')
,p_always_execute=>'Y'
,p_validation_condition=>'P127_CONTRATO_ARRENDA'
,p_validation_condition2=>'S'
,p_validation_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_when_button_pressed=>wwv_flow_api.id(263248154715233969)
,p_associated_item=>wwv_flow_api.id(263253811674233978)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(263266209356233994)
,p_validation_name=>'VAL_TIP_CED_ARRE'
,p_validation_sequence=>50
,p_validation=>'P127_ID_TIPO_IDENTIFICA'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>unistr('Debe seleccionar una opci\00F3n')
,p_always_execute=>'Y'
,p_validation_condition=>'P127_CONTRATO_ARRENDA'
,p_validation_condition2=>'S'
,p_validation_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_when_button_pressed=>wwv_flow_api.id(263248154715233969)
,p_associated_item=>wwv_flow_api.id(263253448260233977)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(263267045908233995)
,p_validation_name=>'VAL_NUMERO_PLACA_NOT_NULL'
,p_validation_sequence=>70
,p_validation=>'P127_NUMERO_PLACA'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>unistr('Debe de ingresar el N\00BA placa automotora')
,p_always_execute=>'Y'
,p_when_button_pressed=>wwv_flow_api.id(263248154715233969)
,p_associated_item=>wwv_flow_api.id(263259129909233985)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(263267474254233995)
,p_validation_name=>'VAL_NOMBRE_ENTIDAD_NOT_NULL'
,p_validation_sequence=>80
,p_validation=>'P127_NOMBRE_ENTIDAD'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>unistr('Debe ingresar el nombre due\00F1o f\00EDsico o jur\00EDdico')
,p_always_execute=>'Y'
,p_when_button_pressed=>wwv_flow_api.id(263248154715233969)
,p_associated_item=>wwv_flow_api.id(263249518191233971)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(263273010943233998)
,p_validation_name=>'VAL_CAPACIDAD_NOT_NULL'
,p_validation_sequence=>90
,p_validation=>'P127_CAPACIDAD'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Debe ingresar la capacidad del automotor'
,p_always_execute=>'Y'
,p_when_button_pressed=>wwv_flow_api.id(263248154715233969)
,p_associated_item=>wwv_flow_api.id(263260362501233986)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(263267846889233995)
,p_validation_name=>'VAL_ID_TIPO_IDENTIFICACION_NOT_NULL'
,p_validation_sequence=>100
,p_validation=>'P127_ID_TIPO_IDENTIFICACION'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>unistr('Debe seleccionar una opci\00F3n')
,p_always_execute=>'Y'
,p_when_button_pressed=>wwv_flow_api.id(263248154715233969)
,p_associated_item=>wwv_flow_api.id(263249930133233974)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(263268233988233995)
,p_validation_name=>'VAL_CEDULA_NOT_NULL'
,p_validation_sequence=>110
,p_validation=>'P127_CEDULA'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>unistr('Debe ingresae la C\00E9dula')
,p_always_execute=>'Y'
,p_when_button_pressed=>wwv_flow_api.id(263248154715233969)
,p_associated_item=>wwv_flow_api.id(263250305450233974)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(263268625943233996)
,p_validation_name=>'VAL_CONTRATO_ARRENDA_NOT_NULL'
,p_validation_sequence=>120
,p_validation=>'P127_CONTRATO_ARRENDA'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>unistr('Debe seleccionar una opci\00F3n')
,p_always_execute=>'Y'
,p_when_button_pressed=>wwv_flow_api.id(263248154715233969)
,p_associated_item=>wwv_flow_api.id(263252640822233976)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(263269037153233996)
,p_validation_name=>'VAL_FECHA_INI_EXCUSION_NOT_NULL'
,p_validation_sequence=>130
,p_validation=>'P127_FECHA_INI_EXCUSION'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>unistr('Debe seleccionar fecha inicio de exclusi\00F3n')
,p_when_button_pressed=>wwv_flow_api.id(263248154715233969)
,p_associated_item=>wwv_flow_api.id(263254566402233979)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(263269457420233996)
,p_validation_name=>'VAL_FECHA_FIN_EXCUSION_NOT_NULL'
,p_validation_sequence=>140
,p_validation=>'P127_FECHA_FIN_EXCUSION'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>unistr('Debe seleccionar fecha fin de la exclusi\00F3n')
,p_always_execute=>'Y'
,p_when_button_pressed=>wwv_flow_api.id(263248154715233969)
,p_associated_item=>wwv_flow_api.id(263254960815233979)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(263269805391233996)
,p_validation_name=>'VAL_TOTAL_PASAJEROS_NOT_NULL'
,p_validation_sequence=>150
,p_validation=>'P127_TOTAL_PASAJEROS'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Debe ingresar la cantidad de personas'
,p_always_execute=>'Y'
,p_when_button_pressed=>wwv_flow_api.id(263248154715233969)
,p_associated_item=>wwv_flow_api.id(263255727835233980)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(263270286246233996)
,p_validation_name=>'VAL_CODIGO_MONEDA_NOT_NULL'
,p_validation_sequence=>160
,p_validation=>'P127_CODIGO_MONEDA'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>unistr('Debe seleccionar un c\00F3digo de moneda')
,p_when_button_pressed=>wwv_flow_api.id(263248154715233969)
,p_associated_item=>wwv_flow_api.id(263257671326233982)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(263270610838233997)
,p_validation_name=>'VAL_MONTO_TOTAL_TRANS_NOT_NULL'
,p_validation_sequence=>170
,p_validation=>'P127_MONTO_TOTAL_TRANS'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Debe ingresar el monto total por transporte'
,p_always_execute=>'Y'
,p_when_button_pressed=>wwv_flow_api.id(263248154715233969)
,p_associated_item=>wwv_flow_api.id(263258078721233983)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(263271069462233997)
,p_validation_name=>'VAL_IMPUESTO_PAGAR_NOT_NULL'
,p_validation_sequence=>180
,p_validation=>'P127_IMPUESTO_PAGAR'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Debe ingresar el impuesto por pagar'
,p_always_execute=>'Y'
,p_when_button_pressed=>wwv_flow_api.id(263248154715233969)
,p_associated_item=>wwv_flow_api.id(263258499654233984)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(263271473678233997)
,p_validation_name=>'VAL_NOMBRE_CHOFER_NOT_NULL'
,p_validation_sequence=>190
,p_validation=>'P127_NOMBRE_CHOFER'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Debe ingresar el nombre del chofer'
,p_always_execute=>'Y'
,p_when_button_pressed=>wwv_flow_api.id(263248154715233969)
,p_associated_item=>wwv_flow_api.id(263259581120233985)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(263271896835233997)
,p_validation_name=>'VAL_CORREO_NOTIFICA1_NOT_NULL'
,p_validation_sequence=>200
,p_validation=>'P127_CORREO_NOTIFICA1'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Debe ingresar un correo para Notificaciones 1'
,p_always_execute=>'Y'
,p_when_button_pressed=>wwv_flow_api.id(263248154715233969)
,p_associated_item=>wwv_flow_api.id(263250727564233975)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(263272267874233997)
,p_validation_name=>'VAL_TELEFONO1_NOT_NULL'
,p_validation_sequence=>210
,p_validation=>'P127_TELEFONO1'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>unistr('Debe ingresar t\00E9lefono 1')
,p_always_execute=>'Y'
,p_when_button_pressed=>wwv_flow_api.id(263248154715233969)
,p_associated_item=>wwv_flow_api.id(263251598216233975)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(263272608951233998)
,p_validation_name=>'VAL_CODIGO_DESTINO_NOT_NULL'
,p_validation_sequence=>220
,p_validation=>'P127_CODIGO_DESTINO'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>unistr('Debe seleccionar una opci\00F3n')
,p_when_button_pressed=>wwv_flow_api.id(263248154715233969)
,p_associated_item=>wwv_flow_api.id(263255337091233980)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(263273488556233998)
,p_validation_name=>'VAL_ID_TIPO_PUESTO_NOT_NULL'
,p_validation_sequence=>230
,p_validation=>'P127_ID_TIPO_PUESTO'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>unistr('Debe seleccionar una opci\00F3n')
,p_when_button_pressed=>wwv_flow_api.id(263248154715233969)
,p_associated_item=>wwv_flow_api.id(263256139087233981)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(263273887466233998)
,p_validation_name=>'VAL_CODIGO_ADUANA_NOT_NULL'
,p_validation_sequence=>240
,p_validation=>'P127_CODIGO_ADUANA'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>unistr('Debe seleccionar una opci\00F3n')
,p_when_button_pressed=>wwv_flow_api.id(263248154715233969)
,p_associated_item=>wwv_flow_api.id(263256599669233981)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(263274240884233998)
,p_validation_name=>'VAL_CODIGO_UBICACION_NOT_NULL'
,p_validation_sequence=>250
,p_validation=>'P127_CODIGO_UBICACION'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>unistr('Debe seleccionar una opci\00F3n')
,p_when_button_pressed=>wwv_flow_api.id(263248154715233969)
,p_associated_item=>wwv_flow_api.id(263256906908233981)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(263275386624234000)
,p_name=>'DAC_MUESTRA_ARRENDAT'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P127_CONTRATO_ARRENDA'
,p_condition_element=>'P127_CONTRATO_ARRENDA'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'S'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(263275848173234001)
,p_event_id=>wwv_flow_api.id(263275386624234000)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P127_NOMBRE_ARRENDA,P127_ID_TIPO_IDENTIFICA,P127_CEDULA_ARRE'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(263276385746234001)
,p_event_id=>wwv_flow_api.id(263275386624234000)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P127_NOMBRE_ARRENDA,P127_ID_TIPO_IDENTIFICA,P127_CEDULA_ARRE'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(263276819281234002)
,p_event_id=>wwv_flow_api.id(263275386624234000)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'NULL;',
'IF :GLOBAL_TIPO_CONTRIBUYENTE = 8 THEN',
':P127_ID_REPORTE := 1220;',
'ELSE ',
':P127_ID_REPORTE := 1282;',
'END IF;',
'',
'END;'))
,p_attribute_02=>'P127_CONTRATO_ARRENDA,P127_NOMBRE_ARRENDA,P127_ID_TIPO_IDENTIFICA,P127_CEDULA_ARRE,P127_ID_REPORTE'
,p_attribute_03=>'P127_ID_REPORTE'
,p_attribute_04=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(263277377901234002)
,p_event_id=>wwv_flow_api.id(263275386624234000)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P127_NOMBRE_ARRENDA := NULL;',
':P127_ID_TIPO_IDENTIFICA := NULL;',
':P127_CEDULA_ARRE := NULL;',
'IF :GLOBAL_TIPO_CONTRIBUYENTE = 8 THEN',
':P127_ID_REPORTE := 1240;',
'ELSE ',
':P127_ID_REPORTE := 1302;',
'END IF;',
''))
,p_attribute_02=>'P127_CONTRATO_ARRENDA,P127_ID_REPORTE'
,p_attribute_03=>'P127_NOMBRE_ARRENDA,P127_ID_TIPO_IDENTIFICA,P127_CEDULA_ARRE,P127_ID_REPORTE'
,p_attribute_04=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(263277705850234002)
,p_name=>'DAC_FORMULA'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P127_MONTO_TOTAL_TRANS'
,p_bind_type=>'live'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(263278203386234003)
,p_event_id=>wwv_flow_api.id(263277705850234002)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'vImpuesto NUMBER;',
'BEGIN',
'vImpuesto:= :P127_MONTO_TOTAL_TRANS * 0.05;',
':P127_IMPUESTO_PAGAR:= vImpuesto;',
'END;'))
,p_attribute_02=>'P127_MONTO_TOTAL_TRANS,P127_IMPUESTO_PAGAR'
,p_attribute_03=>'P127_IMPUESTO_PAGAR'
,p_attribute_04=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(263278747839234003)
,p_event_id=>wwv_flow_api.id(263277705850234002)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P127_IMPUESTO_PAGAR'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(263280929301234004)
,p_name=>'DAC_CLEAR_ITEMS'
,p_event_sequence=>300
,p_condition_element=>'P127_CLEAR'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'S'
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_cond=>'P127_CLEAR'
,p_display_when_cond2=>'S'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(263281425375234005)
,p_event_id=>wwv_flow_api.id(263280929301234004)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>':P127_CLEAR := ''N'';'
,p_attribute_02=>'P127_CLEAR'
,p_attribute_03=>'P127_CLEAR'
,p_attribute_04=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(263281861035234005)
,p_name=>'DAC_DATOS_CONTRIBUYENTE'
,p_event_sequence=>310
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(263282363730234005)
,p_event_id=>wwv_flow_api.id(263281861035234005)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    vTipoIdent NUMBER;',
'    vCedulaF VARCHAR2(20); ',
'    vCedulaJ VARCHAR2(20);',
'    vTelefono NUMBER;',
'    vCorreo VARCHAR2(50);',
'    ',
'    CURSOR C_DATOS_CONTRIB IS',
'    SELECT ID_TIPO_IDENTIFICACION,CEDULA_JURIDICA,CEDULA_FISICA',
'    FROM   MAESTRO_CONTRIBUYENTE',
'    WHERE  ID_CONTRIBUYENTE = :P127_ID_CONTRIBUYENTE;',
'    ',
'    CURSOR C_TELEFONO IS ',
'    SELECT TELEFONO ',
'    FROM TELEFONO_X_MAESTRO_CONTRIBU',
'    WHERE ID_CONTRIBUYENTE = :P127_ID_CONTRIBUYENTE;',
'    ',
'    CURSOR C_CORREO IS',
'    SELECT CORREO_NOTIFICA',
'    FROM  CORREO_NOTIFICACIONES',
'    WHERE ID_CONTRIBUYENTE = :P127_ID_CONTRIBUYENTE',
'    AND   CODIGO_ESTADO = ''AC'';',
'BEGIN',
'    ',
'    OPEN  C_DATOS_CONTRIB;',
'    FETCH C_DATOS_CONTRIB  INTO vTipoIdent,vCedulaJ,vCedulaF;',
'    CLOSE C_DATOS_CONTRIB;',
'    ',
'    OPEN C_TELEFONO;',
'    FETCH C_TELEFONO INTO vTelefono;',
'    :P127_TELEFONO1 := vTelefono;',
'    FETCH C_TELEFONO INTO vTelefono;',
'    :P127_TELEFONO2 := vTelefono;',
'    CLOSE C_TELEFONO;',
'    ',
'    OPEN  C_CORREO;',
'    FETCH C_CORREO INTO vCorreo;',
'    :P127_CORREO_NOTIFICA1 := vCorreo;',
'    FETCH C_CORREO INTO vCorreo;',
'    :P127_CORREO_NOTIFICA2 := vCorreo;',
'    CLOSE C_CORREO;',
'    ',
':P127_ID_TIPO_IDENTIFICACION := vTipoIdent;',
'    IF vTipoIdent = 1 THEN',
'       :P127_CEDULA := vCedulaJ;',
'    ELSE',
'       :P127_CEDULA := vCedulaF;',
'    END IF;',
':P127_NOMBRE_ENTIDAD := PKG_MAESTRO_CONTRIBUYENTE.F_RETORNA_NOM_CONTRI(PKG_MAESTRO_CONTRIBUYENTE.RETORNA_ID_DEUDOR_CONTRIB (:P127_ID_CONTRIBUYENTE));',
'END ;'))
,p_attribute_02=>'P127_ID_CONTRIBUYENTE'
,p_attribute_03=>'P127_NOMBRE_ENTIDAD,P127_ID_TIPO_IDENTIFICACION,P127_CEDULA,P127_TELEFONO1,P127_TELEFONO2,P127_CORREO_NOTIFICA1,P127_CORREO_NOTIFICA2'
,p_attribute_04=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(263279123790234003)
,p_name=>'DAC_SOLO_LETRAS'
,p_event_sequence=>320
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P127_NOMBRE_ENTIDAD,P127_NOMBRE_CHOFER,P127_NOMBRE_GUIA,P127_NOMBRE_ARRENDA'
,p_bind_type=>'bind'
,p_bind_event_type=>'keydown'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(263279689838234004)
,p_event_id=>wwv_flow_api.id(263279123790234003)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'validateText(event);'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(263280014225234004)
,p_name=>'DAC_SOLO_NUMEROS'
,p_event_sequence=>330
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P127_CAPACIDAD,P127_TELEFONO1,P127_TELEFONO2,P127_TOTAL_PASAJEROS,P127_MONTO_TOTAL_TRANS,P127_IMPUESTO_PAGAR'
,p_bind_type=>'bind'
,p_bind_event_type=>'keydown'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(263280581077234004)
,p_event_id=>wwv_flow_api.id(263280014225234004)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'validateNumber(event);'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(263282719959234006)
,p_name=>'DAC_FIELDS_REPORT_SUBMIT'
,p_event_sequence=>340
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P127_NUMERO_PLACA, P127_NOMBRE_CHOFER, P127_NOMBRE_GUIA, P127_CAPACIDAD, P127_CONTRATO_ARRENDA, P127_NOMBRE_ARRENDA, P127_ID_TIPO_IDENTIFICA, P127_CEDULA_ARRE, P127_FECHA_INI_EXCUSION, P127_FECHA_FIN_EXCUSION, P127_CODIGO_DESTINO, P127_TOTAL_PASAJERO'
||'S, P127_ID_TIPO_PUESTO, P127_CODIGO_MONEDA, P127_MONTO_TOTAL_TRANS, P127_IMPUESTO_PAGAR'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(263283274059234007)
,p_event_id=>wwv_flow_api.id(263282719959234006)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'NULL;'
,p_attribute_02=>'P127_NUMERO_PLACA, P127_NOMBRE_CHOFER, P127_NOMBRE_GUIA, P127_CAPACIDAD, P127_CONTRATO_ARRENDA, P127_NOMBRE_ARRENDA, P127_ID_TIPO_IDENTIFICA, P127_CEDULA_ARRE, P127_FECHA_INI_EXCUSION, P127_FECHA_FIN_EXCUSION, P127_CODIGO_DESTINO, P127_TOTAL_PASAJERO'
||'S, P127_ID_TIPO_PUESTO, P127_CODIGO_MONEDA, P127_MONTO_TOTAL_TRANS, P127_IMPUESTO_PAGAR'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(263274936318234000)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_DATOS'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    vID NUMBER;',
'    vSecuencia_COT VARCHAR2 (10) := ''DAT-DO-03-'';',
'    vSecuencia_TTR VARCHAR2 (10) := ''TSR-'';',
'    vIdContrib NUMBER;',
'    vNombreContrib VARCHAR2 (100);',
'    ',
'    CURSOR C_ID IS',
'    SELECT MAX(ID_DECLARA_CTO)',
'    FROM DECLARA_CHARTER_TERRESTRE_O;',
'    ',
'    CURSOR C_DATOS_CONTRIB IS',
'    SELECT NOMBRE_ENTIDAD--,ID_TIPO_IDENTIFICACION,CEDULA_JURIDICA,CEDULA_FISICA',
'    FROM   MAESTRO_CONTRIBUYENTE',
'    WHERE  ID_CONTRIBUYENTE = vIdContrib;',
'BEGIN',
'    OPEN  C_ID;',
'    FETCH C_ID INTO vID;',
'    CLOSE C_ID;',
'    ',
'    OPEN  C_DATOS_CONTRIB;',
'    FETCH C_DATOS_CONTRIB  INTO vNombreContrib;',
'    CLOSE C_DATOS_CONTRIB;',
'    ',
'    vID := vID +1;',
'    :P127_ID_COT := vSecuencia_COT||vID||''-''||EXTRACT(YEAR FROM sysdate);',
'    :P127_ID_TTR := vSecuencia_TTR||vID||''-''||EXTRACT(YEAR FROM sysdate);',
'    vIdContrib := PKG_MAESTRO_CONTRIBUYENTE.RETORNA_ID_CONTRIBUYENTE (:GLOBAL_USUARIO);',
'    :P127_ID_CONTRIBUYENTE := vIdContrib;',
'    :P127_CODIGO_TIBUTARIO := PKG_MAESTRO_CONTRIBUYENTE.RETORNA_ID_DEUDOR_CONTRIB (vIdContrib);',
'END;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(263274597401233999)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_INSERTA_DECLARACION'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    vIdDeclaracion NUMBER;',
'    v_retorno_boolean boolean;',
'    v_mensaje_retorno varchar2(2000);',
'    vFecha DATE;',
'    vFechaInicio DATE;',
'    vFechaFin DATE;',
'    vNum_Tramite VARCHAR2(20);',
'BEGIN',
'    vFecha       := TO_DATE(:P127_FECHA,''DD/MM/YYYY'');',
'    vFechaInicio := TO_DATE(:P127_FECHA_INI_EXCUSION,''DD/MM/YYYY'');',
'    vFechaFin    := TO_DATE(:P127_FECHA_FIN_EXCUSION,''DD/MM/YYYY'');',
'    ',
'    IF :GLOBAL_TIPO_CONTRIBUYENTE = 8 THEN',
'        vNum_Tramite := :P127_ID_COT;',
'    ELSE',
'         vNum_Tramite := :P127_ID_TTR;',
'    END IF;',
'',
'    PKG_TRAMITE_COT.INSERTA_DECLARACION_JURADA_COT (vIdDeclaracion,',
'                                                    :P127_NOMBRE_ENTIDAD,',
'                                                    :P127_ID_TIPO_IDENTIFICACION,',
'                                                    :P127_CEDULA,',
'                                                    :P127_TELEFONO1,',
'                                                    :P127_TELEFONO2,',
'                                                    vFecha,',
'                                                    :P127_NUMERO_PLACA,',
'                                                    :P127_CONTRATO_ARRENDA,',
'                                                    :P127_NOMBRE_ARRENDA,',
'                                                    :P127_ID_TIPO_IDENTIFICA,',
'                                                    :P127_CEDULA_ARRE,',
'                                                    vFechaInicio,',
'                                                    vFechaFin,',
'                                                    :P127_TOTAL_PASAJEROS,',
'                                                    :P127_MONTO_TOTAL_TRANS,',
'                                                    :P127_IMPUESTO_PAGAR,',
'                                                    :P127_NOMBRE_CHOFER,',
'                                                    :P127_NOMBRE_GUIA,',
'                                                    ''P'',',
'                                                    :P127_CORREO_NOTIFICA1,',
'                                                    :P127_CORREO_NOTIFICA2,',
'                                                    :APP_USER,',
'                                                    :P127_ID_TIPO_PUESTO,',
'                                                    :P127_CODIGO_MONEDA,',
'                                                    :vNum_Tramite,',
'                                                    :P127_CAPACIDAD,',
'                                                    :P127_CODIGO_DESTINO,',
'                                                    :P127_CODIGO_ADUANA,',
'                                                    :P127_CODIGO_UBICACION,                ',
'                                                    v_mensaje_retorno,',
'                                                    v_retorno_boolean);',
':P127_ID_DECLARA_CTO := vIdDeclaracion;',
'END;'))
,p_process_error_message=>unistr('Error al generar la declaraci\00F3n')
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(263248154715233969)
,p_process_success_message=>unistr('Declaraci\00F3n creada con \00E9xito')
);
wwv_flow_api.component_end;
end;
/
