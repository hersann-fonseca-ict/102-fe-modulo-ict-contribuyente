prompt --application/pages/page_00104
begin
--   Manifest
--     PAGE: 00104
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>5801312104779619
,p_default_application_id=>102
,p_default_id_offset=>0
,p_default_owner=>'DESA_SIT'
);
wwv_flow_api.create_page(
 p_id=>104
,p_user_interface_id=>wwv_flow_api.id(5143571665344221)
,p_name=>'II.Impuestos / Encargado'
,p_alias=>'II-IMPUESTOS-ENCARGADO'
,p_step_title=>'Impuestos / Encargado'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_browser_cache=>'N'
,p_last_updated_by=>'JORGE.ROJAS'
,p_last_upd_yyyymmddhh24miss=>'20241030140115'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(5415175798363337)
,p_plug_name=>'II.Impuestos / Encargado'
,p_region_template_options=>'#DEFAULT#:t-Wizard--hideStepsXSmall'
,p_plug_template=>wwv_flow_api.id(5069356128344283)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_list_id=>wwv_flow_api.id(5407085389363356)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_api.id(5098266341344267)
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(5415267939363337)
,p_plug_name=>'II.Impuestos / Encargado'
,p_parent_plug_id=>wwv_flow_api.id(5415175798363337)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(5031545193344301)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(5348047441975040)
,p_plug_name=>unistr('Informaci\00F3n encargado del Impuesto')
,p_parent_plug_id=>wwv_flow_api.id(5415267939363337)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(5058998562344289)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(5348250554975042)
,p_plug_name=>'Tipos de Impuestos a declarar'
,p_parent_plug_id=>wwv_flow_api.id(5415267939363337)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(5058998562344289)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(48678934759766352)
,p_plug_name=>'Domicilio Fiscal'
,p_parent_plug_id=>wwv_flow_api.id(5415267939363337)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(5058998562344289)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(5417183474363336)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(5415175798363337)
,p_button_name=>'PREVIOUS'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5121094921344251)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Regresar'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_button_execute_validations=>'N'
,p_icon_css_classes=>'fa-angle-double-left'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(5416991722363336)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(5415175798363337)
,p_button_name=>'CANCEL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5121094921344251)
,p_button_image_alt=>'Cancelar'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:1:&APP_SESSION.::&DEBUG.:::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(5417216112363336)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_api.id(5415175798363337)
,p_button_name=>'NEXT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5121094921344251)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Siguiente'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_icon_css_classes=>'fa-angle-double-right'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(5418608751363336)
,p_branch_action=>'f?p=&APP_ID.:105:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(5417216112363336)
,p_branch_sequence=>20
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(5417907343363336)
,p_branch_name=>'Go To Page 103'
,p_branch_action=>'f?p=&APP_ID.:103:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_VALIDATION'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(5417183474363336)
,p_branch_sequence=>10
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5348180072975041)
,p_name=>'P104_NOM_ENC_IMP'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(5348047441975040)
,p_prompt=>'Nombre Completo:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>50
,p_field_template=>wwv_flow_api.id(5120101748344255)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5348421959975044)
,p_name=>'P104_CED_ENC_IMP'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(5348047441975040)
,p_prompt=>unistr('N\00B0 C\00E9dula:')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(5120101748344255)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_help_text=>unistr('Por favor ingresar el n\00FAmero de c\00E9dula sin espacios y sin guiones ejemplo (102220333).')
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5348503344975045)
,p_name=>'P104_EMAIL_ENC_IMP'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(5348047441975040)
,p_prompt=>'Correo:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(5120101748344255)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5416675628363336)
,p_name=>'P104_TIP_IMPUESTO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(5348250554975042)
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC(,):Impuesto del 5% sobre el valor de pasajes vendidos en Costa Rica, para cualquier clase de viajes internacionales (CR)1'
,p_field_template=>wwv_flow_api.id(5119886074344255)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(11622605473478648)
,p_name=>'P104_TIP_IMPUESTO_1'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(5348250554975042)
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC(,):Impuesto del 5% sobre el valor de pasajes cuyo origen de ruta sea Costa Rica, para cualquier clase de viajes internacionales (OU)2'
,p_display_when=>'P104_VAL_IMPUESTO_1'
,p_display_when2=>'S'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_api.id(5119886074344255)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(11622783907478649)
,p_name=>'P104_TIP_IMPUESTO_2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(5348250554975042)
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC(,):Impuesto de quince d\00F3lares ($15.00) por el ingreso al pa\00EDs v\00EDa a\00E9rea, mediante boleto adquirido en el exterior (NW)3')
,p_display_when=>'P104_VAL_IMPUESTO_2'
,p_display_when2=>'S'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_api.id(5119886074344255)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(43135533332105910)
,p_name=>'P104_VAL_IMPUESTO'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(5348250554975042)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(43135805718105913)
,p_name=>'P104_VAL_IMPUESTO_1'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(5348250554975042)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(43135994203105914)
,p_name=>'P104_VAL_IMPUESTO_2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(5348250554975042)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(43330565592791315)
,p_name=>'P104_PROV_FISCAL'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(48678934759766352)
,p_prompt=>'Provincia:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'SELECT DESCRIPCION, ID FROM PROVINCIAS@consulta_ictx'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(5119886074344255)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(43330934387791318)
,p_name=>'P104_CANTON_FISCAL'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(48678934759766352)
,p_prompt=>unistr('Cant\00F3n:')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DESCRIPCION, ID ',
'FROM CANTONES@consulta_ictx ',
'WHERE PROV_ID = :P104_PROV_FISCAL'))
,p_lov_display_null=>'YES'
,p_lov_cascade_parent_items=>'P104_PROV_FISCAL'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(5119886074344255)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(43331359894791319)
,p_name=>'P104_DIST_FISCAL'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(48678934759766352)
,p_prompt=>'Distrito:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DESCRIPCION, ID ',
'FROM DISTRITOS@consulta_ictx ',
'WHERE PROV_ID = :P104_PROV_FISCAL',
'AND CANTON_ID = :P104_CANTON_FISCAL'))
,p_lov_display_null=>'YES'
,p_lov_cascade_parent_items=>'P104_PROV_FISCAL,P104_CANTON_FISCAL'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(5119886074344255)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(43331710293791320)
,p_name=>'P104_DIRECCION_FISCAL'
,p_is_required=>true
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(48678934759766352)
,p_prompt=>unistr('Direcci\00F3n Fiscal:')
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>173
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(5120101748344255)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(11620860198478630)
,p_validation_name=>'VAL_FORMATO_EMAIL'
,p_validation_sequence=>10
,p_validation=>'P104_EMAIL_ENC_IMP'
,p_validation2=>'@'
,p_validation_type=>'ITEM_IN_VALIDATION_CONTAINS_AT_LEAST_ONE_CHAR_IN_STRING2'
,p_error_message=>'Formato del email no valido'
,p_associated_item=>wwv_flow_api.id(5348503344975045)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(25656209989811234)
,p_validation_name=>'VAL_CEDULA'
,p_validation_sequence=>20
,p_validation=>'P104_CED_ENC_IMP'
,p_validation_type=>'ITEM_IS_ALPHANUMERIC'
,p_error_message=>unistr('Por favor ingresar el n\00FAmero de c\00E9dula sin espacios y sin guiones ejemplo (102220333)')
,p_associated_item=>wwv_flow_api.id(5348421959975044)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(13957476953744219)
,p_validation_name=>'VAL_COMAS'
,p_validation_sequence=>30
,p_validation=>'P104_EMAIL_ENC_IMP'
,p_validation2=>','
,p_validation_type=>'ITEM_IN_VALIDATION_CONTAINS_NO_CHAR_IN_STRING2'
,p_error_message=>'Formato de correo no valido, por favor verificar'
,p_associated_item=>wwv_flow_api.id(5348503344975045)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(42254618740382149)
,p_name=>'DAC_UPPER_NOM_ENC'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P104_NOM_ENC_IMP'
,p_bind_type=>'bind'
,p_bind_event_type=>'focusout'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(42254745632382150)
,p_event_id=>wwv_flow_api.id(42254618740382149)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$("#P104_NOM_ENC_IMP").val($("#P104_NOM_ENC_IMP").val().toUpperCase());'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(43432312256015945)
,p_name=>'DAC_UPPER_DIRECCION'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P104_DIRECCION_FISCAL'
,p_bind_type=>'bind'
,p_bind_event_type=>'focusout'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(43432402477015946)
,p_event_id=>wwv_flow_api.id(43432312256015945)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$("#P104_DIRECCION_FISCAL").val($("#P104_DIRECCION_FISCAL").val().toUpperCase());'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(43135483293105909)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_DATOS'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'IF :P102_TIPO_CONTRIBUYENTE IN (2,4) THEN',
'    :P104_VAL_IMPUESTO_1 := ''N'';',
'    :P104_VAL_IMPUESTO_2 := ''N'';',
'ELSE',
'    :P104_VAL_IMPUESTO_1 := ''S'';',
'    :P104_VAL_IMPUESTO_2 := ''S'';',
'END IF;',
'',
'IF :P102_TIPO_CONTRIBUYENTE IN (5) THEN',
'   :P104_VAL_IMPUESTO_2 := ''N'';',
'--ELSE',
' --   :P104_VAL_IMPUESTO_2 := ''S'';',
'END IF;',
'END;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(13957393592744218)
,p_process_sequence=>10
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_IMPUESTOS'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'--Agencia de viajes',
'IF :P102_TIPO_CONTRIBUYENTE = 2 THEN',
'    IF :P104_TIP_IMPUESTO IS NULL THEN',
'    RAISE_APPLICATION_ERROR(-20000, ''Debe seleccionar un impuesto, por favor verifique.'');',
'    END IF;',
'END IF;',
'',
'--Lineas aereas',
'IF :P102_TIPO_CONTRIBUYENTE = 3 THEN',
'    IF :P104_TIP_IMPUESTO IS NULL AND :P104_TIP_IMPUESTO_1 IS NULL AND :P104_TIP_IMPUESTO_2 IS NULL THEN',
'    RAISE_APPLICATION_ERROR(-20000, ''Debe seleccionar un impuesto, por favor verifique.'');',
'    END IF;',
'END IF;',
'',
'--Trasporte Terrestre',
'IF :P102_TIPO_CONTRIBUYENTE = 4 THEN',
'   IF :P104_TIP_IMPUESTO IS NULL THEN',
'    RAISE_APPLICATION_ERROR(-20000, ''Debe seleccionar un impuesto, por favor verifique.'');',
'    END IF;',
'END IF;',
'',
'--Trasporte Naviera',
'IF :P102_TIPO_CONTRIBUYENTE = 5 THEN',
'   IF :P104_TIP_IMPUESTO IS NULL AND :P104_TIP_IMPUESTO_1 IS NULL THEN',
'    RAISE_APPLICATION_ERROR(-20000, ''Debe seleccionar un impuesto, por favor verifique.'');',
'    END IF;',
'END IF;',
'END;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
