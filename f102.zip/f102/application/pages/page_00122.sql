prompt --application/pages/page_00122
begin
--   Manifest
--     PAGE: 00122
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>5801312104779619
,p_default_application_id=>102
,p_default_id_offset=>0
,p_default_owner=>'DESA_SIT'
);
wwv_flow_api.create_page(
 p_id=>122
,p_user_interface_id=>wwv_flow_api.id(5143571665344221)
,p_name=>unistr('inscripcion Tr\00E1mite Ch\00E1rter Ocasional Terrestre')
,p_alias=>unistr('INSCRIPCION-TR\00C1MITE-CH\00C1RTER-OCASIONAL-TERRESTRE')
,p_step_title=>unistr('Ch\00E1rter Ocasional Terrestre')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_browser_cache=>'N'
,p_last_updated_by=>'KIMBERLYN.SOLANO'
,p_last_upd_yyyymmddhh24miss=>'20221121125419'
);
wwv_flow_api.component_end;
end;
/
