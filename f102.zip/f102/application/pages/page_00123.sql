prompt --application/pages/page_00123
begin
--   Manifest
--     PAGE: 00123
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>5801312104779619
,p_default_application_id=>102
,p_default_id_offset=>0
,p_default_owner=>'DESA_SIT'
);
wwv_flow_api.create_page(
 p_id=>123
,p_user_interface_id=>wwv_flow_api.id(5143571665344221)
,p_name=>'123-Solicitar Usuario'
,p_alias=>'123-SOLICITAR-USUARIO'
,p_step_title=>'Solicitar Usuario'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_last_updated_by=>'KIMBERLYN.SOLANO'
,p_last_upd_yyyymmddhh24miss=>'20220310121350'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(31080264792718345)
,p_plug_name=>'Solicitar Usuario'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(5058998562344289)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(31079031402718333)
,p_plug_name=>'Formulario Solicitar Usuario'
,p_parent_plug_id=>wwv_flow_api.id(31080264792718345)
,p_region_template_options=>'t-Login-region--headerHidden'
,p_plug_template=>wwv_flow_api.id(5057695117344289)
,p_plug_display_sequence=>20
,p_plug_display_column=>5
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(31080133202718344)
,p_button_sequence=>110
,p_button_plug_id=>wwv_flow_api.id(31079031402718333)
,p_button_name=>'BTN_ENVIAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5121094921344251)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Enviar'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(42253716120382140)
,p_button_sequence=>120
,p_button_plug_id=>wwv_flow_api.id(31079031402718333)
,p_button_name=>'BTN_REGRESAR'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5121094921344251)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Cancelar'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.:::'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(38648648276961126)
,p_branch_name=>'Go to 110'
,p_branch_action=>'f?p=&APP_ID.:110:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(31079122884718334)
,p_name=>'P123_NOMBRE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(31079031402718333)
,p_prompt=>'Nombre completo:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>50
,p_field_template=>wwv_flow_api.id(5119973298344255)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(31079262029718335)
,p_name=>'P123_ID_TIPO_IDENTIFICACION'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(31079031402718333)
,p_prompt=>unistr('Tipo Identificaci\00F3n:')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_TIPO_IDENTIFICACION'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(5119973298344255)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(31079319101718336)
,p_name=>'P123_CEDULA'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(31079031402718333)
,p_prompt=>'Cedula:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(5119973298344255)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(31079450135718337)
,p_name=>'P123_ID_PROVINCIA_NOTIFICA'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(31079031402718333)
,p_prompt=>'Provincia:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'SELECT DESCRIPCION, ID FROM PROVINCIAS@consulta_ictx'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(5119973298344255)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(31079539380718338)
,p_name=>'P123_ID_CANTON_NOTIFICA'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(31079031402718333)
,p_prompt=>unistr('Cant\00F3n:')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DESCRIPCION, ID ',
'FROM CANTONES@consulta_ictx ',
'WHERE PROV_ID = :P123_ID_PROVINCIA_NOTIFICA'))
,p_lov_display_null=>'YES'
,p_lov_cascade_parent_items=>'P123_ID_PROVINCIA_NOTIFICA'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(5119973298344255)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(31079653717718339)
,p_name=>'P123_ID_DISTRITO_NOTIFICA'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_api.id(31079031402718333)
,p_prompt=>'Distrito:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DESCRIPCION, ID ',
'FROM DISTRITOS@consulta_ictx ',
'WHERE PROV_ID = :P123_ID_PROVINCIA_NOTIFICA',
'AND CANTON_ID = :P123_ID_CANTON_NOTIFICA'))
,p_lov_display_null=>'YES'
,p_lov_cascade_parent_items=>'P123_ID_PROVINCIA_NOTIFICA,P123_ID_CANTON_NOTIFICA'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(5119973298344255)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(31079701611718340)
,p_name=>'P123_DIRECCION_NOTIFICA'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_api.id(31079031402718333)
,p_prompt=>unistr('Direcci\00F3n:')
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(5119973298344255)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(31079883060718341)
,p_name=>'P123_TELEFONO1'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(31079031402718333)
,p_prompt=>unistr('Tel\00E9fonos:')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(5119973298344255)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(31079999295718342)
,p_name=>'P123_TELEFONO2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(31079031402718333)
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(5119973298344255)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(31080027752718343)
,p_name=>'P123_CORREO'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(31079031402718333)
,p_prompt=>'Correo:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(5119973298344255)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(43551485871307743)
,p_name=>'P123_VALID_MC'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(31079031402718333)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(43551551358307744)
,p_name=>'P123_MENSAJE'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(31079031402718333)
,p_item_default=>'El contribuyente ya se encuentra inscrito...'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_tag_attributes=>'style="color:red;"'
,p_field_template=>wwv_flow_api.id(5119973298344255)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(38648347125961123)
,p_validation_name=>'VAL_CORREO'
,p_validation_sequence=>10
,p_validation=>'P123_CORREO'
,p_validation2=>'@'
,p_validation_type=>'ITEM_IN_VALIDATION_CONTAINS_AT_LEAST_ONE_CHAR_IN_STRING2'
,p_error_message=>'Formato de correo incorrecto'
,p_validation_condition=>'P123_CORREO'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_associated_item=>wwv_flow_api.id(31080027752718343)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(38648483309961124)
,p_validation_name=>'VAL_CEDULA'
,p_validation_sequence=>20
,p_validation=>'P123_CEDULA'
,p_validation_type=>'ITEM_IS_ALPHANUMERIC'
,p_error_message=>unistr('Por favor ingresar el n\00FAmero de c\00E9dula sin espacios y sin guiones ejemplo (102220333)')
,p_validation_condition=>'P123_CEDULA'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_associated_item=>wwv_flow_api.id(31079319101718336)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(45396709692558407)
,p_name=>'DAC_VALIDA_MC'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P123_CEDULA'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(45397143893558410)
,p_event_id=>wwv_flow_api.id(45396709692558407)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'vExiste VARCHAR2(1);',
'BEGIN',
':P123_VALID_MC:= PKG_MAESTRO_CONTRIBUYENTE.VALIDA_EXISTE_MC (:P123_CEDULA);',
'END;'))
,p_attribute_02=>'P123_CEDULA'
,p_attribute_03=>'P123_VALID_MC'
,p_attribute_04=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(43551609185307745)
,p_name=>'DAC_MUESTRA_MSJ'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P123_VALID_MC'
,p_condition_element=>'P123_VALID_MC'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'S'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(43551733743307746)
,p_event_id=>wwv_flow_api.id(43551609185307745)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P123_MENSAJE'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(43551884695307747)
,p_event_id=>wwv_flow_api.id(43551609185307745)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P123_MENSAJE'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(43551953998307748)
,p_event_id=>wwv_flow_api.id(43551609185307745)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_api.id(31080133202718344)
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(43552040952307749)
,p_event_id=>wwv_flow_api.id(43551609185307745)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_api.id(31080133202718344)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(43552168679307750)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_DATOS'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
':P123_VALID_MC := NULL;',
':P123_CEDULA := NULL;',
'END;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(38648531484961125)
,p_process_sequence=>10
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_INSERTA_SOLICITUD'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'vMensaje_Retorno varchar2(200);',
'vRetorno boolean;',
'vCedulaF VARCHAR2(30);',
'vCedulaJ VARCHAR2(30);',
'BEGIN',
'IF :P123_ID_TIPO_IDENTIFICACION = 1 THEN',
'    vCedulaJ := :P123_CEDULA;',
'ELSE',
'    vCedulaF := :P123_CEDULA;',
'END IF;',
'P_SOLICITUD_USUARIO_PWD_COT (:P123_NOMBRE,',
'                             :P123_ID_TIPO_IDENTIFICACION,',
'                             vCedulaF,',
'                             vCedulaJ,',
'                             :P123_ID_PROVINCIA_NOTIFICA,',
'                             :P123_ID_CANTON_NOTIFICA,',
'                             :P123_ID_DISTRITO_NOTIFICA,',
'                             :P123_DIRECCION_NOTIFICA,',
'                             :P123_TELEFONO1,',
'                             :P123_TELEFONO2,',
'                             :P123_CORREO,',
'                             :APP_USER,',
'                             vMensaje_Retorno,',
'                             vRetorno); ',
'END;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(31080133202718344)
);
wwv_flow_api.component_end;
end;
/
