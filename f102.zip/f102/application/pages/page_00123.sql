prompt --application/pages/page_00123
begin
--   Manifest
--     PAGE: 00123
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>5801312104779619
,p_default_application_id=>102
,p_default_id_offset=>0
,p_default_owner=>'DESA_SIT'
);
wwv_flow_api.create_page(
 p_id=>123
,p_user_interface_id=>wwv_flow_api.id(5143571665344221)
,p_name=>'123-Solicitar Usuario'
,p_alias=>'123-SOLICITAR-USUARIO'
,p_step_title=>'123-Solicitar Usuario'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_last_updated_by=>'JORGE.ROJAS'
,p_last_upd_yyyymmddhh24miss=>'20241114093831'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(447095781739781469)
,p_plug_name=>unistr('Solicitar Usuario y Contrase\00F1a')
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(5058998562344289)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<center><h2>Instituto Costarricense de Turismo</h2></center>',
unistr('<center><h3>Solicitar usuario y contrase\00F1a</h3></center>')))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(447094548349781457)
,p_plug_name=>'Formulario Solicitar Usuario'
,p_parent_plug_id=>wwv_flow_api.id(447095781739781469)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_region_attributes=>'style="width: 600px;"'
,p_plug_template=>wwv_flow_api.id(5058998562344289)
,p_plug_display_sequence=>20
,p_plug_display_column=>5
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(263217184618179228)
,p_button_sequence=>110
,p_button_plug_id=>wwv_flow_api.id(447094548349781457)
,p_button_name=>'BTN_ENVIAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5121094921344251)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Enviar'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(263217586250179229)
,p_button_sequence=>120
,p_button_plug_id=>wwv_flow_api.id(447094548349781457)
,p_button_name=>'BTN_REGRESAR'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5121094921344251)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Cancelar'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.:::'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(263238616447179260)
,p_branch_name=>'Go to 110'
,p_branch_action=>'f?p=&APP_ID.:110:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(263217989085179230)
,p_name=>'P123_NOMBRE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(447094548349781457)
,p_prompt=>'Nombre completo:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>50
,p_field_template=>wwv_flow_api.id(5120299602344255)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(263218380009179230)
,p_name=>'P123_ID_TIPO_IDENTIFICACION'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(447094548349781457)
,p_prompt=>unistr('Tipo Identificaci\00F3n:')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_TIPO_IDENTIFICACION1'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(5120299602344255)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(263218717231179231)
,p_name=>'P123_MENSAJE_CED_JURIDCA'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(447094548349781457)
,p_item_default=>unistr('La Personer\00EDa Jur\00EDdica aportada no debe exceder m\00E1s de 30 d\00EDas de emitida')
,p_prompt=>unistr('Atenci\00F3n:')
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_tag_attributes=>'style="color:#444cd1;"'
,p_field_template=>wwv_flow_api.id(5119886074344255)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(263219104447179233)
,p_name=>'P123_CEDULA'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(447094548349781457)
,p_prompt=>'Cedula:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(5120299602344255)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(263219593580179234)
,p_name=>'P123_VALID_MC'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(447094548349781457)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(263219919829179234)
,p_name=>'P123_MENSAJE'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(447094548349781457)
,p_item_default=>'El contribuyente ya se encuentra inscrito...'
,p_prompt=>unistr('Atenci\00F3n:')
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_tag_attributes=>'style="color:red;"'
,p_field_template=>wwv_flow_api.id(5119886074344255)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(263220380361179234)
,p_name=>'P123_TELEFONO1'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(447094548349781457)
,p_prompt=>unistr('Tel\00E9fono 1:')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(5120299602344255)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(263220785914179234)
,p_name=>'P123_TELEFONO2'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(447094548349781457)
,p_prompt=>unistr('Tel\00E9fono 2:')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(5119973298344255)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(263221126687179235)
,p_name=>'P123_CORREO1'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(447094548349781457)
,p_prompt=>'Correo 1:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(5120299602344255)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(263221567401179235)
,p_name=>'P123_CORREO2'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(447094548349781457)
,p_prompt=>'Correo 2:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(5119973298344255)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(263221951806179235)
,p_name=>'P123_ID_PROVINCIA_ENTIDAD'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_api.id(447094548349781457)
,p_prompt=>'Provincia:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'SELECT DESCRIPCION, ID FROM PROVINCIAS@consulta_ictx'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(5120299602344255)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(263222310170179236)
,p_name=>'P123_ID_CANTON_ENTIDAD'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_api.id(447094548349781457)
,p_prompt=>unistr('Cant\00F3n:')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DESCRIPCION, ID ',
'FROM CANTONES@consulta_ictx ',
'WHERE PROV_ID = :P123_ID_PROVINCIA_ENTIDAD'))
,p_lov_display_null=>'YES'
,p_lov_cascade_parent_items=>'P123_ID_PROVINCIA_ENTIDAD'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(5120299602344255)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(263222722843179237)
,p_name=>'P123_ID_DISTRITO_ENTIDAD'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_api.id(447094548349781457)
,p_prompt=>'Distrito:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DESCRIPCION, ID ',
'FROM DISTRITOS@consulta_ictx ',
'WHERE PROV_ID = :P123_ID_PROVINCIA_ENTIDAD',
'AND CANTON_ID = :P123_ID_CANTON_ENTIDAD'))
,p_lov_display_null=>'YES'
,p_lov_cascade_parent_items=>'P123_ID_PROVINCIA_ENTIDAD,P123_ID_CANTON_ENTIDAD'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(5120299602344255)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(263223108287179239)
,p_name=>'P123_DIRECCION_ENTIDAD'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_api.id(447094548349781457)
,p_prompt=>unistr('Direcci\00F3n:')
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(5120299602344255)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(263223574710179239)
,p_name=>'P123_ARCHIVO'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_api.id(447094548349781457)
,p_prompt=>unistr('Archivo (Cedula F\00EDsica o Jur\00EDdica)')
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_tag_attributes=>'accept=".pdf,.jpeg,.png"'
,p_field_template=>wwv_flow_api.id(5120299602344255)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
,p_attribute_11=>'.pdf'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(263223900185179241)
,p_name=>'P123_TIPO_CONTRIBUYENTE'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_api.id(447094548349781457)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(263225674501179243)
,p_validation_name=>'VAL_NOMBRE_NOT_NULL'
,p_validation_sequence=>10
,p_validation=>'P123_NOMBRE'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Debe ingresar el nombre completo'
,p_validation_condition=>'P123_NOMBRE'
,p_validation_condition_type=>'ITEM_IS_NULL'
,p_when_button_pressed=>wwv_flow_api.id(263217184618179228)
,p_associated_item=>wwv_flow_api.id(263217989085179230)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(263226094367179244)
,p_validation_name=>'VAL_ID_TIPO_IDENTIFICACION_NOT_NULL'
,p_validation_sequence=>20
,p_validation=>'P123_ID_TIPO_IDENTIFICACION'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>unistr('Debe seleccionar un tipo de identificaci\00F3n')
,p_validation_condition=>'P123_ID_TIPO_IDENTIFICACION'
,p_validation_condition_type=>'ITEM_IS_NULL'
,p_associated_item=>wwv_flow_api.id(263218380009179230)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(263226443988179244)
,p_validation_name=>'VAL_CEDULA_NOT_NULL'
,p_validation_sequence=>30
,p_validation=>'P123_CEDULA'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>unistr('Debe ingresar el n\00FAmero de identificaci\00F3n')
,p_validation_condition=>'P123_CEDULA'
,p_validation_condition_type=>'ITEM_IS_NULL'
,p_associated_item=>wwv_flow_api.id(263219104447179233)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(263224884023179242)
,p_validation_name=>'VAL_CEDULA'
,p_validation_sequence=>40
,p_validation=>'P123_CEDULA'
,p_validation_type=>'ITEM_IS_ALPHANUMERIC'
,p_error_message=>unistr('Por favor ingresar el n\00FAmero de c\00E9dula sin espacios y sin guiones ejemplo (102220333)')
,p_validation_condition=>'P123_CEDULA'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_associated_item=>wwv_flow_api.id(263219104447179233)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(263226824238179244)
,p_validation_name=>'VAL_TELEFONO1_NOT_NULL'
,p_validation_sequence=>50
,p_validation=>'P123_TELEFONO1'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>unistr('Debe ingresar al menos un n\00FAmero de tel\00E9fono')
,p_validation_condition=>'P123_TELEFONO1'
,p_validation_condition_type=>'ITEM_IS_NULL'
,p_associated_item=>wwv_flow_api.id(263220380361179234)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(263227277923179244)
,p_validation_name=>'VAL_CORREO1_NOT_NULL'
,p_validation_sequence=>60
,p_validation=>'P123_CORREO1'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>unistr('Debe ingresar al menos un correo electr\00F3nico')
,p_validation_condition=>'P123_CORREO1'
,p_validation_condition_type=>'ITEM_IS_NULL'
,p_associated_item=>wwv_flow_api.id(263221126687179235)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(263224401140179241)
,p_validation_name=>'VAL_CORREO1'
,p_validation_sequence=>70
,p_validation=>'P123_CORREO1'
,p_validation2=>'@'
,p_validation_type=>'ITEM_IN_VALIDATION_CONTAINS_AT_LEAST_ONE_CHAR_IN_STRING2'
,p_error_message=>'Formato de correo incorrecto'
,p_validation_condition=>'P123_CORREO1'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_associated_item=>wwv_flow_api.id(263221126687179235)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(263229204594179247)
,p_validation_name=>'VAL_CORREO2'
,p_validation_sequence=>80
,p_validation=>'P123_CORREO2'
,p_validation2=>'@'
,p_validation_type=>'ITEM_IN_VALIDATION_CONTAINS_AT_LEAST_ONE_CHAR_IN_STRING2'
,p_error_message=>'Formato de correo incorrecto'
,p_validation_condition=>'P123_CORREO2'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_associated_item=>wwv_flow_api.id(263221567401179235)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(263227648925179244)
,p_validation_name=>'VAL_ID_PROVINCIA_ENTIDAD_NOT_NULL'
,p_validation_sequence=>90
,p_validation=>'P123_ID_PROVINCIA_ENTIDAD'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Debe seleccionar una provincia'
,p_validation_condition=>'P123_ID_PROVINCIA_ENTIDAD'
,p_validation_condition_type=>'ITEM_IS_NULL'
,p_associated_item=>wwv_flow_api.id(263221951806179235)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(263228063004179245)
,p_validation_name=>'VAL_ID_CANTON_ENTIDAD_NOT_NULL'
,p_validation_sequence=>100
,p_validation=>'P123_ID_CANTON_ENTIDAD'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>unistr('Debe seleccionar un cant\00F3n')
,p_validation_condition=>'P123_ID_CANTON_ENTIDAD'
,p_validation_condition_type=>'ITEM_IS_NULL'
,p_associated_item=>wwv_flow_api.id(263222310170179236)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(263228471441179246)
,p_validation_name=>'VAL_ID_DISTRITO_ENTIDAD_NOT_NULL'
,p_validation_sequence=>110
,p_validation=>'P123_ID_DISTRITO_ENTIDAD'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Debe seleccionar un distrito'
,p_validation_condition=>'P123_ID_DISTRITO_ENTIDAD'
,p_validation_condition_type=>'ITEM_IS_NULL'
,p_associated_item=>wwv_flow_api.id(263222722843179237)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(263228803685179246)
,p_validation_name=>'VAL_ID_DIRECCION_ENTIDAD_NOT_NULL'
,p_validation_sequence=>120
,p_validation=>'P123_DIRECCION_ENTIDAD'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>unistr('Debe ingresar la direcci\00F3n de residencia')
,p_validation_condition=>'P123_DIRECCION_ENTIDAD'
,p_validation_condition_type=>'ITEM_IS_NULL'
,p_associated_item=>wwv_flow_api.id(263223108287179239)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(263225244029179243)
,p_validation_name=>'VAL_ARCHIVO_NOT_NULL'
,p_validation_sequence=>130
,p_validation=>'P123_ARCHIVO'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>unistr('Debe adjuntar el archivo (Cedula F\00EDsica o Jur\00EDdica)')
,p_validation_condition=>'P123_ARCHIVO'
,p_validation_condition_type=>'ITEM_IS_NULL'
,p_associated_item=>wwv_flow_api.id(263223574710179239)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(263230352087179251)
,p_name=>'DAC_VALIDA_MC'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P123_CEDULA'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(263230878635179253)
,p_event_id=>wwv_flow_api.id(263230352087179251)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'vExiste VARCHAR2(1);',
'BEGIN',
':P123_VALID_MC:= PKG_MAESTRO_CONTRIBUYENTE.VALIDA_EXISTE_MC (:P123_CEDULA);',
'END;'))
,p_attribute_02=>'P123_CEDULA'
,p_attribute_03=>'P123_VALID_MC'
,p_attribute_04=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(263237758759179259)
,p_name=>'DAC_VALID_COMAS_CORREO2'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P123_CORREO2'
,p_bind_type=>'bind'
,p_bind_event_type=>'focusout'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(263238124960179260)
,p_event_id=>wwv_flow_api.id(263237758759179259)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
':P123_CORREO2 := REPLACE (:P123_CORREO2,'','',''.'');',
'',
'END;'))
,p_attribute_02=>'P123_CORREO2'
,p_attribute_03=>'P123_CORREO2'
,p_attribute_04=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(263231260106179254)
,p_name=>'DAC_MUESTRA_MSJ'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P123_VALID_MC'
,p_condition_element=>'P123_VALID_MC'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'S'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(263231785211179254)
,p_event_id=>wwv_flow_api.id(263231260106179254)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P123_MENSAJE'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(263232732078179256)
,p_event_id=>wwv_flow_api.id(263231260106179254)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_api.id(263217184618179228)
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(263232297281179255)
,p_event_id=>wwv_flow_api.id(263231260106179254)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_api.id(263217184618179228)
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(263233272710179256)
,p_event_id=>wwv_flow_api.id(263231260106179254)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P123_MENSAJE'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(263233612254179256)
,p_name=>'DAC_VALID_COMAS_CORREO1'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P123_CORREO1'
,p_bind_type=>'bind'
,p_bind_event_type=>'focusout'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(263234166831179257)
,p_event_id=>wwv_flow_api.id(263233612254179256)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
':P123_CORREO1 := REPLACE (:P123_CORREO1,'','',''.'');',
'',
'END;'))
,p_attribute_02=>'P123_CORREO1'
,p_attribute_03=>'P123_CORREO1'
,p_attribute_04=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(263234516938179257)
,p_name=>'DAC_UPPER_NOMBRE'
,p_event_sequence=>50
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P123_NOMBRE'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(263235042029179257)
,p_event_id=>wwv_flow_api.id(263234516938179257)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$("#P123_NOMBRE").val($("#P123_NOMBRE").val().toUpperCase());'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(263235455756179258)
,p_name=>'DAC_UPPER_DIRECCION'
,p_event_sequence=>60
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P123_DIRECCION_ENTIDAD'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(263235968846179258)
,p_event_id=>wwv_flow_api.id(263235455756179258)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$("#P123_DIRECCION_ENTIDAD").val($("#P123_DIRECCION_ENTIDAD").val().toUpperCase());'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(263236372545179258)
,p_name=>'DAC_MUESTRA_MSJ_CED_JURIDICA'
,p_event_sequence=>70
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P123_ID_TIPO_IDENTIFICACION'
,p_condition_element=>'P123_ID_TIPO_IDENTIFICACION'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'1'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(263236866633179259)
,p_event_id=>wwv_flow_api.id(263236372545179258)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P123_MENSAJE_CED_JURIDCA'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(263237325889179259)
,p_event_id=>wwv_flow_api.id(263236372545179258)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P123_MENSAJE_CED_JURIDCA'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(263229932330179251)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_DATOS'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
':P123_VALID_MC := NULL;',
':P123_CEDULA := NULL;',
'END;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(263229598227179247)
,p_process_sequence=>10
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_INSERTA_SOLICITUD'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'vId_Num_Inscripcion NUMBER;',
'vMensaje_Retorno varchar2(200);',
'vRetorno boolean;',
'vCedulaF VARCHAR2(30);',
'vCedulaJ VARCHAR2(30);',
'',
'vArchivo BLOB;',
'vMimetype VARCHAR2(255);',
'vFilename VARCHAR2(255);',
'BEGIN',
'IF :P123_ID_TIPO_IDENTIFICACION = 1 THEN',
'    vCedulaJ := :P123_CEDULA;',
'ELSE',
'    vCedulaF := :P123_CEDULA;',
'END IF;',
'IF :P123_ARCHIVO IS NOT NULL THEN',
'PKG_INSCRIPCION_REGULAR.P_INSERT_SOLICITUD_INSCRIP (vId_Num_Inscripcion,',
'                                                    :P123_NOMBRE,      ',
'                                                    :P123_ID_TIPO_IDENTIFICACION, ',
'                                                    NULL,--Razon social',
'                                                    NULL,--Persona fisica      ',
'                                                    vCedulaJ,      ',
'                                                    vCedulaF,',
'                                                    :P123_TIPO_CONTRIBUYENTE,--Tipo fuente           ',
'                                                    NULL,--Codigo IATA          ',
'                                                    NULL,--Tipo ventas',
'                                                    NULL,--Fecha inicio ope      ',
'                                                    :P123_DIRECCION_ENTIDAD,    ',
'                                                    :P123_ID_PROVINCIA_ENTIDAD,',
'                                                    :P123_ID_CANTON_ENTIDAD,     ',
'                                                    :P123_ID_DISTRITO_ENTIDAD,    ',
'                                                    NULL,--DIRECCION_NOTIFICA,',
'                                                    NULL,--ID_PROVINCIA_NOTIFICA, ',
'                                                    NULL,--ID_CANTON_NOTIFICA,     ',
'                                                    NULL,--ID_DISTRITO_NOTIFICA, ',
'                                                    NULL,--CEDULA_GERENTE,      ',
'                                                    NULL,--NOMBRE_GERENTE,       ',
'                                                    NULL,--CORREO_GERENTE,                                  ',
'                                                    NULL,--NOMBRE_REPRE_LEGAL,  ',
'                                                    NULL,--CEDULA_REPRE_LEGAL,   ',
'                                                    NULL,--pCORREO_REPRE_LEGAL,',
'                                                    ''P'',--pCODIGO_ESTADO,       ',
'                                                    SYSDATE,        ',
'                                                    NULL,--OBSERVA_EMPRESA,    ',
'                                                    NULL,--OBSERVA_ADM_TRIBUTA, ',
'                                                    NULL,--FECHA_SUSCRITO,           ',
'                                                    NULL,--LUGAR_SUSCRITO,',
'                                                    NULL,--USUARIO_INTERNO,     ',
'                                                    NULL,--ID_CHARTER,             ',
'                                                    NULL,--ID_REQUISITOS_INS,',
'                                                    NULL,--ID_MODALIDAD,',
'                                                    NULL,--NOM_ASISTENTE_CHARTER,',
'                                                    NULL,--CEDULA_ASISTENTE_CHARTER,',
'                                                    NULL,--CORREO_ASISTENTE_CHARTER,',
'                                                    NULL,--Encargado,',
'                                                    :APP_USER,',
'                                                    vMensaje_Retorno,',
'                                                    vRetorno);    ',
'    IF vId_Num_Inscripcion IS NOT NULL THEN',
'    --Insertamos los datos en la tabla IMPUESTO_X_SOLICITUD_INSCRI------------------                                        ',
'    PKG_INSCRIPCION_REGULAR.P_INSERT_IMP_SOLIC_INSCRIP (vId_Num_Inscripcion,',
'                                                        1,',
'                                                        NULL,',
'                                                        NULL,',
'                                                        NULL,',
'                                                        :APP_USER,',
'                                                        vMensaje_Retorno,',
'                                                        vRetorno); ',
'    --Insertamos los datos en la tabla TELEFONO_X_SOLICITUD_INSCRIP-----------------',
'    PKG_INSCRIPCION_REGULAR.P_INSERT_TEL_SOLIC_INSCRIP (vId_Num_Inscripcion,',
'                                                        :P123_TELEFONO1,',
'                                                        NULL,',
'                                                        :APP_USER,',
'                                                        vMensaje_Retorno,',
'                                                        vRetorno);',
'    PKG_INSCRIPCION_REGULAR.P_INSERT_TEL_SOLIC_INSCRIP (vId_Num_Inscripcion,',
'                                                        :P123_TELEFONO2,',
'                                                        NULL,',
'                                                        :APP_USER,',
'                                                        vMensaje_Retorno,',
'                                                        vRetorno);                                                    ',
'    --Inserta datos en la tabla CORREO_NOTIFICA_INSCRIP-----------------------------                                          ',
'    PKG_INSCRIPCION_REGULAR.P_INSERT_CORREO_NOT_INSCRIP (vId_Num_Inscripcion,',
'                                                         :P123_CORREO1,',
'                                                         :P123_CORREO2,',
'                                                         :APP_USER,',
'                                                         vMensaje_Retorno,',
'                                                         vRetorno);   ',
'    --Insertamos documentos requeridos',
'    ',
'    SELECT BLOB_CONTENT, MIME_TYPE, FILENAME INTO vArchivo,vMimetype, vFilename FROM APEX_APPLICATION_TEMP_FILES WHERE NAME = :P123_ARCHIVO;',
'    PKG_INSCRIPCION_REGULAR.P_INSERT_ARCHIVO_REQUI_INSCRIP (NULL,',
'                                                            vId_Num_Inscripcion,',
'                                                            vFilename,',
'                                                            vArchivo,',
'                                                            vMimetype,',
'                                                            :APP_USER,',
'                                                            vMensaje_Retorno,',
'                                                            vRetorno);  ',
'   ',
'    --Envio de correo usuario externo',
'    PKG_ENVIO_NOTIF_ICT_CONTRIB.NOTIFICA_INSCRIPCION (vId_Num_Inscripcion,3,''E'',''I'');',
'    --Envio de correo usuario interno',
'    PKG_ENVIO_NOTIF_ICT_CONTRIB.NOTIFICA_INSCRIPCION (vId_Num_Inscripcion,3,''I'',''I'');       ',
'    END IF;',
'END IF;                                                        ',
'END;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(263217184618179228)
);
wwv_flow_api.component_end;
end;
/
