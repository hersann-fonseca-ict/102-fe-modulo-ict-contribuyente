prompt --application/pages/page_00202
begin
--   Manifest
--     PAGE: 00202
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>5801312104779619
,p_default_application_id=>102
,p_default_id_offset=>0
,p_default_owner=>'DESA_SIT'
);
wwv_flow_api.create_page(
 p_id=>202
,p_user_interface_id=>wwv_flow_api.id(5143571665344221)
,p_name=>'202-Actuaciones Tributarias '
,p_alias=>'202-ACTUACIONES-TRIBUTARIAS'
,p_step_title=>'202-Actuaciones Tributarias '
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_browser_cache=>'N'
,p_last_updated_by=>'KIMBERLYN.SOLANO'
,p_last_upd_yyyymmddhh24miss=>'20221121125543'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(36111083345785103)
,p_plug_name=>'Actuaciones Tributarias y Cuentas por Cobrar Pendientes'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(5058998562344289)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(36111191804785104)
,p_plug_name=>'Filtros'
,p_parent_plug_id=>wwv_flow_api.id(36111083345785103)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(5058998562344289)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(36111204502785105)
,p_name=>'Reporte Actuaciones Tributarias '
,p_parent_plug_id=>wwv_flow_api.id(36111083345785103)
,p_template=>wwv_flow_api.id(5058998562344289)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID_DOCUMENTO, ',
'       ID_DEUDOR,',
'       ID_TIPO_DOCUMENTO,',
'to_char(PERIODO,''mm/yyyy'') PERIODO, ',
'       QUINCENA, ',
'       CODIGO_ESTADO, ',
'       TIPO_CAMBIO, ',
'       CODIGO_MONEDA, ',
'       MONTO_MONEDA, ',
'       SALDO_MONEDA,',
'       MONTO_COLONES,',
'       SALDO_COLONES      ',
'from DOCUMENTOS_X_COBRAR@CONSULTA_ICTX ',
'where CODIGO_ESTADO in (''EN'', ''P'',''CJ'')',
'AND ID_DEUDOR = PKG_MAESTRO_CONTRIBUYENTE.RETORNA_ID_DEUDOR(:APP_USER)',
'AND ID_TIPO_DOCUMENTO IN (SELECT ID_TIPO_DOCUMENTO FROM TIPOS_DOCUMENTOS_CXC@CONSULTA_ICTX B',
'                          WHERE ID_TIPO_IMPUESTO = NVL(:P202_TIPO_IMPUESTO,ID_TIPO_IMPUESTO) AND',
'                            NVL(INDICADOR_DECLARACION,0) = 1) ',
'UNION',
'select ID_DOCUMENTO, ',
'       ID_DEUDOR,',
'       ID_TIPO_DOCUMENTO,',
'to_char(PERIODO,''mm/yyyy'') PERIODO, ',
'       QUINCENA, ',
'       CODIGO_ESTADO, ',
'       TIPO_CAMBIO, ',
'       CODIGO_MONEDA, ',
'       MONTO_MONEDA, ',
'       SALDO_MONEDA,',
'       MONTO_COLONES,',
'       SALDO_COLONES      ',
'from DOCUMENTOS_X_COBRAR@CONSULTA_ICTX ',
'where CODIGO_ESTADO in (''EN'', ''P'',''CJ'')',
'AND ID_DEUDOR = PKG_MAESTRO_CONTRIBUYENTE.RETORNA_ID_DEUDOR(:APP_USER)',
'AND ID_TIPO_DOCUMENTO IN (SELECT ID_TIPO_DOCUMENTO FROM TIPOS_DOCUMENTOS_CXC@CONSULTA_ICTX B',
'                          WHERE ID_TIPO_IMPUESTO = NVL(:P202_TIPO_IMPUESTO,ID_TIPO_IMPUESTO) AND',
'                                NVL(IND_RESOLUCION,0) = 1) ',
'UNION',
'select ID_DOCUMENTO, ',
'       ID_DEUDOR,',
'       ID_TIPO_DOCUMENTO,',
'to_char(PERIODO,''mm/yyyy'') PERIODO, ',
'       QUINCENA, ',
'       CODIGO_ESTADO, ',
'       TIPO_CAMBIO, ',
'       CODIGO_MONEDA, ',
'       MONTO_MONEDA, ',
'       SALDO_MONEDA,',
'       MONTO_COLONES,',
'       SALDO_COLONES      ',
'from DOCUMENTOS_X_COBRAR@CONSULTA_ICTX ',
'where CODIGO_ESTADO in (''EN'', ''P'',''CJ'')',
'AND ID_DEUDOR = PKG_MAESTRO_CONTRIBUYENTE.RETORNA_ID_DEUDOR(:APP_USER)',
'AND ID_TIPO_DOCUMENTO IN (SELECT ID_TIPO_DOCUMENTO FROM TIPOS_DOCUMENTOS_CXC@CONSULTA_ICTX B',
'                          WHERE ID_TIPO_IMPUESTO = NVL(:P202_TIPO_IMPUESTO,ID_TIPO_IMPUESTO) AND',
'                                NVL(IND_COSTAS_PROCESALES,0) = 1)',
'UNION',
'select ID_DOCUMENTO, ',
'       ID_DEUDOR,',
'       ID_TIPO_DOCUMENTO,',
'to_char(PERIODO,''mm/yyyy'') PERIODO, ',
'       QUINCENA, ',
'       CODIGO_ESTADO, ',
'       TIPO_CAMBIO, ',
'       CODIGO_MONEDA, ',
'       MONTO_MONEDA, ',
'       SALDO_MONEDA,',
'       MONTO_COLONES,',
'       SALDO_COLONES      ',
'from DOCUMENTOS_X_COBRAR@CONSULTA_ICTX ',
'where CODIGO_ESTADO in (''EN'', ''P'',''CJ'')',
'AND ID_DEUDOR = PKG_MAESTRO_CONTRIBUYENTE.RETORNA_ID_DEUDOR(:APP_USER)',
'AND ID_TIPO_DOCUMENTO IN (SELECT ID_TIPO_DOCUMENTO FROM TIPOS_DOCUMENTOS_CXC@CONSULTA_ICTX B',
'                          WHERE ID_TIPO_IMPUESTO = NVL(:P202_TIPO_IMPUESTO,ID_TIPO_IMPUESTO) AND',
'                                NVL(IND_RECTIFICA,0) = 1)                                  '))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P202_TIPO_IMPUESTO'
,p_query_row_template=>wwv_flow_api.id(5085249619344274)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'SEARCH_ENGINE'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(36111363828785106)
,p_query_column_id=>1
,p_column_alias=>'ID_DOCUMENTO'
,p_column_display_sequence=>1
,p_column_heading=>'Documento'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(36111424320785107)
,p_query_column_id=>2
,p_column_alias=>'ID_DEUDOR'
,p_column_display_sequence=>2
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(36111518673785108)
,p_query_column_id=>3
,p_column_alias=>'ID_TIPO_DOCUMENTO'
,p_column_display_sequence=>3
,p_column_heading=>'Tipo Documento'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_api.id(36151159647665504)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(84957085352006106)
,p_query_column_id=>4
,p_column_alias=>'PERIODO'
,p_column_display_sequence=>11
,p_column_heading=>'Periodo'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(36111706853785110)
,p_query_column_id=>5
,p_column_alias=>'QUINCENA'
,p_column_display_sequence=>4
,p_column_heading=>'Quincena'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(36111852619785111)
,p_query_column_id=>6
,p_column_alias=>'CODIGO_ESTADO'
,p_column_display_sequence=>5
,p_column_heading=>'Estado'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_api.id(30271022373201996)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(84957357443006109)
,p_query_column_id=>7
,p_column_alias=>'TIPO_CAMBIO'
,p_column_display_sequence=>12
,p_column_heading=>'Tipo Cambio'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G990D00'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(36112082039785113)
,p_query_column_id=>8
,p_column_alias=>'CODIGO_MONEDA'
,p_column_display_sequence=>6
,p_column_heading=>'Moneda'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_api.id(36154951738689168)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(36112190864785114)
,p_query_column_id=>9
,p_column_alias=>'MONTO_MONEDA'
,p_column_display_sequence=>7
,p_column_heading=>'Monto Moneda'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G990D00'
,p_column_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(36112227531785115)
,p_query_column_id=>10
,p_column_alias=>'SALDO_MONEDA'
,p_column_display_sequence=>8
,p_column_heading=>'Saldo Moneda'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G990D00'
,p_column_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(36112316779785116)
,p_query_column_id=>11
,p_column_alias=>'MONTO_COLONES'
,p_column_display_sequence=>9
,p_column_heading=>'Monto Colones'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G990D00'
,p_column_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(36112432467785117)
,p_query_column_id=>12
,p_column_alias=>'SALDO_COLONES'
,p_column_display_sequence=>10
,p_column_heading=>'Saldo Colones'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G990D00'
,p_column_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(36112664204785119)
,p_name=>'P202_TIPO_IMPUESTO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(36111191804785104)
,p_prompt=>'Tipo Impuesto:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_IMPUESTO'
,p_lov=>'.'||wwv_flow_api.id(12378667772254658)||'.'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(5119973298344255)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'SUBMIT'
,p_attribute_03=>'Y'
);
wwv_flow_api.component_end;
end;
/
