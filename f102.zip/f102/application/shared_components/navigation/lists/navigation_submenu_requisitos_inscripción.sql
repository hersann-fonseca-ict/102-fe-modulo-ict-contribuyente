prompt --application/shared_components/navigation/lists/navigation_submenu_requisitos_inscripción
begin
--   Manifest
--     LIST: Navigation Submenu requisitos Inscripción
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>5801312104779619
,p_default_application_id=>102
,p_default_id_offset=>0
,p_default_owner=>'DESA_SIT'
);
wwv_flow_api.create_list(
 p_id=>wwv_flow_api.id(42898112770756593)
,p_name=>unistr('Navigation Submenu requisitos Inscripci\00F3n')
,p_list_status=>'PUBLIC'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(42898364504756595)
,p_list_item_display_sequence=>70
,p_list_item_link_text=>'Agencia de viajes'
,p_list_item_link_target=>'f?p=&APP_ID.:100:&SESSION.::&DEBUG.:RP,100:P100_TIPO_CONTRIBUYENTE,P100_NOMBRE:2,Agencia de viajes:'
,p_list_item_icon=>'fa-briefcase'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'122'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(42898721890756598)
,p_list_item_display_sequence=>80
,p_list_item_link_text=>unistr('L\00EDnea A\00E9rea')
,p_list_item_link_target=>unistr('f?p=&APP_ID.:100:&SESSION.::&DEBUG.:100:P100_TIPO_CONTRIBUYENTE,P100_NOMBRE:3,L\00EDnea A\00E9rea:')
,p_list_item_icon=>'fa-fighter-jet'
,p_list_item_disp_cond_type=>'USER_IS_PUBLIC_USER'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(42899122484756598)
,p_list_item_display_sequence=>190
,p_list_item_link_text=>'Transportes Terrestres'
,p_list_item_link_target=>'f?p=&APP_ID.:100:&SESSION.::&DEBUG.:100:P100_TIPO_CONTRIBUYENTE,P100_NOMBRE:4,Transportes Terrestres:'
,p_list_item_icon=>'fa-truck'
,p_list_item_disp_cond_type=>'USER_IS_PUBLIC_USER'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(42900203823773627)
,p_list_item_display_sequence=>200
,p_list_item_link_text=>'Navieras '
,p_list_item_link_target=>'f?p=&APP_ID.:100:&SESSION.::&DEBUG.:100:P100_TIPO_CONTRIBUYENTE,P100_NOMBRE:5,Navieras :'
,p_list_item_icon=>'fa-ship'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.component_end;
end;
/
