prompt --application/shared_components/navigation/lists/wizard_progress_list_ir
begin
--   Manifest
--     LIST: Wizard Progress List IR
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>5801312104779619
,p_default_application_id=>102
,p_default_id_offset=>0
,p_default_owner=>'DESA_SIT'
);
wwv_flow_api.create_list(
 p_id=>wwv_flow_api.id(5407085389363356)
,p_name=>'Wizard Progress List IR'
,p_list_status=>'PUBLIC'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(5408052998363351)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Inicio'
,p_list_item_link_target=>'f?p=&APP_ID.:102:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(5411466008363338)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>unistr('Informaci\00F3n General')
,p_list_item_link_target=>'f?p=&APP_ID.:103:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(5415665182363337)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Impuesto / Encargado'
,p_list_item_link_target=>'f?p=&APP_ID.:104:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(5419810619363335)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>unistr('Domicilio / Direcci\00F3n')
,p_list_item_link_target=>'f?p=&APP_ID.:105:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(5424041965363334)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>unistr('Informaci\00F3n Gerente / Representante Legal')
,p_list_item_link_target=>'f?p=&APP_ID.:106:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(5428290810363332)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>unistr('Informaci\00F3n Apoderado')
,p_list_item_link_target=>'f?p=&APP_ID.:107:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(5432469906363331)
,p_list_item_display_sequence=>70
,p_list_item_link_text=>unistr('Autorizaci\00F3n Uso Firma Digital')
,p_list_item_link_target=>'f?p=&APP_ID.:108:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(5436684297363329)
,p_list_item_display_sequence=>80
,p_list_item_link_text=>'Observaciones de la empresa'
,p_list_item_link_target=>'f?p=&APP_ID.:109:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(19674372271342596)
,p_list_item_display_sequence=>90
,p_list_item_link_text=>'Documentos Requeridos'
,p_list_item_link_target=>'f?p=&APP_ID.:111:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.component_end;
end;
/
