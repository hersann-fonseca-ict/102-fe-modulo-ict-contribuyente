prompt --application/shared_components/navigation/lists/wizard_progress_list_ivc
begin
--   Manifest
--     LIST: Wizard Progress List IVC
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>5801312104779619
,p_default_application_id=>102
,p_default_id_offset=>0
,p_default_owner=>'DESA_SIT'
);
wwv_flow_api.create_list(
 p_id=>wwv_flow_api.id(27737126160602921)
,p_name=>'Wizard Progress List IVC'
,p_list_status=>'PUBLIC'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(27738180198602895)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Inicio '
,p_list_item_link_target=>'f?p=&APP_ID.:115:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(27741657906602883)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>unistr('Informaci\00F3n General Obligado Tributario')
,p_list_item_link_target=>'f?p=&APP_ID.:116:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(27745885869602880)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Tipos de Impuestos a declarar'
,p_list_item_link_target=>'f?p=&APP_ID.:117:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(27750076256602877)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>unistr('Informaci\00F3n Representante en Costa Rica')
,p_list_item_link_target=>'f?p=&APP_ID.:118:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(27754201362602875)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>unistr('Informaci\00F3n Asistente en Tierra en Costa Rica (Obligatorio)')
,p_list_item_link_target=>'f?p=&APP_ID.:119:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(27758456263602871)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>unistr('Informaci\00F3n Apoderado Especial')
,p_list_item_link_target=>'f?p=&APP_ID.:120:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(27762616518602869)
,p_list_item_display_sequence=>70
,p_list_item_link_text=>unistr('Direcci\00F3n Electr\00F3nica para Notificaciones')
,p_list_item_link_target=>'f?p=&APP_ID.:121:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.component_end;
end;
/
