prompt --application/shared_components/navigation/lists/navigation_submenu_cot1
begin
--   Manifest
--     LIST: Navigation Submenu COT1
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>5801312104779619
,p_default_application_id=>102
,p_default_id_offset=>0
,p_default_owner=>'DESA_SIT'
);
wwv_flow_api.create_list(
 p_id=>wwv_flow_api.id(263205619239097367)
,p_name=>'Navigation Submenu COT1'
,p_list_status=>'PUBLIC'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263205964657097378)
,p_list_item_display_sequence=>70
,p_list_item_link_text=>unistr('Ch\00E1rter ocasional terrestre')
,p_list_item_link_target=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-truck'
,p_list_item_disp_cond_type=>'NEVER'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'122'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263206318985097379)
,p_list_item_display_sequence=>80
,p_list_item_link_text=>unistr('Solicitar usuario y contrase\00F1a')
,p_list_item_link_target=>'f?p=&APP_ID.:123:&SESSION.::&DEBUG.::P123_TIPO_CONTRIBUYENTE:&P5_TIPO_CONTRIBUYENTE.:'
,p_list_item_icon=>'fa-address-card-o'
,p_list_item_disp_cond_type=>'USER_IS_PUBLIC_USER'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263206756303097379)
,p_list_item_display_sequence=>190
,p_list_item_link_text=>unistr('Ingresar con usuario y contrase\00F1a')
,p_list_item_link_target=>'f?p=&APP_ID.:9999:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-user'
,p_list_item_disp_cond_type=>'USER_IS_PUBLIC_USER'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263207101388097379)
,p_list_item_display_sequence=>200
,p_list_item_link_text=>unistr('Confirmaci\00F3n de aduanas')
,p_list_item_link_target=>'f?p=&APP_ID.:9999:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-user-check'
,p_list_item_disp_cond_type=>'USER_IS_PUBLIC_USER'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.component_end;
end;
/
