prompt --application/shared_components/navigation/lists/navigation_submenu_consultas
begin
--   Manifest
--     LIST: Navigation Submenu Consultas
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>5801312104779619
,p_default_application_id=>102
,p_default_id_offset=>0
,p_default_owner=>'DESA_SIT'
);
wwv_flow_api.create_list(
 p_id=>wwv_flow_api.id(40820634956069668)
,p_name=>'Navigation Submenu Consultas'
,p_list_status=>'PUBLIC'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(40825218131069675)
,p_list_item_display_sequence=>110
,p_list_item_link_text=>'Consultas Gestiones Tributarias '
,p_list_item_icon=>'fa-align-justify'
,p_list_item_disp_cond_type=>'NEVER'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(40825613046069676)
,p_list_item_display_sequence=>120
,p_list_item_link_text=>'Declar. Presentadas Imp. $15 y 5%(ab)'
,p_list_item_link_target=>'f?p=&APP_ID.:200:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-file-text'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'200'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(40826057179069676)
,p_list_item_display_sequence=>130
,p_list_item_link_text=>'Declaraciones Rectificadas'
,p_list_item_link_target=>'f?p=&APP_ID.:201:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-file-text-o'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(40826485931069676)
,p_list_item_display_sequence=>140
,p_list_item_link_text=>'Actuaciones Tributarias'
,p_list_item_link_target=>'f?p=&APP_ID.:202:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-file-text'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'202'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(40826825393069676)
,p_list_item_display_sequence=>150
,p_list_item_link_text=>unistr('Cr\00E9ditos Fiscales')
,p_list_item_link_target=>'f?p=&APP_ID.:203:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-file-text-o'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'203'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(40827280076069676)
,p_list_item_display_sequence=>160
,p_list_item_link_text=>'Consulta Cuotas Arreglos Pagos'
,p_list_item_link_target=>'f?p=&APP_ID.:204:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-file-text'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'204'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(40827692638069676)
,p_list_item_display_sequence=>170
,p_list_item_link_text=>'Consulta Intereses Tributarios'
,p_list_item_link_target=>'f?p=&APP_ID.:205:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-calculator'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'205'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(40828034740069676)
,p_list_item_display_sequence=>180
,p_list_item_link_text=>'Consulta Intereses Arreglos de Pago'
,p_list_item_link_target=>'f?p=&APP_ID.:206:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-calculator'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'206'
);
wwv_flow_api.component_end;
end;
/
