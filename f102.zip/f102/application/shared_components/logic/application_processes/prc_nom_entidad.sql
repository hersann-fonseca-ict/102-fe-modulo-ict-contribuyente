prompt --application/shared_components/logic/application_processes/prc_nom_entidad
begin
--   Manifest
--     APPLICATION PROCESS: PRC_NOM_ENTIDAD
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>5801312104779619
,p_default_application_id=>102
,p_default_id_offset=>0
,p_default_owner=>'DESA_SIT'
);
wwv_flow_api.create_flow_process(
 p_id=>wwv_flow_api.id(31129362602702407)
,p_process_sequence=>1
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_NOM_ENTIDAD'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'vId_contribuyente NUMBER;',
'vNombre_Entidad VARCHAR2(2000);',
'vTipoContrib NUMBER;',
'',
'    CURSOR C_MC IS',
'    SELECT ID_CONTRIBUYENTE',
'    FROM   USUARIOS_EXTERNOS',
'    WHERE ID_USUARIO = :APP_USER;',
'',
'    CURSOR C_NOM_ENT(p_id_contribuyente NUMBER) IS',
'    SELECT NOMBRE_ENTIDAD, ID_TIPO_CONTRIBUYENTE',
'    FROM   MAESTRO_CONTRIBUYENTE',
'    WHERE  ID_CONTRIBUYENTE = p_id_contribuyente;',
'BEGIN',
'    ',
'    OPEN  C_MC;',
'    FETCH C_MC INTO vId_contribuyente;',
'    CLOSE C_MC;',
'    ',
'    OPEN  C_NOM_ENT (vId_contribuyente);',
'    FETCH C_NOM_ENT INTO vNombre_Entidad, vTipoContrib;',
'    CLOSE C_NOM_ENT;',
'    ',
'    :GLOBAL_NOM_ENTIDAD := vNombre_Entidad;',
'    :GLOBAL_USUARIO := :APP_USER;',
'    IF vTipoContrib IS NOT NULL THEN',
'        :GLOBAL_TIPO_CONTRIBUYENTE := vTipoContrib;',
'    ELSE',
'        :GLOBAL_TIPO_CONTRIBUYENTE := 16;',
'    END IF;',
'    IF :APP_USER != ''nobody'' THEN',
'        :GLOBAL_TIPO_INSCRIPCION := PKG_MAESTRO_CONTRIBUYENTE.RETORNA_TIPO_INSCRIP_CONTRIB (:APP_USER);',
'    END IF;',
'END;'))
);
wwv_flow_api.component_end;
end;
/
